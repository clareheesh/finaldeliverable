<?php

class Job extends Eloquent{

	protected $table = 'jobs';

	protected $primaryKey = 'id';
	public $incrementing = true;

	protected $fillable = array('id', 'user_id', 'name', 'company', 'location', 'department', 'date');

	// DEFINE RELATIONSHIPS --------------------------------------------------

	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
}