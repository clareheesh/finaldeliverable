<?php

class MessageLobby extends Eloquent{

	protected $table = 'message_lobbies';
	protected $primaryKey = 'id';

	public $incrementing = true;
	//	------Database relationships---------------------//
	public function users(){
		return $this->belongsToMany('User', 'message_lobby_users', 'message_lobby_id', 'user_id');
	}
	public function messages(){
		return $this->hasMany('Message', 'message_lobby_id');
	}
	
	
	/*
	 * Get all members of the lobby except for $userId
	 */
	public function getOtherUsers($userId){
		return $this->belongsToMany('User', 'message_lobby_users', 'message_lobby_id', 'user_id')->where('user_id','!=',$userId)->get();
	}

	/*
	 * Get all messages of the lobby
	 */
	public function getMessages(){
		return $this->messages()->get();
	}
	
	/*
	 * Get the last message sent to the lobby
	 */
	public function lastMessage(){
		return $this->hasMany('Message', 'message_lobby_id')->orderby('created_at', 'desc')->first();
	}
	
	/*
	 * Count the number of users in the lobby
	 */
	public function userCount(){
		return count($this->belongsToMany('User', 'message_lobby_users')->get());
	}
	
	/*
	 * Count the number of unread messages for user_id 
	 */
	public function countMsgUser($user_id){
		return count($this->hasMany('MessageReader', 'lobby_id')->where('user_id','=',$user_id)->where('read','=',0)->get());
	}
}