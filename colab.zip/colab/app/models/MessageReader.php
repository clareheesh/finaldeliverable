<?php

class MessageReader extends Eloquent{

	protected $table = 'messages_read';
	protected $primaryKey = 'id';

	public $incrementing = true;
	
	
	/*
	 * Count unread messages for a user
	 */ 
	public function countNotRead($user_id){
		return count(MessageReader::where('user_id','=',$user_id)->where('read','=',0)->get());
	}
	/*
	 * Count all messages for a user
	 */ 
	public function countAll($user_id){
		return count(MessageReader::where('user_id','=',$user_id)->get());
	}
	/*
	 * Read all messages for a user
	 */ 
	public function readAll($user_id){
		DB::table($this->table)->where('user_id', $user_id)->update(array('read' => 1));
	}
	
}