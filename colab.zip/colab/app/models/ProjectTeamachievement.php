<?php

class ProjectTeamachievement extends Eloquent{

	protected $primaryKey = 'id';
	protected $table = 'projects_teamachievements';
	//	------Database relationships---------------------//
	public function projects(){
		return $this->belongsTo('Project', 'project_id', 'id');
	}
	public function teamachievement(){
		return $this->belongsTo('Teamachievement', 'teamachievement_id', 'id');
	}

	/*
	 *	Get the user who owns this achievement
	 */
	public function getProject(){
		return $this->projects()->first();
	}
	
	/*
	 *	Get the achievement information
	 */
	public function getAch(){
		return $this->teamachievement()->first();
	}
}