<?php

class Rule extends Eloquent{

	protected $primaryKey = 'id';
	protected $table = 'rules';

	//--Define Relationships---------------------//
	public function project(){
		return $this->belongsTo('Project', 'project_id', 'id');
	}

}
?>