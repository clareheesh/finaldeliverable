<?php

class Acknowledgement extends Eloquent{

	protected $table = 'acknowledgements';
	protected $primaryKey = 'id';

	public $incrementing = true;


	//	------Database relationships---------------------//
	
	public function task(){
		return $this->belongsTo('Task', 'task_id', 'id');
	}

	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}

	public function post(){
		return $this->belongsTo('Post', 'post_id', 'id');
	}

}