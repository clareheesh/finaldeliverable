<?php

class Comment extends Eloquent{

	protected $table = 'posts_comments';
	protected $primaryKey = 'id';

	public $incrementing = true;
	//	------Database relationships---------------------//
	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
	
	/*
	 *	Get the user who owns this comment
	 */
	public function getUser(){
		return $this->user()->first();
	}
	
}