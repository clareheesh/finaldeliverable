<?php

class Skill extends Eloquent{

	protected $table = 'skills';

	protected $primaryKey = 'id';
	public $incrementing = true;

	protected $fillable = array('id', 'user_id', 'field', 'ability', 'description');

	// DEFINE RELATIONSHIPS --------------------------------------------------

	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
}