<?php

class Personalachievement extends Eloquent{

	protected $primaryKey = 'id';

	//--Define relationships -----------------------------/
	public function users(){
		return $this->belongsToMany('User', 'users_personalachievements', 'personalachievement_id', 'user_id')->withTimestamps();
	}
}