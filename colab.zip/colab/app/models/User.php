<?php

use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {

	

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'users';

	protected $primaryKey = 'id';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password');

	/**
	 * Get the unique identifier for the user.
	 *
	 * @return mixed
	 */
	public function getAuthIdentifier()
	{
		return $this->getKey();
	}

	/**
	 * Get the password for the user.
	 *
	 * @return string
	 */
	public function getAuthPassword()
	{
		return $this->password;
	}

	/**
	 * Get the token value for the "remember me" session.
	 *
	 * @return string
	 */
	public function getRememberToken()
	{
		return $this->remember_token;
	}

	/**
	 * Set the token value for the "remember me" session.
	 *
	 * @param  string  $value
	 * @return void
	 */
	public function setRememberToken($value)
	{
		$this->remember_token = $value;
	}

	/**
	 * Get the column name for the "remember me" token.
	 *
	 * @return string
	 */
	public function getRememberTokenName()
	{
		return 'remember_token';
	}

	/**
	 * Get the e-mail address where password reminders are sent.
	 *
	 * @return string
	 */
	public function getReminderEmail()
	{
		return $this->email;
	}

	public function projects(){
		return $this->belongsToMany('Project', 'users_projects', 'user_id', 'project_id');
	}

	public function tasks(){
		return $this->hasMany('Task', 'user_id', 'id')->where('soft_delete','!=',1);
	}
    
    public function datafiles(){
		return $this->hasMany('Datafile', 'user_id', 'id');
	}

	public function personalachievements(){
		return $this->belongsToMany('Personalachievement', 'users_personalachievements', 'user_id', 'personalachievement_id')->withTimestamps();
	}

	public function stress() {
		return $this->hasMany('Stress', 'user_id', 'id');
	}

	public function stressInProject($Pid) {
		return $this->hasMany('Stress', 'user_id', 'id')->where('project_id','=',$Pid)->orderby('created_at', 'desc')->first();
	}

	public function acknowledgements(){
		return $this->hasMany('Acknowledgement', 'user_id', 'id');
	}
	
	public function getMessageLobbies() {
		return $this->belongsToMany('MessageLobby', 'message_lobby_users', 'user_id' )->orderby('updated_at','desc')->get();
	}

	public static $factory = array(
	  'email' => 'email',
	  'password' => 'password'
	);
	

}
