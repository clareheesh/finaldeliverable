<?php

class Education extends Eloquent{

	protected $table = 'education';

	protected $primaryKey = 'id';
	public $incrementing = true;

	protected $fillable = array('id', 'user_id', 'title', 'place', 'field', 'gpa', 'graduation_year');

	// DEFINE RELATIONSHIPS --------------------------------------------------

	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
}