<?php

class Notification extends Eloquent{

	protected $primaryKey = 'id';
	protected $table = 'notifications';

	public $incrementing = true;
    
    
    // DEFINE RELATIONSHIPS --------------------------------------------------
    
}