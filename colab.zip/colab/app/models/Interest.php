<?php

class Interest extends Eloquent{

	protected $table = 'interests';

	protected $primaryKey = 'id';
	public $incrementing = true;

	protected $fillable = array('id', 'user_id', 'hobby', 'pet', 'food');

	// DEFINE RELATIONSHIPS --------------------------------------------------

	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
}