<?php

class Milestone extends Eloquent{

	protected $primaryKey = 'id';

	public $incrementing = true;
	
	//-- Define Relationships -----------------------------------------------..
	public function project(){
		return $this->belongsTo('Project', 'project_id');
	}

	public function tasks(){
		return $this->hasMany('Task', 'milestone_id', 'id')->where('soft_delete','!=',1);
	}
	
	/*
	 * Get tasks for milestone
	 */
	public function getTasks(){
		return $this->tasks()->get();
	}
	
	/*
	 * Get finished tasks for milestone
	 */
	public function finishedTasks(){
		return $this->hasMany('Task', 'milestone_id', 'id')->whereprogress(100)->count();
	}
	/*
	 * Count tasks for milestone
	 */
	public function totalTasks(){
		return $this->hasMany('Task', 'milestone_id', 'id')->count();
	}

	/*
	 * Get progress of milestone by averaging task progression
	 */
	public function progress(){
		return round($this->tasks()->avg('progress'));
	}

}