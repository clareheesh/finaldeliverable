<?php

class Task extends Eloquent{

	protected $primaryKey = 'id';
	protected $table = 'tasks';
	
	//	------Database relationships---------------------//
	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}

	public function milestone(){
		return $this->belongsTo('Milestone', 'milestone_id', 'id');
	}

	public function acknowledgements(){
		return $this->hasMany('Acknowledgement', 'task_id', 'id');
	}
	
	
	/*
	 *	Get the project who owns this task
	 */
	public function getProject(){
		return $this->milestone->project()->first();
	}

	


}