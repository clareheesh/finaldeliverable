<?php

class Stress extends Eloquent{

	protected $table = 'stress';

	protected $primaryKey = 'id';

	public $incrementing = true;

	
	//	------Database relationships---------------------//
	public function project(){
		return $this->belongsTo('Project', 'project_id', 'id');
	}
	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}

}