<?php

class UserPersonalachievement extends Eloquent{

	protected $primaryKey = 'id';
	protected $table = 'users_personalachievements';
	//	------Database relationships---------------------//
	public function users(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
	public function personalachievement(){
		return $this->belongsTo('Personalachievement', 'personalachievement_id', 'id');
	}
	
	
	/*
	 *	Get the user who owns this achievement
	 */
	public function getUser(){
		return $this->users()->first();
	}
	
	/*
	 *	Get the achievement information
	 */
	public function getAch(){
		return $this->personalachievement()->first();
	}



}