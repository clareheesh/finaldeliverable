<?php

class Project extends Eloquent{

	protected $primaryKey = 'id';
	//--Define Relationships------------------------------//
	public function users(){
		return $this->belongsToMany('User', 'users_projects', 'project_id', 'user_id');
	}
		
	public function rules(){
		return $this->hasMany('Rule', 'project_id', 'id');
	}
	
	public function milestones(){
		return $this->hasMany('Milestone', 'project_id', 'id');
	}

	public function tasks(){
        return $this->hasManyThrough('Task', 'Milestone', 'project_id', 'milestone_id')->where('tasks.soft_delete','!=',1);
    }

	public function teamachievements(){
		return $this->belongsToMany('Teamachievement', 'projects_teamachievements', 'project_id', 'teamachievement_id');
	}

	public function stress() {
		return $this->hasMany('Stress', 'project_id', 'id');
	}
    
    public function datafiles() {
		return $this->hasMany('DataFile', 'project_id', 'id');
	}

	public function posts() {
		return $this->hasMany('Post', 'project_id', 'id');
	}
	/*
	 * Returns all users of a project
	 */
	public function getUsers(){
		return $this->users()->get();
	}
	
	/*
	 * Returns all users of a project except for user with id = $userId
	 */
	public function otherUsers($userId){
		return $this->belongsToMany('User', 'users_projects', 'project_id', 'user_id')->where('user_id','!=',$userId)->get();
	}

	/*
	 *	Adds a user to the project, and creates a 'None' stress for the user
	 */
	public function addUser($userId){
		$time = date("Y-m-d H:i:s", strtotime(time()));
		DB::table('users_projects')->insert(
				array('user_id' => $userId, 'project_id' => $this->id, 'updated_at'  => $time, 'created_at' => $time)
		);
		DB::table('stress')->insert(
				array('user_id' => $userId, 'project_id' => $this->id, 'stress_level' => 0, 'updated_at'  => $time, 'created_at' => $time)
		);
		return 0;
	}


	/*
	 *	Counts the tasks for the project
	 */
	public function countTasks(){
		return count($this->tasks()->get());
	}
	/*
	 *	Counts the milestones for this project
	 */
	public function countMilestones(){
		return count($this->milestones()->get());
	}
	/*
	 *	Count the acknowledgement of posts for this project
	 */
	public function countAck(){
		$totalAck = 0;
		foreach($this->posts()->get() as $post){
			$totalAck+= count($post->acknowledgements()->get())."<br>";
		}
		return $totalAck;
	}
	
	public static $factory = array(
	  'Pid' => 'integer',
	  'Pname' => 'string',
	);

}