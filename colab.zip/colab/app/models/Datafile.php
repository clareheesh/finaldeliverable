<?php

class Datafile extends Eloquent{

	protected $primaryKey = 'id';

	public $incrementing = true;
    
    
    // DEFINE RELATIONSHIPS --------------------------------------------------
    
	public function project(){
		return $this->belongsTo('Project', 'project_id', 'id');
	}

	public function user(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
}