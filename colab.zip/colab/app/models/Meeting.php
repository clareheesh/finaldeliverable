<?php

class Meeting extends Eloquent{

	protected $primaryKey = 'id';

	public $incrementing = true;
    
    
    // DEFINE RELATIONSHIPS --------------------------------------------------
    
	public function project(){
		return $this->belongsTo('Project', 'project_id', 'id');
	}
}