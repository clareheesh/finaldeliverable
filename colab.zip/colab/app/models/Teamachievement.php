<?php

class Teamachievement extends Eloquent{

	protected $primaryKey = 'id';

	
	//	------Database relationships---------------------//
	public function projects(){
		return $this->belongsToMany('Project', 'projects_teamachievements', 'project_id', 'id')->withTimestamps();
	}


}