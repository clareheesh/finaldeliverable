<?php

class Message extends Eloquent{

	protected $table = 'messages';
	protected $primaryKey = 'id';

	public $incrementing = true;
	
	//	------Database relationships---------------------//
	public function users(){
		return $this->belongsTo('User', 'user_id', 'id');
	}
	
	/*
	 * Get the user who sent the message
	 */
	public function getUser(){
		return $this->users()->first();
	}
	
}