<?php

class Post extends Eloquent{

	protected $primaryKey = 'id';

	public $incrementing = true;
	
	//--Define Relationships------------------------------//
	public function project(){
		return $this->belongsTo('Project', 'project_id', 'id');
	}
	public function comments(){
		return $this->hasMany('Comment', 'post_id', 'id');
	}
	public function acknowledgements(){
		return $this->hasMany('Acknowledgement', 'post_id', 'id');
	}
	
	/*
	 * Return the comments of the post
	 */
	public function getComments(){
		return $this->comments()->get();
	}

	//Returns the acknowledgement of a user if it exists
	public function hasAcknowledged($user_id){
		return $this->acknowledgements()->where('user_id','=',$user_id)->first();
	}
	
}