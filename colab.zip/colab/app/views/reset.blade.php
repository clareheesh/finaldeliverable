<!DOCTYPE html>
<html>
<head>
	<title>Reset your password | COLAB | Team collaboration App | by The Latest Tricks</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="shortcut icon" href="img/favicon.ico">
	
    <!-- Styles -->
    <link href="css/bootstrap/bootstrap.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/compiled/bootstrap-overrides.css" type="text/css" />
    <link rel="stylesheet" type="text/css" href="css/compiled/theme.css" />

    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css' />

    <link rel="stylesheet" href="css/compiled/index.css" type="text/css" media="screen" /> 
    <link rel="stylesheet" href="css/compiled/sign-up.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/compiled/fonts.css" type="text/css" media="screen" /> 
    <link rel="stylesheet" href="css/compiled/reset.css" type="text/css" media="screen" />  
    <link rel="stylesheet" type="text/css" href="css/lib/animate.css" media="screen, projection" />    

    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body class="pull_top">
    
    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle pull-right" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="{{ URL::route('home')}}" class="navbar-brand"><div></div></a>
            </div>

            <div class="collapse navbar-collapse navbar-ex1-collapse" role="navigation">
                <ul class="nav navbar-nav navbar-right">
                    <!--<li class="active"><a href="{{ URL::route('home')}}">HOME</a></li>-->
                    <li><a href="">FEATURES</a></li>
                    <li><a href="{{ URL::route('about')}}">ABOUT US</a></li>
                   <!-- <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">PAGES <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="features.html">Features</a></li>
                            <li><a href="services.html">Services</a></li>
                            <li><a href="portfolio.html">Portfolio</a></li>
                            <li><a href="portfolio-item.html">Portfolio Item</a></li>
                            <li><a href="coming-soon.html">Coming Soon</a></li>
                            <li><a href="{{ URL::route('login')}}">Sign in</a></li>
                            <li><a href="{{ URL::route('signup')}}">Sign up</a></li>
                            <li><a href="backgrounds.html">Backgrounds</a></li>
                        </ul>
                    </li>
                    <li><a href="pricing.html">PRICING</a></li>
                    <li><a href="blog.html">BLOG</a></li>-->
                    <li><a href="">CONTACT</a></li>
                    <li><a href="{{ URL::route('signup')}}">SIGN UP</a></li>
                    <li><a href="{{ URL::route('login')}}">LOG IN</a></li>

                </ul>
            </div>
        </div>
    </div>
<!-- Sign In Option 1 -->
    <div id="sign_up1">
        <div class="container">
            <div class="row">
                <div class="col-md-12 header">
                    <h4>Forgot your password?</h4>
                    <p>
                        Tip: Use a combination of numbers and letters to make your password safer.</p>

                    <!--<div class="col-md-4 social">
                        <a href="#" class="circle facebook">
                            <img src="img/face.png" alt="">
                        </a>
                         <a href="#" class="circle twitter">
                            <img src="img/twt.png" alt="">
                        </a>
                         <a href="#" class="circle gplus">
                            <img src="img/gplus.png" alt="">
                        </a>
                    </div>-->
                </div>

               <!-- <div class="col-sm-3 division">
                    <div class="line l"></div>
                    <span>or</span>
                    <div class="line r"></div>
                </div>

                <div class="col-md-12 footer">
                    <form class="form-inline">
                        <input type="text" placeholder="Email" class="form-control">
                        <input type="password" placeholder="Password" class="form-control">
                        <input type="submit" value="sign in">
                    </form>
                </div>

                <div class="col-md-12 proof">
                    <div class="col-md-6 remember">
                        <label class="checkbox">
                            <input type="checkbox"> Remember me
                        </label>
                        <a href="reset.html">Forgot password?</a>
                    </div>

                    <div class="col-md-6">
                        <div class="dosnt">
                            <span>Don’t have an account?</span>
                            <a href="{{ URL::route('signup')}}">Sign up</a>
                        </div>
                    </div>
                </div>-->
            </div>
        </div>
    </div>

   <div id="reset_pwd" class="reset_page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 box_wrapper">
                    <div class="col-md-12">
                        <div class="box">
                            <div class="head">
                                <h4>Enter your email address below to receive instructions on how to reset your password.</h4>
                                <div class="line"></div>
                            </div>
                            <div class="form">
                                <form>
                                    <input type="text" placeholder="Email address" class="control-form" />
                                    <input type="submit" value="Reset password"/>
                                </form>
                            </div>
                        </div>
                    </div>
                    <p class="already">Know your password? <a href="{{ URL::route('login')}}"> Log in</a></p>
                </div>
            </div>
        </div>
    </div>

    <!-- starts footer -->
    <footer id="footer">
        <div class="container">
            <div class="row sections">
                <div class="col-sm-3 testimonials">
                    <h3 class="footer_header">
                        Colab
                    </h3>
                    <div class="wrapper info">
                       <ul class="">
                           <li>
                               <a href="#">Features</a>
                            </li>
                            <li>
                               <a href="{{ URL::route('about')}}">About us</a>
                            </li>
                            <li>
                               <a href="#">Contact</a>
                           </li>
                           <li>
                               <a href="{{ URL::route('signup')}}">Sign up</a>
                           </li>
                           <li>
                               <a href="{{ URL::route('login')}}">Log in</a>
                           </li>
                       </ul>
                        
                    </div>
                   
                </div>
                <div class="col-sm-4 testimonials">
                    <h3 class="footer_header">
                        The Latest Tricks
                    </h3>
                    <div class="wrapper">
                        <div class="quote">
                            
                            The Latest Tricks is a consultancy firm helping organisations gain a business advantage by 
                        	using the latest technologies and techniques. The company focuses on complex systems, User 
                        	Experience designs, digital engagement, social media and affect management.
  
                            <a href="http://thelatesttricks.com/" target="_blank">Learn more</a>
                          
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-5 contact">
                    <h3 class="footer_header">
                        Contact
                    </h3>
                    <form action="#" method="post">
                        <input type="text" placeholder="Your name" />
                        <input type="text" placeholder="Your email" />
                        <textarea rows="3" placeholder="Message"></textarea>
                        <input type="submit" value="Send" />
                    </form>
                </div>
            </div>
            <div class="row credits">
                <div class="col-md-12">
                    <div class="row social">
                        <div class="col-md-12">
                            <a href="https://www.facebook.com/ColabSynergy?fref=nf" class="facebook">
                                <span class="socialicons ico1"></span>
                                <span class="socialicons_h ico1h"></span>
                            </a>
                            <a href="https://twitter.com/CoLabWebApp" class="twitter">
                                <span class="socialicons ico2"></span>
                                <span class="socialicons_h ico2h"></span>
                            </a>
                            <a href="https://plus.google.com/114954676985271116931/posts" class="gplus">
                                <span class="socialicons ico3"></span>
                                <span class="socialicons_h ico3h"></span>
                            </a>
                        </div>
                    </div>
                    <div class="row copyright">
                        <div class="col-md-12">
                            © 2014 The Latest Tricks. All rights reserved. Powered by <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>. Theme by <a href="https://wrapbootstrap.com/theme/clean-canvas-business-theme-WB02634G3" target="_blank">Detail Canvas</a>.
                        </div>
                    </div>
                </div>            
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/theme.js"></script>

    <script type="text/javascript" src="js/index-slider.js"></script>	
</body>
</html>