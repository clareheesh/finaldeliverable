@extends('projects.layout-user')


@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Messages</h1>

					<ol class="breadcrumb">
						<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						<li class="active"><i class="fa fa-tasks fa-fw"></i>Messages</li>
					</ol>
                </div>    
            </div>
			
			<!-- New Message-->
			<div class="row">
			
				<div class="col-md-2">
					<div class="chat-panel panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-envelope fa-fw"></i>Messages
						</div> <!-- /.panel-heading" -->
					
						<div class="panel-body">
						
							<ul class="nav nav-pills">
								<li class="active btn-block"><a href="#_new-message" data-toggle="tab">New Message</a></li>
								@foreach ($messageLobbies as $index=>$lobby)
									<li class="btn-block">
										<a href="#_{{$lobby->id}}" data-toggle="tab">
											@foreach ($lobby->getOtherUsers(Auth::user()->id) as $index=>$otherUser)
									
													@if($index == ( count( $lobby->getOtherUsers(Auth::user()->id)) -1 ))
														{{$otherUser->first_name}}
													@else
														{{$otherUser->first_name}},
													@endif
									
											@endforeach
										
										@if ($lobby->countMsgUser(Auth::user()->id)>0)
											<span class="badge pull-right">
												{{$lobby->countMsgUser(Auth::user()->id)}}
											</span>
										@endif
										
										</a>
									</li>
								@endforeach
							</ul>
						</div> <!-- /.panel-body -->
						
						<div class="panel-footer">
							<p class="fade">Be invisible</p>
						</div>
					
					</div> <!-- /.panel -->
				</div> <!-- /.col-md-2 -->
					
				<div class="col-md-10 collapse fade in active" id="_new-message">
					<div class="chat-panel panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-envelope fa-fw"></i>
							New Message
						</div>
						<div class="panel-body">
							@if($errors->first('to'))
                                {{ Alert::danger('You must select at least one recipient')}}
                            @endif
                            
							{{ Form::open(array('url' => 'projects/newmessage', 'role'=>'form', 'method' => 'POST', 'name'=>'comment')) }}
								@foreach ($otherUsers as $user)
									<label class="checkbox-inline">
										<input name="to[]" value="{{$user->id}}" type="checkbox"> {{$user->first_name. " ".$user->last_name }}
									</label>
									<br />
								@endforeach 
								
							</div>
							<!-- /.panel-body -->
							
							<div class="panel-footer">
						
								<div class="input-group">
									{{ Form::text('comment', Input::old('comment'), array('class' => 'form-control input-sm', 'placeholder' => 'Send Message')) }}
							
									<span class="input-group-btn">
										{{ Form::submit('Send', array('class' => 'btn btn-warning btn-sm')) }}
									</span>
								</div>
								<!-- /.input-group -->
							</div>
							<!-- /.panel-footer -->
							
						{{ Form::close() }}
						
					</div>
					<!-- /.panel -->
				</div>
				<!-- /.col-lg-10 -->
								
			
				<!--Current Messages-->	
						
				@foreach ($messageLobbies as $index=>$lobby)

					<div class="col-md-10 collapse fade" id="_{{$lobby->id}}">
						<div class="chat-panel panel panel-default">
							<div class="panel-heading">
								<i class="fa fa-comments fa-fw"></i>
								@foreach ($lobby->getOtherUsers(Auth::user()->id) as $index=>$otherUser)
									@if($index== ( count( $lobby->getOtherUsers(Auth::user()->id)) -1 ))
										{{$otherUser->first_name}}
									@else
										{{$otherUser->first_name}},
									@endif
								@endforeach
							</div>
							<div class="panel-body">
								<ul class="chat">
								
									@foreach ($lobby->getMessages() as $message)
										@if($message->user_id == (Auth::user()->id))
											<li class="right clearfix">									
												<span class="chat-img pull-right">
													{{ HTML::image('uploads/display_pictures/'.$message->getUser()->display_picture, 'Display Picture', array( 'class'=>'img-circle', 'width' => 50, 'height' => 50 )) }}
												</span>
												<div class="chat-body clearfix">
													<div class="header">
														
														<small class=" text-muted">
															<i class="fa fa-clock-o fa-fw"></i> {{$message->created_at->diffForHumans()}}
														</small>
														<strong class="pull-right primary-font">{{$message->getUser()->first_name}}</strong> 
													</div>
													<p>
														{{$message->contents}}
													</p>
												</div>
											</li>
										@else
											<li class="left clearfix">									
												<span class="chat-img pull-left">
													{{ HTML::image('uploads/display_pictures/'.$message->getUser()->display_picture, 'Display Picture', array( 'class'=>'img-circle', 'width' => 50, 'height' => 50 )) }}
												</span>
												<div class="chat-body clearfix">
													<div class="header">
														<strong class="primary-font">{{$message->getUser()->first_name}}</strong> 
														<small class="pull-right text-muted">
															<i class="fa fa-clock-o fa-fw"></i> {{$message->created_at->diffForHumans()}}
														</small>
													</div>
													<p>
														{{$message->contents}}
													</p>
												</div>
											</li>
										@endif
									@endforeach
								</ul>

							</div>
							<!-- /.panel-body -->
							
							<div class="panel-footer">
									
									<!-- Reply -->
									{{ Form::open(array('url' => 'projects/sendmessage', 'role'=>'form', 'method' => 'POST', 'name'=>'comment', 'class' => 'input-group')) }}
										{{ Form::hidden('lobby', $lobby->id)}}															
										{{ Form::text('comment', Input::old('comment'), array('class' => 'form-control input-sm', 'placeholder' => 'Type your message here...')) }}
										<span class="input-group-btn">
											{{ Form::submit('Send', array('class' => 'btn btn-warning btn-sm')) }}
										</span>
										
									{{ Form::close() }}
								
								<!-- /.input-group -->
							</div>
							<!-- /.panel-footer -->

							
						</div>
						<!-- /.chat-panel -->
					</div>
					<!-- /.col-lg-10 -->
				@endforeach
				
			</div>
			<!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

@stop