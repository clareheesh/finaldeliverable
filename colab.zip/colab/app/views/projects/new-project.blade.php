@extends('projects.layout-user')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">New Project</h1>
					<ol class="breadcrumb">
						<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						<li class="active"><i class="fa fa-folder fa-fw"></i>New Project</li>
					</ol>
                </div>
            </div>
            
            <div class="row">
            	<div class="col-lg-8">
            		<div class="panel panel-default">
            			<div class="panel-heading">
            				<i class="fa fa-folder fa-fw"> </i>New Project
            			</div>
            			<!-- /.panel-heading -->
            			<div class="panel-body">
            			
            				{{ Form::open(array('url' => 'projects/new', 'role'=>'form')) }}
							
							<!--Project Name-->
							<div class="form-group">
								@if($errors->first('name'))
									{{ Alert::danger($errors->first('name'))}}
								@endif
							
								<label>Project Name</label>
								{{ Form::text('name', Input::old('name'), array('class' => 'form-control input-sm')) }}
							</div>
	
	
							<!--Project Description-->
							<div class="form-group">
								@if($errors->first('description'))
									{{ Alert::danger($errors->first('description'))}}
								@endif
							
								<label>Project Description</label>
								{{ Form::textarea('description', Input::old('description'), array('class' => 'form-control input-sm', 'rows'=>'3')) }}
							</div>
			
							<!--Project Start date-->
							<div class="form-group input-group col-xs-3">
								@if($errors->first('start_date'))
									{{ Alert::danger($errors->first('start_date'))}}
								@endif
							
								<label>Start Date</label>
								<div class="form-group input-group">
									<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
									{{ Form::text('start_date', Input::old('start_date'), array('class' => 'form-control datepkr input-sm')) }}
								</div>
							</div>

							<!--Project End date-->
							<div class="form-group input-group col-xs-3">
			
								@if($errors->first('end_date'))
									{{ Alert::danger($errors->first('end_date'))}}
								@endif
							
								<label>End Date</label>
								<div class="form-group input-group">
									<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
									{{ Form::text('end_date', Input::old('end_date'), array('class' => 'form-control datepkr input-sm')) }}
								</div>
							</div>
			
							<!--End Form-->			
							{{ Form::submit('Create', array('class' => 'btn btn-success btn-sm')) }}
							<button type="reset" class="btn btn-primary btn-sm">Reset </button>
							{{ Form::close() }}
            				
            			</div>
            			<!-- /.panel-body -->
            		</div>
            		<!-- /.panel -->            	
            	</div>
            	<!-- /.col-lg-8 -->
            	
            	<div class="col-lg-4">
            		<div class="panel panel-primary">
            			<div class="panel-heading">
            				<i class="fa fa-question-circle fa-fw"></i> Help
            			</div>
            			<!-- /.panel-heading -->
            			
            			<div class="panel-body">
            			
            				<h4>What is a Project?</h4>
                            
                            <p><small>A project is built up of a number of important milestones and tasks. A new project should be created whenever you are 
                            working with new group members on something unrelated to your other projects. If you want to add a new goal or important feature to an existing project, create a new milestone instead.</small></p>
                            
                            <br />
                            
                            <h4>What details should I give my project?</h4>
                            
                            <p><small>It helps to ensure your project has a unique name, so that you won't have trouble navigating to it or referencing it. A project description helps other group members understand the purpose of a project, and a 
                            start date and end date help to set clear goals and deadlines from the beginning.</small></p>
                            
                            <!-- /.list-group -->
            			
            			</div>
            			<!-- /.panel-body -->
            		</div>
            		<!-- /.panel-primary -->
            	</div>
            	<!-- /.col-lg-4-->
        	</div>
        	<!-- /.row -->
        	
        	
			
			
			
        </div>

@stop