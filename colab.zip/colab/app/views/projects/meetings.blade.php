@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Group Meetings</h1>

					<ol class="breadcrumb">
						<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						<li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
						<li class="active"><i class="fa fa-tasks fa-fw"></i>Group Meetings</li>
					</ol>
                </div>
            </div>
			
			<!--Existing Meetings-->
			<div class="row">
				<div class="col-lg-8">
					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-book fa-fw"></i>Meetings
						</div>
			
						<div class="panel-body">		
							
							@if (count($meetings) >= 1)
							<div class="table-responsive">
								<table class="table table-hover" id="dataTables-filelist">
									<thead>
										<tr>
											<th>Date</th>
											<th>Time</th>
											<th>Description</th>
											
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										@foreach($meetings as $meeting)
											<tr class="odd gradeX">
												<td>{{  date("D dS M Y", strtotime($meeting->start_date))}}</td>
												<td>{{  date("g:i a", strtotime($meeting->start_time)) }} - {{ date("g:i a", strtotime($meeting->end_time))}}</td>
												<td>{{ $meeting->description}}</td>
												<td class="center">
													{{ Form::model($meeting, array(
														'url' => 'projects/project/'.$project->id.'/meeting/'.$meeting->id.'/delete', 
														'role'=>'form', 
														'method' => 'DELETE', 
														'name'=>'deleteMeeting'
													)) }} 

													{{ Form::submit('DELETE', array(
														'class' => 'btn btn-danger btn-xs', 
														'name'=>'delete_meeting'
													)) }}

													{{ Form::close() }}
												</td>
											</tr>
										@endforeach
									</tbody>
								</table>
							</div>
							@else
								{{ Alert::danger("No meetings found.")}}
							@endif
		
						</div>
					</div>
					<!-- /panel -->
				</div>	
				<!-- /.col-lg-8 -->		
				 <div class="col-lg-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-question-circle fa-fw"></i> Help
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <h4>What is a meeting?</h4>
                            <small>Creating a meeting allows you to let other team members know when you need to meet in person to discuss one or many issues.</small>
                            
                            <br />
                            
                            <h4>What information should it include?</h4>
                            <small>A meeting should have include the date it will occur, a start time and an estimated end time. It's also important to mention what topics you wish to discuss in the description so other team members can bring proper equipment and prepare.</small>
	
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-4 -->
			</div>
			
			<!--New Meeting-->
			<div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-flag fa-fw"></i> Create a new meeting
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							
							{{ Form::open(array('url' => 'projects/project/'.$project->id.'/meetings', 'role'=>'form')) }} 

							
                            <div class="form-group input-group col-xs-3">
								<label for="">Meeting Date</label>
								{{ Form::text('start_date', Input::old('start_date'), 
								array('class' => 'form-control datepkr input-sm', 'placeholder'=>'Date', 'id'=>'start_date')) }}
								<div>
								@if($errors->first('start_date'))
									{{ Alert::danger($errors->first('start_date'))}}
								@endif
								</div>
                            </div>   

							<div class="form-group input-group col-xs-3">
								<label for="start_time">Start Time</label>
								<div>
									<select class="form-control input-sm" name="start_hour" style="width:75px;">
										@for($i = 1; $i <= 12; $i++)
											@if ($i == 9)
												<option value="{{ $i }}" selected>{{$i}}</option>
											@else
												<option value="{{ $i }}">{{$i}}</option>
											@endif
										@endfor
									</select>
									<select class="form-control input-sm" name="start_minute" style="width:75px;">
										@for($i = 0; $i < 60; $i+=5)
											@if ($i<10)
												<option value="{{ $i }}">0{{$i}}</option>
											@else
												<option value="{{ $i }}">{{$i}}</option>
											@endif
										@endfor
									</select>
									<select class="form-control input-sm" name="start_suffix" style="width:75px;">
										<option value="AM" selected>AM</option>
										<option value="PM">PM</option>
									</select>
								</div>
                            </div>
							
							<div class="form-group input-group col-xs-3">
								<label for="start_time">End Time</label>
								<div>
									<select class="form-control input-sm" name="end_hour" style="width:75px;">
										@for($i = 1; $i <= 12; $i++)
											@if ($i == 5)
												<option value="{{ $i }}" selected>{{$i}}</option>
											@else
												<option value="{{ $i }}">{{$i}}</option>
											@endif
										@endfor
									</select>
									<select class="form-control input-sm" name="end_minute" style="width:75px;">
										@for($i = 0; $i < 60; $i+=5)
											@if ($i<10)
												<option value="{{ $i }}">0{{$i}}</option>
											@else
												<option value="{{ $i }}">{{$i}}</option>
											@endif
										@endfor
									</select>
									<select class="form-control input-sm" name="end_suffix" style="width:75px;">
										<option value="AM">AM</option>
										<option value="PM" selected>PM</option>
									</select>
								</div>
                            </div>
							
							<div class="form-group">
								<label>Description</label>{{ $errors->first('description') }}
							   {{ Form::textarea('description', Input::old('description'), array('class' => 'form-control input-sm', 'rows'=> '3')) }}
							   @if($errors->first('description'))
									{{ Alert::danger($errors->first('description'))}}
								@endif
							</div>    

                            {{ Form::submit('Create', array('class' => 'btn btn-success btn-sm')) }}
                            <button type="reset" class="btn btn-primary btn-sm">Reset </button>
							{{ Form::close() }}

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-8 -->
               
            </div>
            <!-- /.row -->
			
        </div>
        <!-- /#page-wrapper -->

@stop