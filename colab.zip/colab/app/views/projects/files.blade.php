@extends('projects.layout')
@section('content')
<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Group Files</h1>
			<ol class="breadcrumb">
				<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				<li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
				<li class="active"><i class="fa fa-archive fa-fw"></i>Group Files</li>
			</ol>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-8">
			<div class="panel panel-default">
				
				<div class="panel-heading">
					<i class="fa fa-archive fa-fw"></i>Files
				</div>
				<!-- /.panel-heading -->
				<div class="panel-body">
					@if (count($files) >= 1)
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover" id="dataTables-example1">
							<thead>
								<tr>
									<th>File Name</th>
									<th>Description</th>
									<th>File Type</th>
									<th>File Size</th>
									<th>Uploaded By</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								@foreach($files as $file)
								<tr class="odd gradeX">
									<td>{{ $file->name}}</td>
									<td>{{ $file->description}}</td>
									<td>{{ $file->type}}</td>
									<td>{{ $file->size." B"}}</td>
									<!--<td>{{ $file->id}}</td>-->
									<td>
										{{$file->user->first_name." ".$file->user->last_name}}
									</td>
									<td class="center">
										{{ Form::model($file, array(
											'url' => 'projects/project/'.$project->id.'/file/'.$file->id.'/delete',
											'role'=>'form',
											'method' => 'DELETE',
											'name'=>'deleteFile',
											'style' => 'display: inline;'
										)) }}
										
										{{ Form::submit('Delete', array(
											'class' => 'btn btn-danger btn-xs',
											'name'=>'delete_file'
										)) }}
										
										{{ Form::close() }}
										
										{{ Form::model($file, array(
											'url' => 'projects/project/'.$project->id.'/file/'.$file->id.'/download',
											'role'=>'form',
											'method' => 'GET',
											'name'=>'downloadFile',
											'style' => 'display: inline;'
										)) }}
										
										{{ Form::submit('Download', array(
											'class' => 'btn btn-primary btn-xs',
											'name'=>'download_file',
											'style' => 'display: inline;'
										)) }}
										
										{{ Form::close() }}
									</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
					<!-- /.table-responsive -->
					@else
						{{ Alert::danger("No files found.")}}
					@endif
					
				</div>
				<!-- /.panel-body -->
			</div>
			<!-- /.panel panel-default -->
		</div>
		<!-- /.col-lg-8 -->
		
		<div class="col-lg-4">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<i class="fa fa-plus fa-fw"> </i>Upload File
				</div>
				<!-- /.panel-heading -->
				<div class="panel-body">
					{{ Form::open(array('url' => 'projects/project/'.$project->id.'/files', 'role'=>'form', 'files' => true)) }}
					<div class="form-group">{{ Form::label('description', 'File Description') }}</div>
					<div class="form-group">{{ Form::text('description', Input::old('description'), array('class'=>'form-control input-sm')) }}</div>
					<div class="form-group">
						{{ Form::label('file', 'File') }}
						{{ Form::input('file', 'filedata', null) }}
					</div>
					
					{{ Form::submit('Create', array('class' => 'btn btn-success btn-sm btn-block')) }}
					{{ Form::close() }}
				</div>
				<!-- /.panel-body -->
			</div>
			<!-- /.panel -->
		</div>
		<!-- /.col-lg-4 -->
	</div>
	<!-- /.row -->	
</div>
<!-- /#page-wrapper -->
@stop