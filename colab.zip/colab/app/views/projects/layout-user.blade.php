<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="{{ URL::to('img/favicon.ico')}}">

    <title>User Account | COLAB | Team collaboration App | by The Latest Tricks</title>

    <!-- Core CSS - Include with every page -->
    {{ HTML::style('projects/css/bootstrap.css') }}
    {{ HTML::style('projects/font-awesome/css/font-awesome.css') }}

    <!-- Page-Level Plugin CSS - Dashboard -->
    {{ HTML::style('projects/css/plugins/morris/morris-0.4.3.min.css') }}
    {{ HTML::style('projects/css/plugins/timeline/timeline.css') }}

    <!-- SB Admin CSS - Include with every page -->
    {{ HTML::style('projects/css/sb-admin.css') }}

    <!-- Datepicker CSS-->
    {{ HTML::style('projects/css/datepicker.css') }}

    <!-- Page-Level Plugin CSS - Tables -->
    {{ HTML::style('projects/css/plugins/dataTables/dataTables.bootstrap.css') }}

    <!-- Page-Level Plugin CSS - Buttons -->
    {{ HTML::style('projects/css/plugins/social-buttons/social-buttons.css') }}
	
	<!--SB Admin tempalte-->
	{{ HTML::style('projects/css/sb-admin2.css') }}
	
	    <!-- Core Scripts - Include with every page -->
    {{ HTML::script('projects/js/jquery-1.10.2.js') }}
    {{ HTML::script('projects/js/bootstrap.min.js') }}
    {{ HTML::script('projects/js/plugins/metisMenu/jquery.metisMenu.js') }}

    <!-- Datepicker Scripts -->
    {{ HTML::script('projects/js/bootstrap-datepicker.js') }}

    <!-- Page-Level Plugin Scripts - Dashboard -->
    {{ HTML::script('projects/js/plugins/morris/raphael-2.1.0.min.js') }}
    {{ HTML::script('projects/js/plugins/morris/morris.js') }}

     <!-- Page-Level Plugin Scripts - Tables -->
    {{ HTML::script('projects/js/plugins/dataTables/jquery.dataTables.js') }}
    {{ HTML::script('projects/js/plugins/dataTables/dataTables.bootstrap.js') }}

    <!-- SB Admin Scripts - Include with every page -->
    {{ HTML::script('projects/js/sb-admin.js') }}    

    <!-- Page-Level Demo Scripts - Dashboard - Use for reference -->
    {{ HTML::script('projects/js/demo/dashboard-demo.js') }}

    <!-- Page-Level Demo Scripts - Datepicker - Use for reference -->
    <script>$('.datepkr').datepicker();</script>

     <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
		$(document).ready(function() {
			$('#dataTables-example1').dataTable();
		});
		
		

    </script>
    <script>
		
		function getXMLHttp()
		{
			var xmlHttp

			try
			{
				//Firefox, Opera 8.0+, Safari
				xmlHttp = new XMLHttpRequest();
			}
			catch(e)
			{
				//Internet Explorer
				try
				{
					xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
				}
				catch(e)
				{
					try
					{
						xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					catch(e)
					{
						alert("Your browser does not support AJAX!")
						return false;
					}
				}
			}
			return xmlHttp;
		}

		function MakeRequest()
		{
			var xmlHttp = getXMLHttp();

			xmlHttp.onreadystatechange = function()
			{
				if(xmlHttp.readyState == 4)
				{
					HandleResponse(xmlHttp.responseText);
				}
			}

			xmlHttp.open("GET", "{{ URL::route('categories')}}", true); 
			xmlHttp.send(null);
		}
		
		function HandleResponse(response)
		{
			document.getElementById('ResponseDiv').innerHTML = response;
		}
		
    </script>
	
	<!--Page Specific Scripts-->
	@yield('scripts')
	
	<script>
		function readMsg(){
			$( "#MsgResponseDiv" ).load( "{{ URL::route('readmsg', array('user' => Auth::user()->id))}}", function() {
				
			});
		}
	</script>

	<script>
		$(document).ready(function(){
		  $('a[href="' + window.location.hash + '"]').click()
		});
		
		// Change hash for page-reload
		$('.nav-pills a').on('shown', function (e) {
			window.location.hash = e.target.hash;
		})
	</script>
	
</head>

<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="{{ URL::route('dashboard')}}">{{HTML::image('projects/img/logo.png', "logo", array('height' => '30'))}}</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-left"><li>
                            <a href="{{ URL::route('dashboard')}}"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
  <li>
                            <a href="{{ URL::route('new')}}"><i class="fa fa-edit fa-fw"></i> New Project</a>
                        </li>
                    </ul>


            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" onclick='readMsg();'>
					
						<div id='MsgResponseDiv' style="display:inline;">
							@if($messageReader->countNotRead(Auth::user()->id)>0)
								{{Badge::important( $messageReader->countNotRead(Auth::user()->id))}}
							@endif
                        </div>
                        <i class="fa fa-envelope fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
						@if($messageReader->countAll(Auth::user()->id)>0)
							@foreach ($messageLobbies as $lobby)
								<li>
								<a href="{{URL::route('globalmessages')}}#_{{$lobby->id}}">
									<div>
										<strong>
											@foreach ($lobby->getOtherUsers(Auth::user()->id) as $index=>$otherUser)
												@if($index== ( count( $lobby->getOtherUsers(Auth::user()->id)) -1 ))
													{{$otherUser->first_name}}
												@else
													{{$otherUser->first_name}},
												@endif
											@endforeach
											@if ($lobby->countMsgUser(Auth::user()->id))
												({{$lobby->countMsgUser(Auth::user()->id)}})
											@endif
										</strong>
										<span class="pull-right text-muted">
											<em>{{$lobby->lastMessage()->created_at->diffForHumans()}}</em>
										</span>
									</div>
									<div>
										{{$lobby->lastMessage()->getUser()->first_name}}: {{$lobby->lastMessage()->contents}}
									</div>
								</a>
								</li>
							@endforeach
						@else
							<div style="color:#cccccc;" class="text-center">You have no messages</div>
						@endif
                        
                        <!--
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>-->
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="{{URL::route('globalmessages')}}">
                                <strong>Read All Messages</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-tasks fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-tasks">     
						@if (count($myTasks)>0)
							@foreach($myTasks as $myTask)
								  <li>
									   <a href="{{URL::route('project-status', array('Pid' => $myTask->getProject()->id))}}">
											<div>
												 <p>
													  <strong>{{ $myTask->name }}</strong>
													  <span class="pull-right text-muted">{{ $myTask->progress }}% Complete</span>
												 <p>
												 <div class="progress progress-striped active">
													<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="{{ $myTask->progress }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $myTask->progress }}%">
													<span class="sr-only">{{ $myTask->progress }}% Complete (success)</span>
												</div>
											</div>
										</div>
									</a>
								</li>
							 @endforeach
						@else
							<div style="color:#cccccc;" class="text-center">You have no tasks</div>
						@endif
                    </ul>
                    <!-- /.dropdown-tasks -->
                </li>
				
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="noteBtn" onclick='MakeRequest();'>
                        <div id='ResponseDiv' style="display:inline;">
                        @if(count(Notifynder::getNotRead(Auth::user()->id))>0)
                            {{Badge::important( count(Notifynder::getNotRead(Auth::user()->id)) )}}
                        @endif
                        </div>
                        <i class="fa fa-bell fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
							@if (count(Notifynder::getAll(Auth::user()->id))>0)
								@foreach(Notifynder::getAll(Auth::user()->id) as $notify)
								@if($notify->category_id==1)
									<li>
										<a href="{{$notify->url}}">
											<div>
												{{User::find($notify->from_id)->first_name}}
												{{$notify->body->text}}
											</div>
											<div>
												<span class="text-muted small">{{Project::find($notify->project_id)->name}}</span>
												<span class="pull-right text-muted small">{{$notify->created_at->diffForHumans() }}</span>
											</div>
										</a>
									</li>
									<li class="divider"></li>
								@else
									<li>
										<a href="{{$notify->url}}">
											<div>											
												{{$notify->body->text}}											
											</div>
											<div>
												<span class="text-muted small">{{Project::find($notify->project_id)->name}}</span>
												<span class="pull-right text-muted small">{{$notify->created_at->diffForHumans() }}</span>
											</div>
										</a>
									</li>
									<li class="divider"></li>
								@endif
								@endforeach
							@else
								<div style="color:#cccccc;" class="text-center">You have no notifications</div>
							@endif
                    </ul>
                    <!-- /.dropdown-alerts -->
                </li>
				
				
				
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="{{URL::route('profile')}}"><i class="fa fa-user fa-fw"></i> {{Auth::user()->display_name}}</a>
                        </li>
                        <li><a href="{{URL::route('settings')}}"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="{{ URL::route('logout')}}"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search"> 
                        	                           
 							<div class="panel panel-default">
                        		<div class="panel-heading">
                            		Projects
                        		</div>
                       		 	<!-- /.panel-heading -->
                       		 	
                       			<div class="panel-body">
                           			@foreach($projects as $project)
                                		<a class="btn btn-xs btn-block btn-outline btn-social btn-primary" href="{{ URL::to('projects/project/' . $project->id) }}">
											<i class="fa fa-folder"></i> {{ $project->name }}
										</a>
                            		@endforeach
                        		</div>
                    		</div>
                            <!-- /input-group -->
                        </li>
                    </ul>
                    <!-- /#side-menu -->
                    
                </div>
                <!-- /.sidebar-collapse -->
                
			</div>
            <!-- /.navbar-static-side -->
            
        </nav>

    @yield('content')

    </div>
    <!-- /#wrapper -->


	
	<!-- Page-Level Demo Scripts - Datepicker - Use for reference -->
    <script>$('.datepkr').datepicker();</script>
<script>

    function getXMLHttp()
{
  var xmlHttp

  try
  {
    //Firefox, Opera 8.0+, Safari
    xmlHttp = new XMLHttpRequest();
  }
  catch(e)
  {
    //Internet Explorer
    try
    {
      xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch(e)
    {
      try
      {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
      }
      catch(e)
      {
        alert("Your browser does not support AJAX!")
        return false;
      }
    }
  }
  return xmlHttp;
}

function MakeRequest()
{
  var xmlHttp = getXMLHttp();

  xmlHttp.onreadystatechange = function()
  {
    if(xmlHttp.readyState == 4)
    {
      HandleResponse(xmlHttp.responseText);
    }
  }

  xmlHttp.open("GET", "{{ URL::route('categories')}}", true);
  xmlHttp.send(null);
}
function HandleResponse(response)
{
  document.getElementById('ResponseDiv').innerHTML = response;
}
    </script>
</body>

</html>
