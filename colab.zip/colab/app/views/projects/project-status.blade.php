@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Project Status</h1>

                     <ol class="breadcrumb">
              <li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
              <li class="active"><i class="fa fa-tasks fa-fw"></i> Tasks &amp; Milestones &raquo; Project Status</li>
            </ol>
                </div>


                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
			
			@if($stressLevel>=3)
                {{Alert::info($stressTip)}}            
			@endif
			
            <div class="row">

                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-tasks fa-fw"></i> Milestone Progress
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                             @foreach($project->milestones as $milestone)
                               
                                @if($milestone->totalTasks()>0)
                                    <p>
                                        <strong><a href="{{URL::route('milestone-status', array('Pid' => $project->id, 'Mid'=> $milestone->id))}}">{{ $milestone-> name}}</a></strong>
                                        <span class="pull-right text-muted">{{ $milestone->progress()}}% Complete</span>
                                    </p>

                                    <div class="bs-example">
                                    @if($milestone->progress() ==100)
                                      <div class="progress progress-striped">
                                    @else
                                      <div class="progress progress-striped active">
									@endif
									
									@if($milestone->progress() >=75)
                                        <div class="progress-bar progress-bar-success" style="width: {{ $milestone->progress()}}%"></div>
									@elseif($milestone->progress() >=50)
                                        <div class="progress-bar progress-bar-info" style="width: {{ $milestone->progress()}}%"></div>	
									@elseif($milestone->progress() >=25)
                                        <div class="progress-bar progress-bar-warning" style="width: {{ $milestone->progress()}}%"></div>
									@else
                                        <div class="progress-bar progress-bar-danger" style="width: {{ $milestone->progress()}}%"></div>	
									@endif
                                      </div>
                                    </div>
                                @else

                                    <p>
                                        <strong><a href="{{URL::route('milestone-status', array('Pid' => $project->id, 'Mid'=> $milestone->Mid))}}">{{ $milestone-> Mname}}</a></strong>
                                        <span class="pull-right text-muted">0% Complete</span>
                                    </p>

                                    <div class="bs-example">

                                      <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-success" style="width: 0%"></div>
                                      </div>
                                    </div>

                                @endif
                            @endforeach


                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                   <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-question-circle fa-fw"></i> Help
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <h4>What is a Milestone Progress?</h4>
                            
                            <p><small>To see how much the milestone has done and click to see the task performance.</small></p>
<br>
                            <h4>Stress Level?</h4>
                            
                            <p><small>Different colours represent different stress level</small></p>
                            <ul>
                            <li><small>Green: neutral - no effect on stress</small></li>
                            <li><small>Blue: barely noticeable stress </small></li>
                            <li><small>Orange: a bit stressed - offer support </small></li>
                            <li><small>Red: stressful - approach with caution</small></li>
                            </ul>

                            
                            
                            <!-- /.list-group -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
<br><br>

                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-warning fa-fw"></i> Individual Stress Level
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                          <div class="stressalert">
                            
                            @foreach($otherUsers as $otherUser)
                                @if($otherUser->stressInProject($project->id)->stress_level == 0)
                                     <div class="alert alert-success"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "Not stressed at all"</div>
                                @elseif($otherUser->stressInProject($project->id)->stress_level == 1)
                                    <div class="alert alert-info"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "I have low stress"</div>
                                @elseif($otherUser->stressInProject($project->id)->stress_level == 2)
                                    <div class="alert alert-info"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "Average stress level"</div>
                                @elseif($otherUser->stressInProject($project->id)->stress_level == 3)
                                    <div class="alert alert-warning"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "My stress is high"</div>
                                @else
                                     <div class="alert alert-danger"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "Super crazy stressed"</div>
                                @endif
                            @endforeach
                   
                    
                    </div>

                        </div>
                    </div>
                </div>


                <div class="col-lg-4">
					@if($groupStress == 0)
						<div class="panel panel-success">
							<div class="panel-heading">
								Current Team Stress Level: None	
							</div>
							<!-- /.panel-heading -->
							<div class="panel-body">                          
								<p>Tip: Find ways to balance the amount of work load across the team.</p>                               
								<!-- /.list-group -->
							</div>
							<!-- /.panel-body -->
						</div>
						
					@elseif($groupStress == 1)
						<div class="panel panel-info">
							<div class="panel-heading">
								Current Team Stress Level: Low
							</div>
							<!-- /.panel-heading -->
							<div class="panel-body">                          
								<p>Tip: Find ways to balance the amount of work load across the team.</p>                               
								<!-- /.list-group -->
							</div>
							<!-- /.panel-body -->
						</div>
					@elseif($groupStress == 2)
						<div class="panel panel-info">
							<div class="panel-heading">
								Current Team Stress Level: Medium
							</div>
							<!-- /.panel-heading -->
							<div class="panel-body">                          
								<p>Tip: Find ways to balance the amount of work load across the team.</p>                               
								<!-- /.list-group -->
							</div>
							<!-- /.panel-body -->
						</div>
					@elseif($groupStress == 3)
						<div class="panel panel-warning">
							<div class="panel-heading">
								Current Team Stress Level: High
							</div>
							<!-- /.panel-heading -->
							<div class="panel-body">                          
								<p>Tip: Find ways to balance the amount of work load across the team.</p>                               
								<!-- /.list-group -->
							</div>
							<!-- /.panel-body -->
						</div>
					@elseif($groupStress == 4)
						<div class="panel panel-danger">
							<div class="panel-heading">
								Current Team Stress Level: Dangerous
							</div>
							<!-- /.panel-heading -->
							<div class="panel-body">                          
								<p>Tip: Find ways to balance the amount of work load across the team.</p>                               
								<!-- /.list-group -->
							</div>
							<!-- /.panel-body -->
						</div>
					@endif
                   
                </div>
 <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-8 -->
                
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

@stop