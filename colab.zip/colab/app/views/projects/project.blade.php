@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
			
		
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">News Feed</h1>
                      @if(Session::has('flash_notice'))
                        {{Alert::info(Session::get('flash_notice'))}}
                     @endif
                      @if(Session::has('flash_award'))
                        {{Alert::success(Session::get('flash_award'))}}
                     @endif
                 
                     <ol class="breadcrumb">
                          <li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                          <li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
                          <li class="active"><i class="fa fa-bullhorn fa-fw"></i> News Feed</li>
                     </ol>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
			
			@if($stressLevel>=3)
                {{Alert::info($stressTip)}}            
			@endif
			
            <div class="row">
                <div class="col-lg-12">
                   
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-clock-o fa-fw"></i> Timeline
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <ul class="timeline">
                               
                                @foreach(Post::where('project_id','=',$project->id)->orderBy('created_at', 'DESC')->get() as $post)
                                    @if($post->table=="tasks")
                                        @if($post->id%2)
                                            <li>
                                        @else
                                            <li class="timeline-inverted">
                                        @endif
                                            <div class="timeline-badge warning"><i class="fa fa-check"></i>
                                            </div>
                                            <div class="timeline-panel">
                                                <div class="timeline-heading">
                                                    <h4 class="timeline-title">
														@if (Task::find($post->TB_id))
															{{Task::find($post->TB_id)->user->first_name}} has finished <a href="{{URL::route('overview', array('Pid' => $project->id))}}" style="color:#3276b1">"{{Task::find($post->TB_id)->name}}"</a></h4>
														@endif
                                                    <p>
                                                        <small class="text-muted"><i class="fa fa-time"></i> {{ $post->created_at->diffForHumans() }}</small>
                                                    </p>
                                                </div>
                                                <div class="timeline-body">
                                                    <hr>
													@if (Task::find($post->TB_id))
                                                    {{ Form::open(array('url' => 'projects/project/'.$project->id.'/task/'.Task::find($post->TB_id)->id.'/acknowledge', 'role'=>'form', 'method' => 'POST', 'name'=>'acknowledge')) }}
														
														@if(Auth::user()!=Task::find($post->TB_id)->user)
															@if($post->hasAcknowledged(Auth::user()->id))
																<button type="submit" class="btn btn-primary btn-sm disabled">
																	<i class="fa fa-heart fa-lg fa-fw"></i> Acknowledged
																</button>  
															@else
																{{ Form::hidden('PSid', $post->id) }}
																<button type="submit" class="btn btn-primary btn-sm">
																	<i class="fa fa-heart fa-lg"></i> Say Good Job! 
																</button>  
															@endif
														@else
															People who like your work: 
														@endif
                                                    
														<strong>{{count($post->acknowledgements)}}</strong> <i class="fa fa-heart fa-lg" style="color:#d9534f"></i>
                                                    
                                                    {{ Form::close() }}
													@endif
													<!-- Existing comments-->
													<hr>
													
													<table class="table table-striped no-border">
													@foreach ($post->getComments() as $comment)
														<tr>
															<td><strong>{{$comment->getUser()->first_name." ".$comment->getUser()->last_name;}}</strong></td>
															<td>{{$comment->comment}}</td>
															<td><small class="text-muted">{{$comment->created_at->diffForHumans()}}</small></td>
														</tr>
													@endforeach
													</table>
													<!--New comment-->
													<p>
														{{ Form::open(array('url' => 'projects/project/'.$project->id.'/comment', 'role'=>'form', 'method' => 'POST', 'name'=>'comment')) }}
															{{ Form::hidden('post', $post->id)}}															
															{{ Form::text('comment', Input::old('comment'), array('class' => 'form-control input-sm', 'placeholder' => 'Write a comment')) }}
														{{ Form::close() }}
													</p>                                  
													
                                                </div>
                                            </div>
                                        </li>
                                    @elseif($post->table=="projects_teamachievements")
                                        @if($post->id%2)
                                            <li>
                                        @else
                                            <li class="timeline-inverted">
                                        @endif
                                            <div class="timeline-badge success"><i class="fa fa-thumbs-up"></i>
                                            </div>
                                            <div class="timeline-panel">
                                                <div class="timeline-heading">
                                                    <h4 class="timeline-title">
                                                       <span>{{Project::find($post->project_id)->name}}</span> has earned the achievement
                                                       <a href="{{URL::route('team-achievement', array('Pid' => $project->id))}}"style="color:#3276b1">"{{Teamachievement::find($post->TB_id)->name}}"</a> </h4>
                                                    <p>
                                                        <small class="text-muted"><i class="fa fa-time"></i> {{ $post->created_at->diffForHumans() }}</small>
                                                    </p>
                                                </div>
												
												<div class="timeline-body">
                                                    <!-- Existing comments-->
													<hr>
													
													<table class="table table-striped no-border">
													@foreach ($post->getComments() as $comment)
														<tr>
															<td><strong>{{$comment->getUser()->first_name." ".$comment->getUser()->last_name;}}</strong></td>
															<td>{{$comment->comment}}</td>
															<td><small class="text-muted">{{$comment->created_at->diffForHumans()}}</small></td>
														</tr>
													@endforeach
													</table>
													<!--New comment-->
													<p>
														{{ Form::open(array('url' => 'projects/project/'.$project->id.'/comment', 'role'=>'form', 'method' => 'POST', 'name'=>'comment')) }}	
															{{ Form::hidden('post', $post->id)}}
															{{ Form::text('comment', Input::old('comment'), array('class' => 'form-control input-sm', 'placeholder' => 'Write a comment')) }}
														{{ Form::close() }}
													</p>     
													
                                                </div>
                                            </div>
                                        </li>
									@elseif($post->table=="personalachievements")
                                        @if($post->id%2)
                                            <li>
                                        @else
                                            <li class="timeline-inverted">
                                        @endif
                                            <div class="timeline-badge success"><i class="fa fa-thumbs-up"></i>
                                            </div>
                                            <div class="timeline-panel">
                                                <div class="timeline-heading">
                                                    <h4 class="timeline-title">
                                                       <span>{{UserPersonalachievement::find($post->TB_id)->getUser()->first_name}}</span> has earned the achievement
                                                       <a href="{{URL::route('team-achievement', array('Pid' => $project->id))}}"style="color:#3276b1">"{{UserPersonalachievement::find($post->TB_id)->getAch()->name}}"</a> </h4>
                                                    <p>
                                                        <small class="text-muted"><i class="fa fa-time"></i> {{ $post->created_at->diffForHumans() }}</small>
                                                    </p>
                                                </div>
												
												<div class="timeline-body">
                                                    <!-- Existing comments-->
													<hr>
													
													<table class="table table-striped no-border">
													@foreach ($post->getComments() as $comment)
														<tr>
															<td><strong>{{$comment->getUser()->first_name." ".$comment->getUser()->last_name;}}</strong></td>
															<td>{{$comment->comment}}</td>
															<td><small class="text-muted">{{$comment->created_at->diffForHumans()}}</small></td>
														</tr>
													@endforeach
													</table>
													<!--New comment-->
													<p>
														{{ Form::open(array('url' => 'projects/project/'.$project->id.'/comment', 'role'=>'form', 'method' => 'POST', 'name'=>'comment')) }}	
															{{ Form::hidden('post', $post->id)}}
															{{ Form::text('comment', Input::old('comment'), array('class' => 'form-control input-sm', 'placeholder' => 'Write a comment')) }}
														{{ Form::close() }}
													</p>     
													
                                                </div>
                                            </div>
                                        </li>
										
										
                                    @elseif($post->table=="stress")
                                        @if($post->id%2)
                                            <li>
                                        @else
                                            <li class="timeline-inverted">
                                        @endif
                                            <div class="timeline-badge danger"><i class="fa fa-exclamation-triangle"></i>
                                            </div>
                                            <div class="timeline-panel">
                                                <div class="timeline-heading">
                                                    <h4 class="timeline-title">
														{{ Stress::find($post->TB_id)->user->first_name}}'s stress level is now 
														@if(Stress::find($post->TB_id)->stress_level==4)
															<a href="{{URL::route('project-status', array('Pid' => $project->id))}}" style="color:#3276b1"> "Going Insane"</a></h4>
														@elseif(Stress::find($post->TB_id)->stress_level==1)
															<a href="{{URL::route('project-status', array('Pid' => $project->id))}}" style="color:#3276b1"> "Low"</a></h4>
														@elseif(Stress::find($post->TB_id)->stress_level==2)
															<a href="{{URL::route('project-status', array('Pid' => $project->id))}}" style="color:#3276b1"> "Medium"</a></h4>
														@elseif(Stress::find($post->TB_id)->stress_level==3)
															<a href="{{URL::route('project-status', array('Pid' => $project->id))}}" style="color:#3276b1"> "High"</a></h4>
														@else
															<a href="{{URL::route('project-status', array('Pid' => $project->id))}}" style="color:#3276b1"> "None"</a></h4>
														@endif
                                                    <p>
                                                        <small class="text-muted"><i class="fa fa-time"></i> {{ $post->created_at->diffForHumans() }}</small>
                                                    </p>
                                                </div>
                                                <div class="timeline-body">
                                                    <!-- Existing comments-->
													<hr>
													
													<table class="table table-striped no-border">
													@foreach ($post->getComments() as $comment)
														<tr>
															<td><strong>{{$comment->getUser()->first_name." ".$comment->getUser()->last_name;}}</strong></td>
															<td>{{$comment->comment}}</td>
															<td><small class="text-muted">{{$comment->created_at->diffForHumans()}}</small></td>
														</tr>
													@endforeach
													</table>
													<!--New comment-->
													<p>
														{{ Form::open(array('url' => 'projects/project/'.$project->id.'/comment', 'role'=>'form', 'method' => 'POST', 'name'=>'comment')) }}	
															{{ Form::hidden('post', $post->id)}}
															{{ Form::text('comment', Input::old('comment'), array('class' => 'form-control input-sm', 'placeholder' => 'Write a comment')) }}
														{{ Form::close() }}
													</p>                                    
                                                </div>
                                            </div>
                                        </li>
										
										<!--New user post-->
										@elseif($post->table=="users")
											@if($post->id%2)
												<li>
											@else
												<li class="timeline-inverted">
											@endif
												<div class="timeline-badge info"><i class="fa fa-plus"></i>
												</div>
												<div class="timeline-panel">
													<div class="timeline-heading">
														<h4 class="timeline-title">
															{{ User::find($post->TB_id)->display_name }} has been added to the group!
														<p>
															<small class="text-muted"><i class="fa fa-time"></i> {{ $post->created_at->diffForHumans() }}</small>
														</p>
													</div>
													<div class="timeline-body">
														<!-- Existing comments-->
														<hr>
														
														<table class="table table-striped no-border">
														@foreach ($post->getComments() as $comment)
															<tr>
																<td><strong>{{$comment->getUser()->first_name." ".$comment->getUser()->last_name;}}</strong></td>
																<td>{{$comment->comment}}</td>
																<td><small class="text-muted">{{$comment->created_at->diffForHumans()}}</small></td>
															</tr>
														@endforeach
														</table>
														<!--New comment-->
														<p>
															{{ Form::open(array('url' => 'projects/project/'.$project->id.'/comment', 'role'=>'form', 'method' => 'POST', 'name'=>'comment')) }}	
																{{ Form::hidden('post', $post->id)}}
																{{ Form::text('comment', Input::old('comment'), array('class' => 'form-control input-sm', 'placeholder' => 'Write a comment')) }}
															{{ Form::close() }}
														</p>                                    
													</div>
												</div>
											</li>
										<!--End New User Post-->
                                    @endif
                                @endforeach

                            </ul>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-8 -->
               
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

@stop