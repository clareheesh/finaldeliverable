@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Project Overview</h1>
                    @if(Session::has('flash_notice'))
                        {{Alert::info(Session::get('flash_notice'))}}
                     @endif
                      @if(Session::has('flash_award'))
                        {{Alert::success(Session::get('flash_award'))}}
                     @endif


                     <ol class="breadcrumb">
						   <li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						   <li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
						   <li class="active"><i class="fa fa-tasks fa-fw"></i> Tasks &amp; Milestones &raquo; Overview</li>
					 </ol>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
			
			@if($stressLevel>=3)
                {{Alert::info($stressTip)}}            
			@endif
            
            <div class="row">
                <div class="col-lg-12">
                
                	<div class="panel panel-default">
                        <div class="panel-heading">
                              <i class="fa fa-eye fa-fw"></i> My tasks 
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example1">
                                    @if($myTasks->count()>0)
										<thead>
											<tr>
												<th>Task</th>
												<th>Description</th>
												<th>Assigned to</th>
												<th>Due Date</th>   
												<th>Progress</th>  
												<th>Actions</th>
											</tr>
										</thead>
										<tbody>
                                        {{ $errors->first('progress') }}
                                        @foreach($myTasks as $myTask)
                                        	@if($myTask->progress==100)
                                        		<tr class="odd gradeX" style="background-color:rgba(218,237,246,1);">
                                        	@else 
                                            	<tr class="odd gradeX">
                                            @endif
                                                <td>{{$myTask->name}}</td>
												<td>{{$myTask->description}}</td>
                                                <td><i class="fa fa-user fa-fw"></i> {{$user->first_name." ".$user->last_name}}</td>
                                                <td class="center">{{ date("M d",strtotime( $myTask->end_date)) }}</td>
                                                <td class="center" width="100px">
                                                    <div class="input-group col-xs-12">
                                                        @if($myTask->progress==100)
															<p>Completed</p>
                                                        @else
                                                            <!-- Form to update task with new Progress -->
                                                            {{ Form::model($myTask, array('url' => 'projects/project/'.$project->id.'/task/'.$myTask->id.'/edit_progress', 'role'=>'form', 'method' => 'PUT', 'name'=>'taskEdit')) }}
                                                                {{Form::select('progress', array(0 => '0%', 10 => '10%', 20 => '20%', 30 => '30%', 40 => '40%',50 => '50%',
                                                                60 => '60%',70 => '70%',80 => '80%',90 => '90%',100 => '100%'), Input::old('taskEdit'), array('class' => 'form-control input-sm', 'onchange'=>'this.form.submit();'))}}
                                                            {{Form::close()}}
                                                          
                                                        
                                                        @endif
                                                    </div>
                                                </a>
                                                <td class="center">
													<div style="float:left;margin-right:5px;">
														{{ Form::model($myTask, array(
															'url' => 'projects/project/'.$project->id.'/task/'.$myTask->id.'/edit', 
															'method' => 'get', 
															)) }} 

																{{ Form::submit('Edit', array(
																	'class' => 'btn editbtn btn-primary btn-xs'
																)) }}

														{{ Form::close() }}
													</div>
													<div style="float:left;margin-right:5px;">													
														{{ Form::model($myTask, array(
														'url' => 'projects/project/'.$project->id.'/task/'.$myTask->id.'/delete', 
														'role'=>'form', 
														'method' => 'DELETE', 
														'name'=>'deleteRule'
														)) }} 

															{{ Form::submit('DELETE', array(
																'class' => 'btn btn-danger btn-xs', 
																'name'=>'delete_rule'
															)) }}

														{{ Form::close() }}
													</div>
													<div style="float:left;margin-right:5px;">
														@if($myTask->progress==100)
															<!-- form to reopen task -->
															{{ Form::model($myTask, array('url' => 'projects/project/'.$project->id.'/task/'.$myTask->id.'/edit_progress', 'role'=>'form', 'method' => 'PUT', 'name'=>'taskReopen', 'style' => 'display: inline;')) }}
																{{ Form::hidden('progress', 50) }}
																{{ Form::submit('Reopen', array('class' => 'btn editbtn btn-success btn-xs')) }}
															{{ Form::close() }}
														@else
															<!-- Form to complete task -->
															{{ Form::model($myTask, array('url' => 'projects/project/'.$project->id.'/task/'.$myTask->id.'/edit_progress', 'role'=>'form', 'method' => 'PUT', 'name'=>'taskComplete', 'style' => 'display: inline;')) }}
																{{ Form::hidden('progress', 100) }}
																{{ Form::submit('Complete', array('class' => 'btn editbtn btn-success btn-xs')) }}
															{{ Form::close() }}
														@endif
													</div>
													<div style="clear:both;"></div>
                                                </td>
                                            </tr>
										@endforeach
                                    @else
										<tr class="odd gradeX">
											You have no tasks for this project.
										</tr>
                                    @endif
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->


                    <div class="panel panel-default">
                        <div class="panel-heading">
                              <i class="fa fa-eye fa-fw"></i> Project's Milestones
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        
                        	<p>Click each milestone name below to see how many tasks it has and who is responsible for them. For a breakdown of how complete a milestone or 
                        		task is, see the <a href="{{URL::route('project-status', array('Pid' => $project->id))}}">project status</a>.</p>
                        
                        	<div class="panel-group" id="accordian">
                        		@foreach($project->milestones as $milestone)
                        		<div class="panel panel-default">
                        			<div class="panel-heading">
                        				<strong>
                        					<a data-toggle="collapse" data-parent="#accordion" href="#{{$milestone->id}}">{{$milestone->name}}</a>
                        				</strong>
                        			</div>
                        			
                        			<div id="{{$milestone->id}}" class="panel-collapse collapse">
                        				<div class="panel-body">
											<div class="table-responsive">
												<table class="table table-striped table-bordered table-hover" id="dataTables-example1">
													<thead>
														<tr>
															<th>Task</th>
															<th>Assigned to</th>
															<th>Due Date</th>
															<th>Actions</th>
														</tr>
													</thead>
													<tbody>
														@foreach($milestone->tasks as $task)
															<tr class="odd gradeX">
																<td><a href="{{URL::route('milestone-status', array('Pid' => $project->id, 'Mid'=> $milestone->id))}}">{{ $task->name}}</a></td>
																<td><i class="fa fa-user fa-fw"></i> {{ $task->user->first_name." ".$task->user->last_name}}</td>
																<td class="center">{{ date("M d",strtotime( $task->end_date)) }}
																	@if($task->progress==100) - completed @endif</td>
																<td class="center">
																	<div style="float:left;margin-right:5px;">
																		{{ Form::model($task, array(
																		'url' => 'projects/project/'.$project->id.'/task/'.$task->id.'/edit', 
																		'role'=>'form', 
																		'method' => 'get', 
																		)) }} 

																			{{ Form::submit('Edit', array(
																				'class' => 'btn editbtn btn-primary btn-xs '
																			)) }}

																		{{ Form::close() }}
																	</div>
																	<div style="float:left;margin-right:5px;">													
																		{{ Form::model($task, array(
																		'url' => 'projects/project/'.$project->id.'/task/'.$task->id.'/delete', 
																		'role'=>'form', 
																		'method' => 'DELETE', 
																		'name'=>'deleteRule'
																		)) }} 

																			{{ Form::submit('DELETE', array(
																				'class' => 'btn btn-danger btn-xs', 
																				'name'=>'delete_rule'
																			)) }}

																		{{ Form::close() }}
																	</div>
																</td>
															</tr>
														@endforeach
										
													</tbody>
												</table>
											</div>
											<!-- /.table-responsive -->
                        				</div>
                        			</div>
                        		</div><!-- /.panel -->
                        		@endforeach
                        	</div><!-- /.panel group -->
                        </div><!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

					

                    <div class="panel panel-default">
                        <div class="panel-heading">
                              <i class="fa fa-meh-o"></i> Stress level
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
            
                            {{ Form::model($stress, array('url' => 'projects/project/'.$project->id.'/stress/'.$stress->id.'/change', 'role'=>'form', 'method' => 'PUT', 'name'=>'changeStress')) }}
                                 
                                
                              
                                    @if($stress->stress_level == 0)
                                        {{ Form::submit('None', array('class' => 'btn btn-success', 'name'=>'stress_level')) }}
                                    @else
                                        {{ Form::submit('None', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
                                    @endif
                                    

                                    @if($stress->stress_level == 1)
                                        {{ Form::submit('Low', array('class' => 'btn btn-info', 'name'=>'stress_level')) }}
                                    @else
                                        {{ Form::submit('Low', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
                                    @endif
                                    
                                   
                                 
                                   
                                    @if($stress->stress_level == 2)
                                        {{ Form::submit('Medium', array('class' => 'btn btn-primary', 'name'=>'stress_level')) }}
                                    @else
                                        {{ Form::submit('Medium', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
                                    @endif
                                   
                                 
                                   
                                    @if($stress->stress_level == 3)
                                        {{ Form::submit('High', array('class' => 'btn btn-warning', 'name'=>'stress_level')) }}
                                    @else
                                        {{ Form::submit('High', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
                                    @endif
                                    
                                 

                                    @if($stress->stress_level == 4)
                                        {{ Form::submit('Going insane', array('class' => 'btn btn-danger', 'name'=>'stress_level')) }}
                                    @else
                                        {{ Form::submit('Going insane', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
                                    @endif

                        {{ Form::close() }}
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->                    
                    
                </div>
                <!-- /.col-lg-12 -->
                
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

@stop