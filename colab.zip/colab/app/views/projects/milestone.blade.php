@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">New Milestone</h1>

                     <ol class="breadcrumb">
              <li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
              <li class="active"><i class="fa fa-tasks fa-fw"></i> Tasks &amp; Milestones &raquo; New Milestone</li>
            </ol>
                </div>


                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-flag fa-fw"></i> Create a new Milestone
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							{{ Form::open(array('url' => 'projects/project/'.$project->id.'/milestone', 'role'=>'form')) }}

								<div class="form-group">

									<label>Name</label> {{ $errors->first('name') }}
									{{ Form::text('name', Input::old('name'), array('class' => 'form-control input-sm')) }}

								</div>
								<div class="form-group">

									<label>Description</label>{{ $errors->first('description') }}
									{{ Form::textarea('description', Input::old('description'), array('class' => 'form-control input-sm', 'rows'=> '3')) }}

								</div>


								<label for="">Due Date</label>
								<div class="form-group input-group col-xs-3">

									<div class="form-group input-group">
										<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
										{{ Form::text('start_date', Input::old('start_date'), 
										array('class' => 'form-control datepkr input-sm', 'placeholder'=>'Start', 'id'=>'start_date')) }}
									</div>
								</div>

								{{ $errors->first('start_date') }}

								<div class="form-group input-group col-xs-3">

									<div class="form-group input-group">
										<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
										{{ Form::text('end_date', Input::old('end_date'), 
										array('class' => 'form-control datepkr input-sm', 'placeholder'=>'End', 'id'=>'end_date')) }}
									</div> 
								</div>

								{{ $errors->first('end_date') }}                  


								{{ Form::submit('Create', array('class' => 'btn btn-success btn-sm')) }}
								<button type="reset" class="btn btn-primary btn-sm">Reset </button>
							
							{{ Form::close() }}

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-question-circle fa-fw"></i> Help
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <h4>What is a Milestone?</h4>
                            
                            <p><small>A milestone is a group of tasks that form an important stage of the project.</small></p>
							
							<br />
                            
                            <h4>Why create a Milestone?</h4>
                            
                            <p><small>Tracking the completition of Milestones lets the team know when an important stage of the project is finished. It also allows team members to better break large projects into smaller sections. </small></p>

                            <!-- /.list-group -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

@stop