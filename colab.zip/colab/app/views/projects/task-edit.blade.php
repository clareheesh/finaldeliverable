@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Task</h1>
                    <ol class="breadcrumb">
						<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						<li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
						<li class="active"><i class="fa fa-tasks fa-fw"></i> Tasks &amp; Milestones &raquo; New Task</li>
					</ol>
				</div>
            </div>
			
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-flag fa-fw"></i> Edit Task
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							
							{{ Form::open(array('url' => 'projects/project/'.$project->id.'/task/'.$task->id.'/edit', 'role'=>'form')) }}
								<div class="form-group">
								
									<label>Milestone</label> {{ $errors->first('milestone') }}
									<select class="form-control input-sm"  name="milestone">
										<option disabled selected>Select</option>
									
										@foreach($project->milestones as $milestone)
											@if ($milestone->id==$task->milestone->id)
											<option  selected="selected" value="{{ $milestone->id }}">{{ $milestone->name }}</option>
											@else
											<option value="{{ $milestone->id }}">{{ $milestone->name }}</option>
											@endif
										@endforeach
									
									</select>
								</div>


								<div class="form-group">
									<label>Name</label> {{ $errors->first('name') }}
									{{ Form::text('name', $task->name, array('class' => 'form-control input-sm')) }}
								</div>
								
								<div class="form-group">
									<label>Description</label>{{ $errors->first('description') }}
									{{ Form::textarea('description', $task->description, array('class' => 'form-control input-sm', 'rows'=> '3')) }}
								</div>

								<label for="">Due Date</label>
								<div class="form-group input-group col-xs-3">
								
									<div class="form-group input-group">
										<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
										{{ Form::text('start_date', date("m/d/Y", strtotime($task->start_date)), 
											array('class' => 'form-control datepkr input-sm', 'placeholder'=>'Start', 'id'=>'start_date')) }}
									</div>
								</div>
								
								{{ $errors->first('start_date') }}
								
								<div class="form-group input-group col-xs-3">
									
									<div class="form-group input-group">
										<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
										{{ Form::text('end_date', date("m/d/Y", strtotime($task->end_date)), 
											array('class' => 'form-control datepkr input-sm', 'placeholder'=>'End', 'id'=>'end_date')) }}
									</div>
								</div>
								
								{{ $errors->first('end_date') }}
								
								<div class="form-group">
									
									<label>Assign to</label> {{ $errors->first('user') }}
									<select class="form-control input-sm" name="user">
										<option disabled selected>Not assigned</option>
									
										@foreach($otherUsers as $Tuser)
											@if ($Tuser->id==$task->user->id)
											<option  selected="selected" value="{{ $Tuser->id }}">{{ $Tuser->display_name }}</option>
											@else
											<option value="{{ $Tuser->id }}">{{ $Tuser->display_name }}</option>
											@endif
										@endforeach
									
									</select>
								</div>

								{{ Form::submit('Save', array('class' => 'btn btn-success btn-sm')) }}
							{{ Form::close() }}

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-question-circle fa-fw"></i> Help
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <h4>What is a Task?</h4>
                            
                            <p><small>A task is a specific assignment of a project. Milestones are formed by tasks.</small></p>
							<br>
                            <h4>Why create a Task?</h4>
                            
                            <p><small>To be able to assign the task to a member or members of the team and track the progress of the project.</small></p>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

@stop