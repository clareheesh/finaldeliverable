@extends('projects.layout')

@section('content')

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Team's Achievement</h1>

            <ol class="breadcrumb">
              <li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
              <li class="active"><i class="fa fa-star fa-fw"></i> Achievements &raquo; Team</li>
          </ol>
      </div>


      <!-- /.col-lg-12 -->
  </div>
  <!-- /.row -->
  <div class="row">
    <div class="col-lg-8">
        <div class="panel panel-default">
            <div class="panel-heading">
				Team Achievements
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
		
			
			@foreach ($achievements as $ach)	
				<div class="panel panel-default">
					@if(in_array($ach->id, $ach_id))
					<div class="panel-body">
					@else
					<div class="panel-body" style="color:#cccccc;">
					@endif
						<div class="col-lg-2" >
							<i class="fa fa-{{$ach->icon}} fa-4x"></i>
						</div>
						<div class="col-lg-10">
							<div><strong>{{$ach->name}}</strong></div>
							<div>{{$ach->description}}</div>
							
						</div>
					</div>
				</div>			
			@endforeach
              
                  

		   </div>
		   <!-- /.panel-body -->

       </div>
	</div>
       <!-- /.col-lg-8 -->
       <div class="col-lg-4">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <i class="fa fa-question-circle fa-fw"></i> Help
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <h4>Team achievement</h4>

                <p><small>These are the badges earned as a team and those which are still to be unlocked.</small></p>
                <br>


                <!-- /.list-group -->

            </div>
            <!-- /.panel-body -->
        </div>

    </div>
    <!-- /.col-lg-4 -->
</div>
<!-- /.row -->
</div>
<!-- /#page-wrapper -->


@stop
