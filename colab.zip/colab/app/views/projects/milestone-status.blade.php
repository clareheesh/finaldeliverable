@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Milestone Status</h1>

                     <ol class="breadcrumb">
             			<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              			<li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
              			<li><a href="{{URL::route('project-status', array('Pid' => $project->id))}}"><i class="fa fa-tasks"></i> Tasks &amp; Milestones &raquo; Project Status</a></li>
             			<li class="active"><i class="fa fa-tasks fa-fw"></i> Milestone: "{{ $milestone->Mname }}"</li>
            		</ol>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
            <div class="row">

                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-tasks fa-fw"></i> {{ $milestone->name }}: Tasks
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        @if($milestone->totalTasks()>0)
                             @foreach($milestone->tasks as $task)
                                <p>
                                    <strong>{{$task->name}}</strong>
                                    <span class="pull-right text-muted">{{$task->progress}}% Complete</span>
                                </p>
                                <div class="bs-example">
                                   @if($task->progress ==100)
                                        <div class="progress progress-striped">
                                    @else
                                        <div class="progress progress-striped active">
                                    @endif
                                    
									@if($task->progress >=75)
                                        <div class="progress-bar progress-bar-success" style="width: {{ $task->progress}}%"></div>
									@elseif($task->progress>=50)
                                        <div class="progress-bar progress-bar-info" style="width: {{ $task->progress}}%"></div>	
									@elseif($task->progress>=25)
                                        <div class="progress-bar progress-bar-warning" style="width: {{ $task->progress}}%"></div>
									@else
                                        <div class="progress-bar progress-bar-danger" style="width: {{ $task->progress}}%"></div>	
									@endif
									
                                  </div>
                                </div>

                                <p>
                            @endforeach
                        @else
                            You have no tasks for this milestone
                        @endif 

                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                   <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-question-circle fa-fw"></i> Help
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <h4>What is Milestone Status?</h4>
                            
                            <p><small>The list of tasks that a Milestone is made of and the percentage of progress of each one.</small></p>
<br>
                         
                            
                        


                            
                            
                            <!-- /.list-group -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

              


               
 <!-- /.panel-body -->
                    </div>
                    
                </div>
                <!-- /.col-lg-8 -->
                
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->


@stop
