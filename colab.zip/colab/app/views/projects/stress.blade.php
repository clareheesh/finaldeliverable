@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Group Stress Levels</h1>

                     <ol class="breadcrumb">
              <li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
              <li class="active"><i class="fa fa-user fa-fw"></i> Group Stress Levels</li>
            </ol>
                </div>


                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
			
			<div class="row">
				<div class="col-lg-8">
					<div class="row">
						<div class="col-lg-12">
							@if($groupStress == 0)
							<div class="panel panel-success">
							@elseif($groupStress == 1)
							<div class="panel panel-info">
							@elseif($groupStress == 2)
							<div class="panel panel-info">
							@elseif($groupStress == 3)
							<div class="panel panel-yellow">
							@elseif($groupStress == 4)
							<div class="panel panel-red">
							@endif
								<div class="panel-heading">
									<div class="row">
										<div class="col-lg-12">
											<span class="fa-2x">
											@if($groupStress == 0)
											Current Team Stress Level: None
											@elseif($groupStress == 1)
											Current Team Stress Level: Low
											@elseif($groupStress == 2)
											Current Team Stress Level: Medium
											@elseif($groupStress == 3)
											Current Team Stress Level: High
											@elseif($groupStress == 4)
											Current Team Stress Level: Dangerous
											@endif
											</span>
										</div><!-- /.col-lg-12 -->
									</div><!-- /.row -->
								</div><!-- /.panel-heading -->
							</div><!-- panel-->
						</div><!-- /.col-lg-12 -->
					</div>
					<!--/row-->
					
					<div class="row">
						<div class="col-lg-12">
							<div class="panel panel-default">
								<div class="panel-heading">
									  <i class="fa fa-meh-o"></i> Stress level
								</div><!-- /.panel-heading -->
								
								<div class="panel-body">
					
									{{ Form::model($stress, array('url' => 'projects/project/'.$project->id.'/stress/'.$stress->id.'/change', 'role'=>'form', 'method' => 'PUT', 'name'=>'changeStress')) }}
										 
										
									  
											@if($stress->stress_level == 0)
												{{ Form::submit('None', array('class' => 'btn btn-success', 'name'=>'stress_level')) }}
											@else
												{{ Form::submit('None', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
											@endif
											

											@if($stress->stress_level == 1)
												{{ Form::submit('Low', array('class' => 'btn btn-info', 'name'=>'stress_level')) }}
											@else
												{{ Form::submit('Low', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
											@endif
											
										   
										 
										   
											@if($stress->stress_level == 2)
												{{ Form::submit('Medium', array('class' => 'btn btn-primary', 'name'=>'stress_level')) }}
											@else
												{{ Form::submit('Medium', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
											@endif
										   
										 
										   
											@if($stress->stress_level == 3)
												{{ Form::submit('High', array('class' => 'btn btn-warning', 'name'=>'stress_level')) }}
											@else
												{{ Form::submit('High', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
											@endif
											
										 

											@if($stress->stress_level == 4)
												{{ Form::submit('Going insane', array('class' => 'btn btn-danger', 'name'=>'stress_level')) }}
											@else
												{{ Form::submit('Going insane', array('class' => 'btn btn-plain', 'name'=>'stress_level')) }}
											@endif

								{{ Form::close() }}
								</div>
								<!-- /.panel-body -->
							</div>
							<!-- /.panel -->
						</div>
                    	<!-- /.col-lg-12 -->    
					</div>
					<!-- /.row -->
					
					<div class="row">
						<div class="col-lg-12">
							<div class="panel panel-default">
								<div class="panel-heading">
									<i class="fa fa-warning fa-fw"></i> Individual Stress Level
									
								</div>
								<!-- /.panel-heading -->
								<div class="panel-body">

									<div class="stressalert">
								
										@foreach($otherUsers as $otherUser)
											@if($otherUser->stressInProject($project->id)->stress_level == 0)
												 <div class="alert alert-success col-lg-12"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "Not stressed at all"</div>
											@elseif($otherUser->stressInProject($project->id)->stress_level == 1)
												<div class="alert alert-info col-lg-12"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "I have low stress"</div>
											@elseif($otherUser->stressInProject($project->id)->stress_level == 2)
												<div class="alert alert-info col-lg-12"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "Average stress level"</div>
											@elseif($otherUser->stressInProject($project->id)->stress_level == 3)
												<div class="alert alert-warning col-lg-12"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "My stress is high"</div>
											@else
												<div class="alert alert-danger col-lg-12"><strong>{{$otherUser->first_name." ".$otherUser->last_name}}</strong> - "Super crazy stressed"</div>
											@endif
										@endforeach
					   
						
									</div><!-- /.stressalert -->

								</div><!-- /.panel-body -->
							</div><!-- /.panel -->
						</div><!-- /.col-lg-12 -->
					</div><!-- /.row-->	
							
				</div><!-- /.col-lg-8-->
				
				<div class="col-lg-4">
				   <div class="panel panel-primary">
						<div class="panel-heading">
							<i class="fa fa-question-circle fa-fw"></i> Help
						</div>
						<!-- /.panel-heading -->
						<div class="panel-body">
							<h4>Stress Level?</h4>
							
							<p><small>Different colours represent different stress level</small></p>
							<ul>
								<li><small>Green: neutral - no effect on stress</small></li>
								<li><small>Blue: barely noticeable stress </small></li>
								<li><small>Orange: a bit stressed - offer support </small></li>
								<li><small>Red: stressful - approach with caution</small></li>
							</ul>
							
							<!-- /.list-group -->
							
						</div>
						<!-- /.panel-body -->
					</div><!-- /.panel -->
				</div><!-- /.col-lg-4-->		
						
			</div>
			<!-- /.row -->
		
        <!-- /#page-wrapper -->

@stop