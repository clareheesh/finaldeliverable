@extends('projects.layout')

@section('content')

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Group Rules</h1>

					<ol class="breadcrumb">
						<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						<li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
						<li class="active"><i class="fa fa-book fa-fw"></i>Team Rules</li>
					</ol>
                </div>
            </div>
			
			<div class="row">
				<div class="col-lg-8">
					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-book fa-fw"></i>Rules
						</div>
			
						<div class="panel-body">		
							
							@if (count($rules) >= 1)
							<div class="table-responsive">
								<table class="table table-hover" id="dataTables-filelist">
									<thead>
										<tr>
											<th>Description</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										@foreach($rules as $rule)
											<tr class="odd gradeX">
												<td>{{ $rule->description}}</td>
												<td class="center">
													{{ Form::model($rule, array(
														'url' => 'projects/project/'.$project->id.'/rule/'.$rule->id.'/delete', 
														'role'=>'form', 
														'method' => 'DELETE', 
														'name'=>'deleteRule'
													)) }} 

													{{ Form::submit('DELETE', array(
														'class' => 'btn btn-danger btn-xs', 
														'name'=>'delete_rule'
													)) }}

													{{ Form::close() }}
												</td>
											</tr>
										@endforeach
									</tbody>
								</table>
							</div>
							@else
								{{ Alert::danger("No rules found.")}}
							@endif
		
						</div>
					</div>
					<!-- /panel -->
				</div>	
				<!-- /.col-lg-8 -->			

				<div class="col-lg-4">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<i class="fa fa-plus fa-fw"> </i>Add Rule
						</div>
						<!-- /.panel-heading -->
						
						<div class="panel-body">
							<!--Add new rule-->
							@if($errors->first('ruledesc'))
								{{ Alert::danger($errors->first('ruledesc'))}}
							@endif
							
							{{ Form::open(array(
								'url' => 'projects/project/'.$project->id.'/rules', 
								'role'=>'form'
							)) }}
							<h4>New Rule</h4>
							<p><small>Add a new rule that will define the way team members interact with one another during the project.</small></p>
							
							<div class="form-group">
								{{ Form::label('ruledesc', 'Rule Description') }}
								{{ Form::textarea('ruledesc', null, array('class' => 'form-control input-sm', 'rows'=>'3')) }}
							</div>
							
							<div class="form-group">
								{{ Form::submit('Create', array('class' => 'btn btn-success btn-sm btn-block')) }}
							</div>
							
							{{ Form::close() }}
						
						</div>
						<!-- /.panel-body -->
					</div>
					<!-- /.panel -->
				</div>
				<!-- /.col-lg-4 -->
			</div>
			<!-- /.row -->
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->
</div>
<!-- /#page-wrapper -->

@stop