@extends('projects.layout')

@section('scripts')
	<script>
		function search(){
			var input = $( "#searchbar" ).val();
			$( "#searchResults" ).load( "{{ URL::route('search', array('Pid' => $project->id))}}", { search: input }, function() {
				
			});
		
		}
	</script>
@stop

@section('content')

<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Group Members</h1>

                <ol class="breadcrumb">
                    <li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
                    <li class="active"><i class="fa fa-users fa-fw"></i>Group Members</li>
                </ol>
            </div>
        </div>

		<div class="row">
			<div class="col-lg-8">
				<div class="panel panel-default">
					<div class="panel-heading">
						  <i class="fa fa-users fa-fw"></i> Group Members
					</div>
					<!-- /.panel-heading -->

					<div class="panel-body">	
						<div>
							@if(Session::has('flash_notice'))
								{{ Alert::success(Session::get('flash_notice'))}}
							@endif
							@if(Session::has('flash_info'))
								{{ Alert::info(Session::get('flash_info'))}}
							@endif
						</div>
						<!-- Nav tabs -->
						<ul class="nav nav-tabs">
							@foreach ($members as $index=>$member)
								@if($index==0)				 							
									<li class="active">
								@else
									<li>
								@endif
								<a href="#{{ $member->id }}" data-toggle="tab">{{ $member->first_name }}</a>
								</li>
							@endforeach	
						</ul>
				 
						<div class="tab-content">
							@foreach ($members as $index=>$member)
								@if($index==0)				 							
									<div class="tab-pane fade in active" id="{{ $member->id }}">
								@else
									<div class="tab-pane fade in" id="{{ $member->id }}">
								@endif
									<div class="profilepic">
										{{ HTML::image('uploads/display_pictures/'.$member->display_picture, 'Display Picture', array( 'class'=>'img-circle', 'width' => 200, 'height' => 200 )) }}
                                    </div>
									<h3> 
										{{ $member->first_name }} {{ $member->last_name }} <br />
										<small>{{ $member->display_name }}</small>
									</h3>
									
									<br />
									
									<!-- 3 most recent achievements -->									
									<table>
										<tr align="center" height="100px" valign="top">
											@foreach(Personalachievement::all() as $ach)
												@if(in_array($ach->id, $member->personalachievements()->get()->lists('id')))
													<td width="30%">
												@else
													<td width="30%" style="color:#cccccc;">
												@endif
													<i class="fa fa-{{$ach->icon}} fa-4x" style="vertical-align: middle;"></i>
													<br>
													<span><strong>{{$ach->name}}</strong><br>
												</td>
											@endforeach
											
											<!--
											@if (count($member->personalachievements()->get())>0)
												@foreach ($member->personalachievements()->get() as $ach)
												<td width="30%">
													<i class="fa fa-{{$ach->icon}} fa-4x" style="vertical-align: middle;"></i>
													<br>
													<span><strong>{{$ach->name}}</strong><br>
												</td>
												@endforeach
											@else
												
												<td width="30%" style="color:#cccccc;">
													<i class="fa fa-{{$ach->icon}} fa-4x" style="vertical-align: middle;"></i>
													<br>
													<span><strong>{{$ach->name}}</strong><br>
												</td>
												
											@endif-->
											
										</tr>
									</table>
									
									<h4>Contact Details</h4>
									
									@if($member->date_of_birth == 0 && $member->phone =="")
											<p>{{ $member->first_name }} has not provided contact details.</p>
									@endif
									
									@if($member->date_of_birth != 0)
											<p><strong>Date of Birth: </strong> {{ $member->date_of_birth }}</p>
									@endif
										
									@if($member->phone != "")
										<p><strong>Phone:</strong> {{ $member->phone }} </p>
									@endif							
									
									<br />
									
									<h4>About</h4>
									
									@if($member->location == "" && $member->about == "")
											<p>{{ $member->first_name }} has not provided about information.</p>
									@endif
									
									@if($member->location != "")
											<p><strong>Location: </strong>{{ $member->location }}</p>
									@endif
									
									<p> {{ $member->about }} </p>
									
									<br />
									
								</div>
							@endforeach	
						</div>
						<!-- /.tab-content -->	 
						
					</div>
					<!-- /.panel-body -->
				</div>
				<!-- /.panel -->
			</div>
			<!-- /.col-lg-8 -->
			
			
			
			<div class="col-lg-4">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<i class="fa fa-pencil fa-fw"> </i>Add Members
					</div>
					<!-- /.panel-heading -->
					
					<div class="panel-body">
					
						<h4>Find Members</h4>
						
						<p><small>Add members to the project by searching for them using their CoLab username.</small></p>
					
						<div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search..." data-emoji_font="true" style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif, 'Segoe UI Emoji', 'Segoe UI Symbol', Symbola, EmojiSymbols !important;" id="searchbar">
                            
							<span class="input-group-btn">
                                <button class="btn btn-default" type="button" onclick="search()">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
						
						<p><div id="searchResults">
						
						</div></p>
					</div>
					<!-- /.panel-body -->
					
				</div>
				<!-- /.panel -->
			</div>
			<!-- /.col-lg-4 -->			
			
			
			
		</div>
		<!-- row -->
    </div>
    <!-- /.container fluid -->
</div>
<!-- page wrapper -->

@stop