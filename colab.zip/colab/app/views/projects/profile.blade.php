@extends('projects.layout-user')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">User Profile</h1>

                    <ol class="breadcrumb">
						<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						<li class="active"><i class="fa fa-user fa-fw"></i>User Profile</li>
					</ol>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
            <div class="row">
            	<div class="col-lg-8">
            	
            		<div class="panel panel-default">
            			<div class="panel-heading">
            				<i class="fa fa-user fa-fw"> </i>User Profile
            				<button class="btn btn-success btn-xs pull-right" data-toggle="modal" data-target="#myModal">
								Edit
							</button>
            			</div>
            			
            			<div class="panel-body">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs">
								<li class="active"><a href="#basic" data-toggle="tab">Basic</a>
								</li>
								<li><a href="#contact" data-toggle="tab">Contact</a>
								</li>
								<li><a href="#education" data-toggle="tab">Education</a>
								</li>
								<li><a href="#experience" data-toggle="tab">Experience</a>
								</li>
								<li><a href="#skills" data-toggle="tab">Skills</a>
								</li>
								<li><a href="#interests" data-toggle="tab">Interests</a>
								</li>
							</ul>

							<!-- Tab panes -->
							<div class="tab-content">
								<div class="tab-pane fade in active" id="basic">
							
									<br />
							
									@if(Session::has('flash_notice'))
										{{ Alert::success(Session::get('flash_notice'))}}
									@endif

									<!--{{ Form::open(array('url' => 'projects/profile', 'role'=>'form')) }}-->
									<!--First name-->
									<div class="form-group">
										@if($errors->first('first_name'))
											{{ Alert::danger($errors->first('first_name'))}}
										@endif
						
										<label>First Name</label>
										<p>{{ $user->first_name }}</p>
									</div>

									<!--Last Name-->
									<div class="form-group">
										@if($errors->first('last_name'))
											{{ Alert::danger($errors->first('last_name'))}}
										@endif
										<label>Last Name</label>
										<p>{{ $user->last_name }}</p>
									</div>
							
									<!--Username-->
									<div class="form-group">
										@if($errors->first('display_name'))
											{{ Alert::danger($errors->first('display_name'))}}
										@endif
										<label>Username</label>
										<p>{{ $user->display_name }}</p>
									</div>

									<!--Location-->
									<div class="form-group">
										<label>Location</label>
										<p>{{ $user->location }}</p>
									</div>

									<!--About-->
									<div class="form-group">
										@if($errors->first('about'))
											{{ Alert::danger($errors->first('about'))}}
										@endif
										<label>About Me</label>
										<p>{{ $user->about }}</p>			
									</div>
							
									<!--Display Picture-->
									<div class="form-group">
										<label>Display Picture</label>
										<div class="profilepic nofloat">
											{{ HTML::image('uploads/display_pictures/'.$user->display_picture, 'Display Picture', array( 'class'=>'img-circle', 'width' => 200, 'height' => 200 )) }}
										</div>
									</div>
																
								</div>
								<div class="tab-pane fade" id="contact">
									<br />
							
									<!--Phone-->
									<div class="form-group">
										@if($errors->first('phone'))
											{{ Alert::danger($errors->first('phone'))}}
										@endif
										<label>Mobile Phone</label>
										<p>{{ $user->phone }}</p>
									</div>
						
									<!--Email-->
									<div class="form-group">
										@if($errors->first('email'))
											{{ Alert::danger($errors->first('email'))}}
										@endif
										<label>Email</label>
										<p>{{ $user->email }}</p>
									</div>
							
									<!--Social Media-->
									<div class="form-group">
										<label>Find me at:</label>
										<div>
								
											<a href="#" class="btn btn-circle btn-xl btn-facebook">
												<i class="fa fa-facebook fa-2x"> </i>
											</a>
							
											<a href="#" class="btn btn-circle btn-xl btn-google-plus">
												<i class="fa fa-google-plus fa-2x"> </i>
											</a>
							
											<a href="#" class="btn btn-circle btn-xl btn-twitter">
												<i class="fa fa-twitter fa-2x"> </i>
											</a>
								
										</div>
									</div>
						
								</div>
								<div class="tab-pane fade" id="education">
									<br />
							
									@if (Education::where('user_id', '=', $user->id)->first())
									<div class="form-group">
										<label>Degree or Certificate</label>
										<p>{{Education::where('user_id', '=', $user->id)->firstOrFail()->title}}</p>
									</div>
							
									<div class="form-group">
										<label>University</label>
										<p>{{Education::where('user_id', '=', $user->id)->firstOrFail()->place}}</p>
									</div>
							
									<div class="form-group">
										<label>Program</label>
										<p>{{Education::where('user_id', '=', $user->id)->firstOrFail()->field}}</p>
									</div>
							
									<div class="form-group">
										<label>Passing Year</label>
										<p>{{Education::where('user_id', '=', $user->id)->firstOrFail()->graduation_year}}</p>
									</div>
							
									<div class="form-group">
										<label>GPA</label>
										<p>{{Education::where('user_id', '=', $user->id)->firstOrFail()->gpa}}</p>
									</div>
									@else
									<div class="form-group" style="color:#cccccc;">
										<strong>No information provided</strong>
									</div>
									@endif
						
								</div>
								<div class="tab-pane fade" id="experience">
									<br />
									@if (Job::where('user_id', '=', $user->id)->first())
									<div class="form-group">
										<label>Job Title</label>
										<p>{{Job::where('user_id', '=', $user->id)->firstOrFail()->name}}</p>
									</div>
							
									<div class="form-group">
										<label>Department</label>
										<p>{{Job::where('user_id', '=', $user->id)->firstOrFail()->department}}</p>
									</div>
							
									<div class="form-group">
										<label>Company</label>
										<p>{{Job::where('user_id', '=', $user->id)->firstOrFail()->company}}</p>
									</div>
							
									<div class="form-group">
										<label>Location</label>
										<p>{{Job::where('user_id', '=', $user->id)->firstOrFail()->location}}</p>
									</div>
							
									<div class="form-group input-group col-xs-3">
										<label>Date</label>
										<p>{{Job::where('user_id', '=', $user->id)->firstOrFail()->date}}</p>
									</div>
									@else
									<div class="form-group" style="color:#cccccc;">
										<strong>No information provided</strong>
									</div>
									@endif
						
								</div>
								<div class="tab-pane fade" id="skills">
									<br />
									@if (Skill::where('user_id', '=', $user->id)->first())
									<div class="form-group">
										<label>Field</label>
										<p>{{Skill::where('user_id', '=', $user->id)->firstOrFail()->field}}</p>
									</div>
							
									<div class="form-group">
										<label>Ability</label>
										<p>{{Skill::where('user_id', '=', $user->id)->firstOrFail()->ability}}</p>
									</div>
							
									<div class="form-group">
										<label>Description</label>
										<p>{{Skill::where('user_id', '=', $user->id)->firstOrFail()->description}}</p>
									</div>
									@else
									<div class="form-group" style="color:#cccccc;">
										<strong>No information provided</strong>
									</div>
									@endif
						
								</div>
								<div class="tab-pane fade" id="interests">
									<br />
									@if (Interest::where('user_id', '=', $user->id)->first())
									<div class="form-group">
										<label>Hobby</label>
										<p>{{Interest::where('user_id', '=', $user->id)->firstOrFail()->hobby}}</p>
									</div>
							
									<div class="form-group">
										<label>Pet</label>
										<p>{{Interest::where('user_id', '=', $user->id)->firstOrFail()->pet}}</p>
									</div>
							
									<div class="form-group">
										<label>Food</label>
										<p>{{Interest::where('user_id', '=', $user->id)->firstOrFail()->food}}</p>
									</div>
									@else
									<div class="form-group" style="color:#cccccc;">
										<strong>No information provided</strong>
									</div>
									@endif
						
								</div>
							</div>
							<!-- /.tab content -->
            			</div>
            			<!-- /.panel-body -->
            		</div>
            		<!-- /.panel -->			     	
            	</div>
            	<!-- /.col-lg-8 -->
            	 	
            	<div class="col-lg-4">
            		<div class="panel panel-primary">
            			<div class="panel-heading">
            				<i class="fa fa-question-circle fa-fw"></i> Help
            			</div>
            			<!-- /.panel-heading -->
            			
            			<div class="panel-body">
            			
            				<h4> </h4>
                            
                            <p><small> </small></p>
                            
                            <!-- /.list-group -->
            			
            			</div>
            			<!-- /.panel-body -->
            		</div>
            		<!-- /.panel-primary -->
            	</div>
            	<!-- /.col-lg-4-->
        	</div>
        	<!-- /.row -->	
        	
        	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title" id="myModalLabel">
								<i class="fa fa-pencil fa-fw"> </i>Edit User Profile
							</h4>
						</div>
						<!-- /.modal-header -->
						<div class="modal-body">
				
							<!-- Nav tabs -->
							<ul class="nav nav-tabs">
								<li class="active"><a href="#basic2" data-toggle="tab">Basic</a>
								</li>
								<li><a href="#contact2" data-toggle="tab">Contact</a>
								</li>
								<li><a href="#education2" data-toggle="tab">Education</a>
								</li>
								<li><a href="#experience2" data-toggle="tab">Experience</a>
								</li>
								<li><a href="#skills2" data-toggle="tab">Skills</a>
								</li>
								<li><a href="#interests2" data-toggle="tab">Interests</a>
								</li>
							</ul>

							<!-- Tab panes -->
							<div class="tab-content">
								<div class="tab-pane fade in active" id="basic2">
							
									<br />
							
									@if(Session::has('flash_notice'))
										{{ Alert::success(Session::get('flash_notice'))}}
									@endif

									{{ Form::open(array('url' => 'projects/profile', 'role'=>'form', 'files' => true)) }}
									<!--First name-->
									<div class="form-group">
										@if($errors->first('first_name'))
											{{ Alert::danger($errors->first('first_name'))}}
										@endif
						
										<label>First Name</label>
										{{ Form::text('first_name', $user->first_name, array('class' => 'form-control input-sm')) }}
									</div>

									<!--Last Name-->
									<div class="form-group">
										@if($errors->first('last_name'))
											{{ Alert::danger($errors->first('last_name'))}}
										@endif
										<label>Last Name</label>
										{{ Form::text('last_name', $user->last_name, array('class' => 'form-control input-sm')) }}
									</div>
							
									<!--Username-->
									<div class="form-group">
										@if($errors->first('display_name'))
											{{ Alert::danger($errors->first('display_name'))}}
										@endif
										<label>Username</label>
										{{ Form::text('display_name', $user->display_name, array('class' => 'form-control input-sm')) }}
									</div>

									<!--Location-->
									<div class="form-group">
										<label>Location</label>
										{{ Form::text('location', $user->location, array('class' => 'form-control input-sm')) }}
									</div>

									<!--About-->
									<div class="form-group">
										@if($errors->first('about'))
											{{ Alert::danger($errors->first('about'))}}
										@endif
										<label>About Me</label>
										{{ Form::textarea('about', $user->about, array('class' => 'form-control input-sm', 'rows'=>'3')) }}
									</div>
							
									<!--Display Picture-->
									<div class="form-group">
										<label>Display Picture</label>
										<p>
											{{ Form::input('file', 'photo', null) }}
										</p>
										<div class="profilepic nofloat">
											{{ HTML::image('uploads/display_pictures/'.$user->display_picture, 'Display Picture', array( 'class'=>'img-circle', 'width' => 200, 'height' => 200 )) }}
										</div>
										
										
										
									</div>
																
								</div>
								<div class="tab-pane fade" id="contact2">
									<br />
							
									<!--Phone-->
									<div class="form-group">
										@if($errors->first('phone'))
											{{ Alert::danger($errors->first('phone'))}}
										@endif
										<label>Mobile Phone</label>
										{{ Form::text('phone', $user->phone, array('class' => 'form-control input-sm')) }}
									</div>
						
									<!--Email-->
									<div class="form-group">
										@if($errors->first('email'))
											{{ Alert::danger($errors->first('email'))}}
										@endif
										<label>Email</label>
										{{ Form::text('email', $user->email, array('class' => 'form-control input-sm')) }}
									</div>
							
									<!--Social Media-->
									<div class="form-group">
										<label>Find me at:</label>
										<div>
								
											<a href="#" class="btn btn-circle btn-xl btn-facebook">
												<i class="fa fa-facebook fa-2x"> </i>
											</a>
							
											<a href="#" class="btn btn-circle btn-xl btn-google-plus">
												<i class="fa fa-google-plus fa-2x"> </i>
											</a>
							
											<a href="#" class="btn btn-circle btn-xl btn-twitter">
												<i class="fa fa-twitter fa-2x"> </i>
											</a>
								
										</div>
									</div>
						
								</div>
								<div class="tab-pane fade" id="education2">
									<br />
							
									<div class="form-group">
										<label>Degree or Certificate</label>
										@if(Education::where('user_id', '=', $user->id)->first())
										{{ Form::text('degree', Education::where('user_id', '=', $user->id)->firstOrFail()->title, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('degree', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>University</label>
										@if(Education::where('user_id', '=', $user->id)->first())
										{{ Form::text('university', Education::where('user_id', '=', $user->id)->firstOrFail()->place, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('university', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">										
										<label>Program</label>
										@if(Education::where('user_id', '=', $user->id)->first())
										{{ Form::text('program', Education::where('user_id', '=', $user->id)->firstOrFail()->field, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('program', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group input-group col-xs-3">										
										<label>Passing Year</label>
										@if(Education::where('user_id', '=', $user->id)->first())
										{{ Form::text('grad_year', Education::where('user_id', '=', $user->id)->firstOrFail()->graduation_year, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('grad_year', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										
										<label>GPA</label>
										@if(Education::where('user_id', '=', $user->id)->first())
										{{ Form::text('gpa', Education::where('user_id', '=', $user->id)->firstOrFail()->gpa, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('gpa', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
						
								</div>
								<div class="tab-pane fade" id="experience2">
									<br />
							
									<div class="form-group">
										<label>Job Title</label>
										@if(Job::where('user_id', '=', $user->id)->first())
										{{ Form::text('name', Job::where('user_id', '=', $user->id)->firstOrFail()->name, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('name', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>Department</label>
										@if(Job::where('user_id', '=', $user->id)->first())
										{{ Form::text('department', Job::where('user_id', '=', $user->id)->firstOrFail()->department, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('department', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>Company</label>
										@if(Job::where('user_id', '=', $user->id)->first())
										{{ Form::text('company', Job::where('user_id', '=', $user->id)->firstOrFail()->company, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('company', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>Location	</label>
										@if(Job::where('user_id', '=', $user->id)->first())
										{{ Form::text('location', Job::where('user_id', '=', $user->id)->firstOrFail()->location, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('location', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group input-group col-xs-3">
										<label>Date</label>
										@if(Job::where('user_id', '=', $user->id)->first())
										{{ Form::text('date', Job::where('user_id', '=', $user->id)->firstOrFail()->date, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('date', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
						
								</div>
								<div class="tab-pane fade" id="skills2">
									<br />
							
									<div class="form-group">
										<label>Field</label>
										@if(Skill::where('user_id', '=', $user->id)->first())
										{{ Form::text('field', Skill::where('user_id', '=', $user->id)->firstOrFail()->field, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('field', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>Ability</label>
										@if(Skill::where('user_id', '=', $user->id)->first())
										{{ Form::text('ability', Skill::where('user_id', '=', $user->id)->firstOrFail()->ability, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('ability', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>Description</label>
										@if(Skill::where('user_id', '=', $user->id)->first())
										{{ Form::textarea('description', Skill::where('user_id', '=', $user->id)->firstOrFail()->description, array('class' => 'form-control input-sm', 'rows'=>'3')) }}
										@else
										{{ Form::text('description', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
						
								</div>
								<div class="tab-pane fade" id="interests2">
									<br />
							
									<div class="form-group">
										<label>Hobby</label>
										@if(Interest::where('user_id', '=', $user->id)->first())
										{{ Form::text('hobby', Interest::where('user_id', '=', $user->id)->firstOrFail()->hobby, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('hobby', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>Pet</label>
										@if(Interest::where('user_id', '=', $user->id)->first())
										{{ Form::text('pet', Interest::where('user_id', '=', $user->id)->firstOrFail()->pet, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('pet', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
							
									<div class="form-group">
										<label>Food</label>
										@if(Interest::where('user_id', '=', $user->id)->first())
										{{ Form::text('food', Interest::where('user_id', '=', $user->id)->firstOrFail()->food, array('class' => 'form-control input-sm')) }}
										@else
										{{ Form::text('food', '', array('class' => 'form-control input-sm')) }}
										@endif
									</div>
						
								</div>
							</div>
						</div>
						<!-- /.modal-body -->
				
						<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								{{ Form::submit('Save', array('class' => 'btn btn-primary')) }}
								{{ Form::close() }}
						</div>
						<!-- /.modal-footer -->
					</div>
					<!-- /.modal-content-->
				</div>
				<!-- /.modal-dialog -->
			</div>
			<!-- /.modal fade -->   
		
        </div>
        <!-- /#page-wrapper -->

@stop