@extends('projects.layout')

@section('content')

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Chat</h1>

					<ol class="breadcrumb">
						<li><a href="{{URL::route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
						<li><a href="{{URL::route('project', array('Pid' => $project->id))}}"><i class="fa fa-folder"></i> {{ $project->name }}</a></li>
						<li class="active"><i class="fa fa-tasks fa-fw"></i>Chat</li>
					</ol>
                </div>
            </div>
			
			<div class="row">
				 {{ Alert::danger("This page is not yet implemented")}}
			</div>
			
        </div>
        <!-- /#page-wrapper -->

@stop