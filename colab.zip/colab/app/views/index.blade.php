<!DOCTYPE html>
<html>
<head>
	<title>COLAB | Team collaboration App | by The Latest Tricks</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="shortcut icon" href="img/favicon.ico">
	
    <!-- Styles -->
    <link href="css/bootstrap/bootstrap.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/compiled/bootstrap-overrides.css" type="text/css" />
    <link rel="stylesheet" type="text/css" href="css/compiled/theme.css" />

    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css' />

    <link rel="stylesheet" href="css/compiled/index.css" type="text/css" media="screen" /> 
    <link rel="stylesheet" href="css/compiled/fonts.css" type="text/css" media="screen" />   
    <link rel="stylesheet" type="text/css" href="css/lib/animate.css" media="screen, projection" />    

    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body class="pull_top">
    
    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle pull-right" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="{{ URL::route('home')}}" class="navbar-brand"><div></div></a>
            </div>

            <div class="collapse navbar-collapse navbar-ex1-collapse" role="navigation">
                <ul class="nav navbar-nav navbar-right">
                    <!--<li class="active"><a href="{{ URL::route('home')}}">HOME</a></li>-->
                    <li><a href="{{ URL::route('home')}}">FEATURES</a></li>
                    <li><a href="{{ URL::route('about')}}">ABOUT US</a></li>
                    <li><a href="{{ URL::route('signup')}}">SIGN UP</a></li>
                    <li><a href="{{ URL::route('login')}}">LOG IN</a></li>

                </ul>
            </div>
        </div>
    </div>

    <section id="feature_slider" class="lol">
        <!-- 
            Each slide is composed by <img> and .info
            - .info's position is customized with css in index.css
            - each <img> parallax effect is declared by the following params inside its class:
            
            example: class="asset left-472 sp600 t120 z3"
            left-472 means left: -472px from the center
            sp600 is speed transition
            t120 is top to 120px
            z3 is z-index to 3
            Note: Maintain this order of params

            For the backgrounds, you can combine from the bgs folder :D
        -->
        <article class="slide" id="showcasing" style="background: url('img/backgrounds/ocean.jpg') repeat-x top center;">
            <img class="asset left-30 sp600 t120 z1" src="img/slides/scene1/macbook.png" />
            <div class="info">
                <h2>Feel confident and supported working in a team.</h2>
            </div>
        </article>
        <article class="slide" id="ideas" style="background: url('img/backgrounds/aqua.jpg') repeat-x top center;">
            <div class="info">
                <h2>Task management, team communication and much more.</h2>
            </div>
            <img class="asset left-480 sp600 t260 z1" src="img/slides/scene2/left.png" />
            <img class="asset left-210 sp600 t213 z2" src="img/slides/scene2/middle.png" />
            <img class="asset left60 sp600 t260 z1" src="img/slides/scene2/right.png" />
        </article>
        <article class="slide" id="tour" style="background: url('img/backgrounds/color-splash.jpg') repeat-x top center;">
            <img class="asset left-472 sp650 t210 z3" src="img/slides/scene3/ipad.png" />
            <img class="asset left-365 sp600 t270 z4" src="img/slides/scene3/iphone.png" />
            <img class="asset left-350 sp450 t135 z2" src="img/slides/scene3/desktop.png" />
            <img class="asset left-185 sp550 t220 z1" src="img/slides/scene3/macbook.png" />
            <div class="info">
                <h2>Cross-platform design.</h2>
                <a href="">LEARN MORE</a>
            </div>
        </article>    
    </section>




    <div id="showcase">
        <div class="container">
			
				@if(isset($_GET['submitted']))
					<div>
						{{ Alert::success('Great to hear from you!')}}
					</div>
					
				@endif
			
            <div class="section_header">
                <h3>Top Features</h3>
            </div>            
            <div class="row feature_wrapper">
                <!-- Features Row -->
                <div class="features_op1_row">
                    <!-- Feature -->
                    <div class="col-sm-4 feature first">
                        <div class="img_box">
                            <a href="{{ URL::route('about')}}">
                                <img src="img/service1.png">
                                <span class="circle"> 
                                    <span class="plus">&#43;</span>
                                </span>
                            </a>
                        </div>
                        <div class="text">
                            <h6>Milestones &amp; Tasks</h6>
                            <p>
                                Milestones represent important dates and deadlines in a project. Each milestone is made up of a number of tasks and each task is assigned to a user. Progress bars clearly demonstrate how complete tasks and milstones are.
                            </p>
                        </div>
                    </div>
                    <!-- Feature -->
                    <!-- Feature -->
                    <div class="col-sm-4 feature">
                        <div class="img_box">
                            <a href="{{ URL::route('about')}}">
                                <img src="img/service2.png">
                                <span class="circle"> 
                                    <span class="plus">&#43;</span>
                                </span>
                            </a>
                        </div>
                        <div class="text">
                            <h6>Rewards system</h6>
                            <p>
                            	Users can earn a number of badges for completing tasks, both individually and for their team. Achievements provide extra incentive and foster a sense of accomplishment. 
                            </p>
                        </div>
                    </div>
                    <!-- Feature -->
                    <div class="col-sm-4 feature last">
                        <div class="img_box">
                            <a href="{{ URL::route('about')}}">
                                <img src="img/service3.png">
                                <span class="circle"> 
                                    <span class="plus">&#43;</span>
                                </span>
                            </a>
                        </div>
                        <div class="text">
                            <h6>Stress-free team work</h6>
                            <p>
                            	Through the use of stress levels team members can also see an overall summary of how each team member is handling their workload and provide support and encouragement.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    


    <!-- Pricing Option -->
    <div id="in_pricing">
        <div class="container">
            <div class="start">
                <p>Discover the only User-First collaboration tool.</p>
                <a href="{{ URL::route('signup')}}">Join Now!</a>
            </div>
        </div>
    </div>

   

    <!-- starts footer -->
    <footer id="footer">
        <div class="container">
            <div class="row sections">
                <div class="col-sm-3 testimonials">
                    <h3 class="footer_header">
                        Colab
                    </h3>
                    <div class="wrapper info">
                       <ul class="">
                           <li>
                               <a href="{{ URL::route('home')}}">Features</a>
                            </li>
                            <li>
                               <a href="{{ URL::route('about')}}">About us</a>
                            </li>
                            <li>
                               <a href="{{ URL::route('signup')}}">Sign up</a>
                            </li>
                            <li>
                               <a href="{{ URL::route('login')}}">Log in</a>
                           </li>
                       </ul>
                        
                    </div>
                   
                </div>
                <div class="col-sm-4 testimonials">
                    <h3 class="footer_header">
                        The Latest Tricks
                    </h3>
                    <div class="wrapper">
                        <div class="quote">
                        
                        	The Latest Tricks is a consultancy firm helping organisations gain a business advantage by 
                        	using the latest technologies and techniques. The company focuses on complex systems, User 
                        	Experience designs, digital engagement, social media and affect management.
  
                            <a href="http://thelatesttricks.com/" target="_blank">Learn more</a>
                          
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-5 contact">
                    <h3 class="footer_header">
                        Contact
                    </h3>
                    <form action="#" method="get">
                        <input type="text" placeholder="Your name" />
                        <input type="text" placeholder="Your email" />
                        <textarea rows="3" placeholder="Message"></textarea>
                        <input type="submit" value="Send" />
                    </form>
                </div>
            </div>
            <div class="row credits">
                <div class="col-md-12">
                    <div class="row social">
                        <div class="col-md-12">
                            <a href="https://www.facebook.com/ColabSynergy?fref=nf" class="facebook">
                                <span class="socialicons ico1"></span>
                                <span class="socialicons_h ico1h"></span>
                            </a>
                            <a href="https://twitter.com/CoLabWebApp" class="twitter">
                                <span class="socialicons ico2"></span>
                                <span class="socialicons_h ico2h"></span>
                            </a>
                            <a href="https://plus.google.com/114954676985271116931/posts" class="gplus">
                                <span class="socialicons ico3"></span>
                                <span class="socialicons_h ico3h"></span>
                            </a>
                        </div>
                    </div>
                    <div class="row copyright">
                        <div class="col-md-12">
                            © 2014 The Latest Tricks. All rights reserved. Powered by <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>. Theme by <a href="https://wrapbootstrap.com/theme/clean-canvas-business-theme-WB02634G3" target="_blank">Detail Canvas</a>.
                        </div>
                    </div>
                </div>            
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/theme.js"></script>

    <script type="text/javascript" src="js/index-slider.js"></script>	
</body>
</html>