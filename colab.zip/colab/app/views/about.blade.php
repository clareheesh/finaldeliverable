<!DOCTYPE html>
<html>
<head>
	<title>About | COLAB | Team collaboration App | by The Latest Tricks</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="shortcut icon" href="img/favicon.ico">
	
    <!-- Styles -->
    <link href="css/bootstrap/bootstrap.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/compiled/bootstrap-overrides.css" type="text/css" />
    <link rel="stylesheet" type="text/css" href="css/compiled/theme.css" />

    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css' />

    <link rel="stylesheet" href="css/compiled/index.css" type="text/css" media="screen" /> 
    <link rel="stylesheet" href="css/compiled/sign-in.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/compiled/fonts.css" type="text/css" media="screen" />   
    <link rel="stylesheet" type="text/css" href="css/lib/animate.css" media="screen, projection" /> 
    <link rel="stylesheet" href="css/compiled/about.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/lib/flexslider.css" type="text/css" media="screen" />   

    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body class="pull_top">
    
     <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle pull-right" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="{{ URL::route('home')}}" class="navbar-brand"><div></div></a>
            </div>

            <div class="collapse navbar-collapse navbar-ex1-collapse" role="navigation">
                <ul class="nav navbar-nav navbar-right">
                    <!--<li class="active"><a href="{{ URL::route('home')}}">HOME</a></li>-->
                    <li><a href="{{ URL::route('home')}}">FEATURES</a></li>
                    <li><a href="{{ URL::route('about')}}">ABOUT US</a></li>
                    <li><a href="{{ URL::route('signup')}}">SIGN UP</a></li>
                    <li><a href="{{ URL::route('login')}}">LOG IN</a></li>

                </ul>
            </div>
        </div>
    </div>
<!-- Sign In Option 1 -->
    <div id="sign_in1">
        <div class="container">
            <div class="row">
                <div class="col-md-12 header">
                    <h4>Get to know us!</h4>
                    <p>
                        Learn a little bit about us and why you should try COLAB.</p>

                  
                </div>

              
            </div>
        </div>
    </div>

    <!-- About us -->
    <div id="aboutus">
        

        <div class="container">
            <div class="section_header">
                <h3>About Us</h3>
            </div>
            <div class="row">
                <div class="col-sm-6 intro">
                    <h6>No stress. No conflicts. No late submissions.</h6>
                    <p>
                        COLAB is focused on creating a sense of motivation and support between members of a study group. Is the first Team Collaboration APP that rewards all your achievements
                    </p>
					<ul>
						<li>Team collaboration focused on motivation and support</li>
						<li>Encourage members through rewards and achievement systems</li>
						<li>Identify and lower the stress levels on team members</li>
						<li>Avoid conflicts between members</li>
						<li>Engaging and effective team work based on mutual help</li>
						<li>Organized task management, monitoring and allocation</li>
					
					</ul>
                       
                </div>
                <div class="col-sm-6">
                    <div class="flexslider">
                        <ul class="slides">
                            <li>
                              <img src="img/about_slide01.jpg" />
                            </li>
                            <li>
                              <img src="img/about_slide02.jpg" />
                            </li>
                            <li>
                              <img src="img/about_slide03.jpg" />
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    
    </div>  



    <!-- starts footer -->
    <footer id="footer">
        <div class="container">
            <div class="row sections">
                <div class="col-sm-3 testimonials">
                    <h3 class="footer_header">
                        Colab
                    </h3>
                    <div class="wrapper info">
                       <ul class="">
                           <li>
                               <a href="{{ URL::route('home')}}">Features</a>
                            </li>
                            <li>
                               <a href="{{ URL::route('about')}}">About us</a>
                            </li>
						    <li>
							   <a href="{{ URL::route('signup')}}">Sign up</a>
							</li>
							<li>
                               <a href="{{ URL::route('login')}}">Log in</a>
							</li>
						</ul>
                        
                    </div>
                   
                </div>
                <div class="col-sm-4 testimonials">
                    <h3 class="footer_header">
                        The Latest Tricks
                    </h3>
                    <div class="wrapper">
                        <div class="quote">
                            
                            The Latest Tricks is a consultancy firm helping organisations gain a business advantage by 
                        	using the latest technologies and techniques. The company focuses on complex systems, User 
                        	Experience designs, digital engagement, social media and affect management.
  
                            <a href="http://thelatesttricks.com/" target="_blank">Learn more</a>
                          
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-5 contact">
                    <h3 class="footer_header">
                        Contact
                    </h3>
                    <form action="#" method="get">
                        <input type="text" placeholder="Your name" />
                        <input type="text" placeholder="Your email" />
                        <textarea rows="3" placeholder="Message"></textarea>
                        <input type="submit" value="Send" />
                    </form>
                </div>
            </div>
            <div class="row credits">
                <div class="col-md-12">
                    <div class="row social">
                        <div class="col-md-12">
                            <a href="https://www.facebook.com/ColabSynergy?fref=nf" class="facebook">
                                <span class="socialicons ico1"></span>
                                <span class="socialicons_h ico1h"></span>
                            </a>
                            <a href="https://twitter.com/CoLabWebApp" class="twitter">
                                <span class="socialicons ico2"></span>
                                <span class="socialicons_h ico2h"></span>
                            </a>
                            <a href="https://plus.google.com/114954676985271116931/posts" class="gplus">
                                <span class="socialicons ico3"></span>
                                <span class="socialicons_h ico3h"></span>
                            </a>
                        </div>
                    </div>
                    <div class="row copyright">
                        <div class="col-md-12">
                            © 2014 The Latest Tricks. All rights reserved. Powered by <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>. Theme by <a href="https://wrapbootstrap.com/theme/clean-canvas-business-theme-WB02634G3" target="_blank">Detail Canvas</a>.
                        </div>
                    </div>
                </div>            
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/theme.js"></script>

    <script type="text/javascript" src="js/index-slider.js"></script>
    <script type="text/javascript" src="js/flexslider.js"></script>
</body>
</html>