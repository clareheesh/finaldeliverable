<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Setup extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//acknowledgements
		Schema::create('acknowledgements', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->integer('task_id')->unsigned();
			$table->integer('post_id')->unsigned();
			$table->timestamps();
		});

		//datafiles
		Schema::create('datafiles', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->integer('project_id')->unsigned();
			$table->string('name');
			$table->string('type');
			$table->string('description');
			$table->string('destination');
			$table->string('size');
			$table->timestamps();
		});

		//education
		Schema::create('education', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->string('title')->default('');
			$table->string('place')->default('');
			$table->string('field')->default('');
			$table->integer('graduation_year')->default(0);;
			$table->float('gpa')->default(0);
			$table->timestamps();
		});

		//interests
		Schema::create('interests', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->string('hobby')->default('');
			$table->string('pet')->default('');
			$table->string('food')->default('');
			$table->timestamps();
		});

		//jobs
		Schema::create('jobs', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->string('name')->default('');
			$table->string('company')->default('');
			$table->string('location')->default('');
			$table->string('department')->default('');
			$table->date('date')->default('0000-00-00');
			$table->timestamps();
		});

		//meetings
		Schema::create('meetings', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('description');
			$table->integer('project_id')->unsigned();
			$table->date('start_date')->default('0000-00-00');
			$table->date('end_date')->default('0000-00-00');
			$table->time('start_time');
			$table->time('end_time');
			$table->timestamps();
		});

		//message_lobbies
		Schema::create('message_lobbies', function(Blueprint $table)
		{
			$table->increments('id');
			$table->timestamps();
		});

		//message_lobby_users
		Schema::create('message_lobby_users', function(Blueprint $table)
		{
			$table->increments('id');
			$table->timestamps();
			$table->integer('message_lobby_id')->unsigned();
			$table->integer('user_id')->unsigned();
		});

		//messages
		Schema::create('messages', function(Blueprint $table)
		{
			$table->increments('id');
			$table->timestamps();
			$table->string('contents');
			$table->integer('user_id')->unsigned();
			$table->integer('message_lobby_id')->unsigned();
		});

		//messages_read
		Schema::create('messages_read', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('lobby_id')->unsigned();
			$table->integer('message_id')->unsigned();
			$table->integer('user_id')->unsigned();
			$table->integer('read')->unsigned();
			$table->timestamps();
		});

		//milestones
		Schema::create('milestones', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->date('start_date')->default('0000-00-00');
			$table->date('end_date')->default('0000-00-00');
			$table->integer('project_id')->unsigned();
			$table->integer('soft_delete')->default('0');
			$table->timestamps();
		});

		//notification_categories
		Schema::create('notification_categories', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->string('text');
			$table->timestamps();
		});

		//notifications
		Schema::create('notifications', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('to_id')->unsigned();
			$table->integer('from_id')->unsigned();
			$table->string('from_type');
			$table->string('to_type');
			$table->integer('category_id')->unsigned();
			$table->string('url');
			$table->string('extra');
			$table->integer('read');
			$table->timestamps();
			$table->integer('project_id')->unsigned();
		});

		//personalachievements
		Schema::create('personalachievements', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->string('description');
			$table->string('icon');
			$table->timestamps();
		});

		//posts
		Schema::create('posts', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('project_id')->unsigned();
			$table->string('table');
			$table->string('TB_id');
			$table->timestamps();
		});

		//posts_comments
		Schema::create('posts_comments', function(Blueprint $table)
		{
			$table->increments('id');
			$table->timestamps();
			$table->integer('user_id')->unsigned();
			$table->integer('post_id')->unsigned();
			$table->string('comment');
		});

		//profiles
		Schema::create('profiles', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->string('type');
			$table->string('hobbies');
			$table->string('hair_colour');
			$table->string('eye_colour');
			$table->string('height');
			$table->string('zodiac_sign');
			$table->string('pets');
			$table->string('bad_habits');
			$table->string('best_friend');
			$table->string('future_goals');
			$table->string('three_words');
			$table->string('favourite_song');
			$table->string('favourite_movie');
			$table->string('favourite_celebrity');
			$table->timestamps();
		});

		//projects
		Schema::create('projects', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->string('description');
			$table->date('start_date')->default('0000-00-00');
			$table->date('end_date')->default('0000-00-00');
			$table->timestamps();
		});

		//projects_teamachievements
		Schema::create('projects_teamachievements', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('project_id')->unsigned();
			$table->integer('teamachievement_id')->unsigned();
			$table->timestamps();
		});

		//rules
		Schema::create('rules', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('description');
			$table->integer('project_id')->unsigned();
			$table->timestamps();
		});

		//skills
		Schema::create('skills', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->string('field')->default('');
			$table->string('ability')->default('');
			$table->string('description')->default('');
			$table->timestamps();
		});

		//stress
		Schema::create('stress', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->integer('project_id')->unsigned();
			$table->integer('stress_level')->default('0');
			$table->timestamps();
		});

		//stress_tips
		Schema::create('stress_tips', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('content');
			$table->string('source_name');
			$table->string('source_url');
		});

		//tasks
		Schema::create('tasks', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->string('description');
			$table->date('start_date')->default('0000-00-00');
			$table->date('end_date')->default('0000-00-00');
			$table->integer('user_id')->unsigned();
			$table->integer('milestone_id')->unsigned();
			$table->integer('progress');
			$table->timestamps();
			$table->integer('soft_delete')->default('0');
		});

		//teamachievements
		Schema::create('teamachievements', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->string('description');
			$table->string('icon');
			$table->timestamps();
		});

		//users
		Schema::create('users', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('email');
			$table->string('password');
			$table->string('first_name');
			$table->string('last_name');
			$table->string('display_name');
			$table->date('date_of_birth')->default('0000-00-00');
			$table->string('phone')->default('');
			$table->string('location')->default('');
			$table->string('about')->default('');
			$table->string('remember_token')->default('');
			$table->timestamps();
			$table->string('display_picture')->default('default.png');
		});

		//users_personalachievements
		Schema::create('users_personalachievements', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->integer('personalachievement_id')->unsigned();
			$table->timestamps();
			$table->integer('project_id')->unsigned();
		});

		//users_projects
		Schema::create('users_projects', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('project_id')->unsigned();
			$table->integer('user_id')->unsigned();
			$table->timestamps();
		});

		Schema::table('acknowledgements', function($table) {
			$table->foreign('post_id')->references('id')->on('posts')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('task_id')->references('id')->on('tasks')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('datafiles', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('education', function($table) {
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('interests', function($table) {
		});
		Schema::table('jobs', function($table) {
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('meetings', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('message_lobbies', function($table) {
		});
		Schema::table('message_lobby_users', function($table) {
			$table->foreign('message_lobby_id')->references('id')->on('message_lobbies')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('messages', function($table) {
			$table->foreign('message_lobby_id')->references('id')->on('message_lobbies')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('messages_read', function($table) {
			$table->foreign('lobby_id')->references('id')->on('message_lobbies')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('message_id')->references('id')->on('messages')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('milestones', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('notification_categories', function($table) {
		});
		Schema::table('notifications', function($table) {
			$table->foreign('category_id')->references('id')->on('notification_categories')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('from_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('to_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('personalachievements', function($table) {
		});
		Schema::table('posts', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('posts_comments', function($table) {
			$table->foreign('post_id')->references('id')->on('posts')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('profiles', function($table) {
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('projects', function($table) {
		});
		Schema::table('projects_teamachievements', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('teamachievement_id')->references('id')->on('teamachievements')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('rules', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('skills', function($table) {
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('stress', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('stress_tips', function($table) {
		});
		Schema::table('tasks', function($table) {
			$table->foreign('milestone_id')->references('id')->on('milestones')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('teamachievements', function($table) {
		});
		Schema::table('users', function($table) {
		});
		Schema::table('users_personalachievements', function($table) {
			$table->foreign('personalachievement_id')->references('id')->on('personalachievements')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
		Schema::table('users_projects', function($table) {
			$table->foreign('project_id')->references('id')->on('projects')->onUpdate('cascade')->onDelete('cascade');
			$table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('cascade');
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
	}

}
