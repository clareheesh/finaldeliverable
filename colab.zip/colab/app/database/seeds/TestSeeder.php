<?php

class TestSeeder extends Seeder {

	/**
	 * Run the database seeds. All sample data. Do not use on live version
	 *
	 * @return void
	 */
	public function run()
	{
		//Test User
		$user = new User;
		$user->first_name = 'Test';
		$user->last_name = 'User';
		$user->password = Hash::make('password');
		$user->display_name = 'Test User';
		$user->email = 'testuser@gmail.com';
		$user->save();	
		$testuser = new User;
		$testuser->first_name = 'Test';
		$testuser->last_name = 'User';
		$testuser->password = Hash::make('password');
		$testuser->display_name = 'Test User';
		$testuser->email = 'testuser2@gmail.com';
		$testuser->save();	
		
		//Test Project
		$project = new Project;
		$project->name = 'Test Project';
		$project->description = 'Project for testing environment';
		$project->start_date = "2014-01-01";
		$project->end_date = "2014-01-01";
		$project->save();	
		
		//Add user to project
		$project->addUser($user->id);
		
		//Test Milestone
		$milestone = new Milestone;
		$milestone->name = "Test Milestone";
		$milestone->start_date = "2014-01-01";
		$milestone->end_date = "2014-01-01";
		$milestone->project_id = $project->id;
		$milestone->save();
		
		//Test Task
		$task = new Task();
		$task->name = "Test Task";
		$task->description = "Task for testing purposes";
		$task->start_date = "2014-01-01";
		$task->end_date = "2014-01-01";
		$task->user_id = $user->id;
		$task->milestone_id=$milestone->id;
		$task->progress = 0;
		$task->save();
		$finishedtask = new Task();
		$finishedtask->name = "Finished Test Task";
		$finishedtask->description = "Task for testing purposes";
		$finishedtask->start_date = "2014-01-01";
		$finishedtask->end_date = "2014-01-01";
		$finishedtask->user_id = $user->id;
		$finishedtask->milestone_id=$milestone->id;
		$finishedtask->progress = 100;
		$finishedtask->save();
		
		//Test Post
		$post  = new Post;
		$post->project_id = $project->id;
		$post->table = 'tasks';
		$post->TB_id = 1;
		$post->save();
		
		//Test Acknowledgement
		$ack = new Acknowledgement;
		$ack->user_id = $user->id;
		$ack->task_id = $task->id;
		$ack->post_id = $post->id;
		$ack->save();
		
		//Test Comment
		$comment = new Comment;
		$comment->user_id = $user->id;
		$comment->post_id = $post->id;
		$comment->comment = "Test Comment";
		$comment->save();	
		
		//Test Rule
		$rule = new Rule;
		$rule->description = "Test Rule";
		$rule->project_id = $project->id;
		$rule->save();
		
		//Team achievement
		DB::table('projects_teamachievements')->insert(
			array('id' => 1, 'project_id' => 1,'teamachievement_id' => 1, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
	
		//Personal achievement
		DB::table('users_personalachievements')->insert(
			array('id' => 1, 'user_id' => 2, 'project_id' => 1, 'personalachievement_id' => 1, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//Message Lobby
		DB::table('message_lobbies')->insert(
			array('id' => 1, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//Message Lobbby Users
		DB::table('message_lobby_users')->insert(
			array('id' => 1, 'message_lobby_id' => 1, 'user_id' => 2, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//Message
		DB::table('messages')->insert(
			array('id' => 1, 'contents' => 'Test Message', 'message_lobby_id' => 1, 'user_id' => 2, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//Message Read
		DB::table('messages_read')->insert(
			array('id' => 1, 'lobby_id' => 1, 'user_id' => 2, 'read' => 0, 'message_id' => 1, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//Datafile
		DB::table('datafiles')->insert(
			array('id' => 1, 'user_id' => 2, 'project_id' => 1, 'name' => 'Test File', 'type' => 'text/plain', 'description' => 'Test File', 'size' => 0, 'destination' => '','created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//User education
		DB::table('education')->insert(
			array('id' => 1, 'user_id' => 2,'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//User education
		DB::table('interests')->insert(
			array('id' => 1, 'user_id' => 2,'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//User Job
		DB::table('jobs')->insert(
			array('id' => 1, 'user_id' => 2,'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//User Skill
		DB::table('skills')->insert(
			array('id' => 1, 'user_id' => 2,'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
		
		//Group Meetings
		DB::table('meetings')->insert(
			array('id' => 1, 'description' => 'Test Meeting', 'project_id' => 1, 'start_date' => '2014-01-01', 'end_date' => '2014-01-01', 'start_time' => '00:00:00',  'end_time' => '00:00:00', 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
		);
	}
	
}