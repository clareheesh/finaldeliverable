<?php

class SampleSeeder extends Seeder {

	/**
	 * Run the database seeds. All sample data. Do not use on live version
	 *
	 * @return void
	 */
	public function run()
	{
	
		Eloquent::unguard();
		
		$this->call('DefaultSeeder');

		//--Users--//
		// Jacob
		$obj = DB::table('users')->where('email', '=', 'jacob23791@gmail.com')->first();   // this will return NULL if empty
		if(!$obj) {
		  	User::create(array(
				'email'    => 'jacob23791@gmail.com',
				'password' => Hash::make('password'),
				'first_name'     => 'Jacob',
				'last_name' => 'Klein',
				'display_name' => 'Jacob Klein',
				'date_of_birth' => '1991-07-23',
				'phone' => '0412148038',
				'location' => 'Brisbane',
				'about' => 'too cool for school',		
			));
		}
		
		// Clare
		$obj = DB::table('users')->where('email', '=', 'clareheesh@gmail.com')->first();   // this will return NULL if empty
		if(!$obj) {
		  	User::create(array(
				'email'    => 'clareheesh@gmail.com',
				'password' => Hash::make('password'),
				'first_name'     => 'Clare',
				'last_name' => 'Heesh',
				'display_name' => 'Clare Heesh',
			));
		}
		// Andy
		$obj = DB::table('users')->where('email', '=', 'andytest@gmail.com')->first();   // this will return NULL if empty
		if(!$obj) {
		  	User::create(array(
				'email'    => 'andytest@gmail.com',
				'password' => Hash::make('password'),
				'first_name'     => 'Andy',
				'last_name' => 'Schaul',
				'display_name' => 'Andy Schaul',		
			));
		}
		// Kate
		$obj = DB::table('users')->where('email', '=', 'katelouisew@gmail.com')->first();   // this will return NULL if empty
		if(!$obj) {
		  	User::create(array(
				'email'    => 'katelouisew@gmail.com',
				'password' => Hash::make('password'),
				'first_name'     => 'Kate',
				'last_name' => 'Weir',
				'display_name' => 'Kate Weir',
			));
		}
		// Mitchell
		$obj = DB::table('users')->where('email', '=', 'mitchell.stringfellow@uqconnect.edu.au')->first();   // this will return NULL if empty
		if(!$obj) {
		  	User::create(array(
				'email'    => 'mitchell.stringfellow@uqconnect.edu.au',
				'password' => Hash::make('password'),
				'first_name'     => 'Mitchell',
				'last_name' => 'Stringfellow',
				'display_name' => 'Mitchell Stringfellow',
			));
		}		
		// Ben
		$obj = DB::table('users')->where('email', '=', 'benjamin.byron@uqconnect.edu.au')->first();   // this will return NULL if empty
		if(!$obj) {
		  	User::create(array(
				'email'    => 'benjamin.byron@uqconnect.edu.au',
				'password' => Hash::make('password'),
				'first_name'     => 'Benjamin',
				'last_name' => 'Byron',
				'display_name' => 'Benjamin Byron',
			));
		}

		//Create Project
		$obj = DB::table('projects')->where('id', '=', '2')->first();   // this will return NULL if empty
		if(!$obj) {
		  	Project::create(array(
				'id' => 2,
				'name'    => "CoLab", 
				'description' => 'Best project in the world',
				'start_date' => '2014-07-28',
				'end_date' => '2014-11-23',
			));
		}
		
		//Add Users
		for ($i = 2; $i<=7; $i++){
			$obj = DB::table('users_projects')->where('id', '=', $i)->first();   // this will return NULL if empty
			if(!$obj) {
				DB::table('users_projects')->insert(
					array('id' => $i, 'user_id' => $i,'project_id'=> 2, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
				);
				DB::table('stress')->insert(
					array('user_id' => $i, 'project_id' => 2, 'stress_level' => "None", 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
				);			
			}
		}
		//Add Milestone
		$obj = DB::table('milestones')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('milestones')->insert(
				array('id' => 1, 'name' => 'Final Product Demonstration','project_id'=> 2,'start_date' => '2014-07-28','end_date' => '2014-11-23', 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		
		//Add task
		$obj = DB::table('tasks')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('tasks')->insert(
				array('id' => 1, 'name' => 'Redesign Existing Database', 'description' => 'Redesign Database','milestone_id'=> 1,'user_id'=> 2,'start_date' => '2014-07-28','end_date' => '2014-11-23', 'progress' => 50, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		$obj = DB::table('tasks')->where('id', '=', '2')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('tasks')->insert(
				array('id' => 2, 'name' => 'Add messages to database', 'description' => 'Add messages to database','milestone_id'=> 1, 'user_id'=> 1,'start_date' => '2014-07-28','end_date' => '2014-11-23', 'progress' => 0, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		$obj = DB::table('tasks')->where('id', '=', '3')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('tasks')->insert(
				array('id' => 3, 'name' => 'Add timeline comments to database', 'description' => 'Add timeline comments to database','milestone_id'=> 1, 'user_id'=> 2, 'start_date' => '2014-07-28','end_date' => '2014-11-23', 'progress' => 0, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		
		//Add post
		$obj = DB::table('posts')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('posts')->insert(
				array('id' => 1,'project_id' => 2,'table' => 'tasks','TB_id' => 1, 'created_at'=>'2014-09-17 08:28:24', 'updated_at' => '2014-09-17 08:28:24')
			);
		}
		//--Post Comment--//
		$obj = DB::table('posts_comments')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('posts_comments')->insert(
				array('id' => 1,'user_id' => 3, 'post_id' => 1, 'comment' => 'OMG you are so awesome', 'created_at'=>'2014-09-17 08:28:24', 'updated_at' => '2014-09-17 08:28:24')
			);
		}
		$obj = DB::table('posts_comments')->where('id', '=', '2')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('posts_comments')->insert(
				array('id' => 2,'user_id' => 2, 'post_id' => 1, 'comment' => 'I know', 'created_at'=>'2014-09-17 08:28:24', 'updated_at' => '2014-09-17 08:28:24')
			);
		}		
		
		//--Acknowledge--//
		for ($i = 1; $i<5; $i++){
			$obj = DB::table('acknowledgements')->where('id', '=', $i)->first();   // this will return NULL if empty
			if(!$obj) {
				DB::table('acknowledgements')->insert(
					array('id' => $i, 'user_id' => ($i+2), 'task_id' => 1, 'post_id' => 1, 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
				);
			}
		}

	}

}