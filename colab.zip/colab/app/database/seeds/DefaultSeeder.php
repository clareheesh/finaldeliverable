<?php

class DefaultSeeder extends Seeder {

	/**
	 * Run the database seeds. All sample data. Do not use on live version
	 *
	 * @return void
	 */
	public function run()
	{
		Eloquent::unguard();

		//--Team Achievements--//
		$obj = DB::table('teamachievements')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('teamachievements')->insert(
				array('id' => 1, 'name' => 'Group Love', 'description' => 'Have a member\'s task acknowledged by the rest of the team','icon' => 'heart', 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		$obj = DB::table('teamachievements')->where('id', '=', '2')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('teamachievements')->insert(
				array('id' => 2, 'name' => 'Synergy', 'description' => 'Complete the project','icon' => 'globe', 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
				
		//--Personal Achievements--//
		$obj = DB::table('personalachievements')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('personalachievements')->insert(
				array('id' => 1, 'name' => 'First Step', 'description' => 'Completed their first task','icon' => 'tasks', 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		$obj = DB::table('personalachievements')->where('id', '=', '2')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('personalachievements')->insert(
				array('id' => 2, 'name' => 'The Last Step', 'description' => 'Completed all tasks','icon' => 'check', 'created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		
		//--Notification Category--//
		$obj = DB::table('notification_categories')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('notification_categories')->insert(
				array('id' => 1, 'name' => 'acknowledgement', 'text' => '{User.first_name} has acknowledged "{extra}"','created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		$obj = DB::table('notification_categories')->where('id', '=', '2')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('notification_categories')->insert(
				array('id' => 2, 'name' => 'achievement', 'text' => 'The group has unlocked the team achievement <strong>{extra}</strong>!','created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		$obj = DB::table('notification_categories')->where('id', '=', '3')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('notification_categories')->insert(
				array('id' => 3, 'name' => 'newmeeting', 'text' => 'A new meeting has been set for {extra}','created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		$obj = DB::table('notification_categories')->where('id', '=', '4')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('notification_categories')->insert(
				array('id' => 4, 'name' => 'newtask', 'text' => 'You have been assigned a new task "{extra}"','created_at'=>'2014-09-17 08:33:24', 'updated_at' => '2014-09-17 08:33:24')
			);
		}
		
		//--Stress Tips--//
		$obj = DB::table('stress_tips')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 1, 'content' => "<strong>Meditate</strong> A few minutes of practice per day can help ease anxiety. “Research suggests that daily meditation may alter the brain’s neural pathways, making you more resilient to stress,” says psychologist Robbie Maller Hartman, PhD, a Chicago health and wellness coach. It's simple. Sit up straight with both feet on the floor. Close your eyes. Focus your attention on reciting -- out loud or silently -- a positive mantra such as “I feel at peace” or “I love myself.” Place one hand on your belly to sync the mantra with your breaths. Let any distracting thoughts float by like clouds.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		
		$obj = DB::table('stress_tips')->where('id', '=', '2')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 2, 'content' => "<strong>Breathe Deeply</strong> Take a 5-minute break and focus on your breathing. Sit up straight, eyes closed, with a hand on your belly. Slowly inhale through your nose, feeling the breath start in your abdomen and work its way to the top of your head. Reverse the process as you exhale through your mouth. “Deep breathing counters the effects of stress by slowing the heart rate and lowering blood pressure,” psychologist Judith Tutin, PhD, says. She's a certified life coach in Rome, GA.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		
		$obj = DB::table('stress_tips')->where('id', '=', '3')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 3, 'content' => "<strong>Be Present</strong> Slow down.“Take 5 minutes and focus on only one behavior with awareness,” Tutin says. Notice how the air feels on your face when you’re walking and how your feet feel hitting the ground. Enjoy the texture and taste of each bite of food. When you spend time in the moment and focus on your senses, you should feel less tense.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		$obj = DB::table('stress_tips')->where('id', '=', '4')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 4, 'content' => "<strong>Reach Out</strong> Your social network is one of your best tools for handling stress. Talk to others -- preferably face to face, or at least on the phone. Share what's going on. You can get a fresh perspective while keeping your connection strong.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		$obj = DB::table('stress_tips')->where('id', '=', '5')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 5, 'content' => "<strong>Tune In to Your Body</strong> Mentally scan your body to get a sense of how stress affects it each day. Lie on your back, or sit with your feet on the floor. Start at your toes and work your way up to your scalp, noticing how your body feels. “Simply be aware of places you feel tight or loose without trying to change anything,” Tutin says. For 1 to 2 minutes, imagine each deep breath flowing to that body part. Repeat this process as you move your focus up your body, paying close attention to sensations you feel in each body part.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		
		$obj = DB::table('stress_tips')->where('id', '=', '6')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 6, 'content' => "<strong>Decompress</strong> Place a warm heat wrap around your neck and shoulders for 10 minutes. Close your eyes and relax your face, neck, upper chest, and back muscles. Remove the wrap, and use a tennis ball or foam roller to massage away tension. “Place the ball between your back and the wall. Lean into the ball, and hold gentle pressure for up to 15 seconds. Then move the ball to another spot, and apply pressure,” says Cathy Benninger, a nurse practitioner and assistant professor at The Ohio State University Wexner Medical Center in Columbus", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		
		$obj = DB::table('stress_tips')->where('id', '=', '7')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 7, 'content' => "<strong>Laugh Out Loud</strong> A good belly laugh doesn’t just lighten the load mentally. It lowers cortisol, your body’s stress hormone, and boosts brain chemicals called endorphins, which help your mood. Lighten up by tuning in to your favorite sitcom or video, reading the comics, or chatting with someone who makes you smile.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		
		$obj = DB::table('stress_tips')->where('id', '=', '8')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 8, 'content' => "<strong>Crank Up the Tunes</strong> Research shows that listening to soothing music can lower blood pressure, heart rate, and anxiety. “Create a playlist of songs or nature sounds (the ocean, a bubbling brook, birds chirping), and allow your mind to focus on the different melodies, instruments, or singers in the piece,” Benninger says. You also can blow off steam by rocking out to more upbeat tunes -- or singing at the top of your lungs!", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		$obj = DB::table('stress_tips')->where('id', '=', '9')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 9, 'content' => "<strong>Get Moving</strong> You don’t have to run in order to get a runner’s high. All forms of exercise, including yoga and walking, can ease depression and anxiety by helping the brain release feel-good chemicals and by giving your body a chance to practice dealing with stress. You can go for a quick walk around the block, take the stairs up and down a few flights, or do some stretching exercises like head rolls and shoulder shrugs.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		$obj = DB::table('stress_tips')->where('id', '=', '10')->first();   // this will return NULL if empty
		if(!$obj) {
			DB::table('stress_tips')->insert(
				array('id' => 10, 'content' => "<strong>Be Grateful</strong> Keep a gratitude journal or several (one by your bed, one in your purse, and one at work) to help you remember all the things that are good in your life. “Being grateful for your blessings cancels out negative thoughts and worries,” says Joni Emmerling, a wellness coach in Greenville, NC. Use these journals to savor good experiences like a child’s smile, a sunshine-filled day, and good health. Don’t forget to celebrate accomplishments like mastering a new task at work or a new hobby. When you start feeling stressed, spend a few minutes looking through your notes to remind yourself what really matters.", 'source_name' => 'WebMD', 'source_url' => 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot')
			);
		}
		
		// Not Assigned
		$obj = DB::table('users')->where('id', '=', '1')->first();   // this will return NULL if empty
		if(!$obj) {
		  	User::create(array(
				'id' => 1,
				'email'    => 'not@assigned.com',
				'password' => '',
				'first_name'     => 'Not',
				'last_name' => 'Assigned',
				'display_name' => 'Not Assigned',		
			));
		}

	}
}