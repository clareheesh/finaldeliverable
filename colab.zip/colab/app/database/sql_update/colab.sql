-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 27, 2014 at 02:16 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `colab`
--

-- --------------------------------------------------------

--
-- Table structure for table `acknowledgements`
--

CREATE TABLE IF NOT EXISTS `acknowledgements` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `acknowledgements`
--

INSERT INTO `acknowledgements` (`id`, `user_id`, `task_id`, `post_id`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 1, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(2, 4, 1, 1, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(3, 5, 1, 1, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(4, 6, 1, 1, '2014-09-16 22:33:24', '2014-09-16 22:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `datafiles`
--

CREATE TABLE IF NOT EXISTS `datafiles` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `destination` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `datafiles`
--

INSERT INTO `datafiles` (`id`, `user_id`, `project_id`, `name`, `type`, `description`, `destination`, `size`, `created_at`, `updated_at`) VALUES
(1, 4, 2, 'Tickets Outline.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Outline of Future Github Tickets', '/Applications/XAMPP/xamppfiles/htdocs/colabfinal/public/uploads', '87243', '2014-10-26 23:14:30', '2014-10-26 23:14:30'),
(2, 2, 2, 'colab.sql', 'text/plain', 'New sql document', '/Applications/XAMPP/xamppfiles/htdocs/colabfinal/public/uploads', '38877', '2014-10-27 01:05:15', '2014-10-27 01:05:15');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE IF NOT EXISTS `education` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `place` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `graduation_year` int(11) NOT NULL,
  `gpa` float(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `user_id`, `title`, `place`, `field`, `graduation_year`, `gpa`, `created_at`, `updated_at`) VALUES
(2, 2, '', '', '', 0, 0.00, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 3, '', '', '', 0, 0.00, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 4, 'Information Technology', 'University of Queensland', 'Bachelor', 2014, 5.00, '0000-00-00 00:00:00', '2014-10-26 23:09:08'),
(5, 5, '', '', '', 0, 0.00, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 6, '', '', '', 0, 0.00, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 7, 'Mathematics', 'University of Queensland', 'Bachelor', 2015, 5.00, '0000-00-00 00:00:00', '2014-10-27 00:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `interests`
--

CREATE TABLE IF NOT EXISTS `interests` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `hobby` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pet` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `food` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `interests`
--

INSERT INTO `interests` (`id`, `user_id`, `hobby`, `pet`, `food`, `created_at`, `updated_at`) VALUES
(2, 2, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 3, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 4, 'Reading', 'Dog', 'Pizza', '0000-00-00 00:00:00', '2014-10-26 23:09:08'),
(5, 5, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 6, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 7, 'Sleeping', 'Dog', 'Muesli Bars', '0000-00-00 00:00:00', '2014-10-27 00:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `department` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `user_id`, `name`, `company`, `location`, `department`, `date`, `created_at`, `updated_at`) VALUES
(2, 2, '', '', '', '', '0000-00-00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 3, '', '', '', '', '0000-00-00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 4, 'Fruit Picker', 'Sun Burst', 'Brisbane', '', '2012-01-01', '0000-00-00 00:00:00', '2014-10-26 23:13:28'),
(5, 5, '', '', '', '', '0000-00-00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 6, '', '', '', '', '0000-00-00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 7, '', '', '', '', '0000-00-00', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `meetings`
--

CREATE TABLE IF NOT EXISTS `meetings` (
`id` int(10) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `contents` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message_lobby_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `created_at`, `updated_at`, `contents`, `user_id`, `message_lobby_id`) VALUES
(1, '2014-10-26 23:15:34', '2014-10-26 23:15:34', 'Have a look at the new tickets document I''ve uploaded.', 4, 1),
(2, '2014-10-27 00:37:19', '2014-10-27 00:37:19', 'A new team blog has been put up!', 7, 2),
(3, '2014-10-27 01:04:16', '2014-10-27 01:04:16', 'Looks good.', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages_read`
--

CREATE TABLE IF NOT EXISTS `messages_read` (
`id` int(10) unsigned NOT NULL,
  `lobby_id` int(10) unsigned NOT NULL,
  `message_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `read` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `messages_read`
--

INSERT INTO `messages_read` (`id`, `lobby_id`, `message_id`, `user_id`, `read`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2, 1, '2014-10-26 23:15:34', '2014-10-26 23:15:34'),
(2, 1, 1, 3, 0, '2014-10-26 23:15:34', '2014-10-26 23:15:34'),
(3, 1, 1, 6, 0, '2014-10-26 23:15:34', '2014-10-26 23:15:34'),
(4, 2, 2, 2, 1, '2014-10-27 00:37:19', '2014-10-27 00:37:19'),
(5, 2, 2, 3, 0, '2014-10-27 00:37:19', '2014-10-27 00:37:19'),
(6, 2, 2, 4, 0, '2014-10-27 00:37:19', '2014-10-27 00:37:19'),
(7, 2, 2, 5, 0, '2014-10-27 00:37:19', '2014-10-27 00:37:19'),
(8, 2, 2, 6, 0, '2014-10-27 00:37:19', '2014-10-27 00:37:19'),
(9, 1, 3, 4, 0, '2014-10-27 01:04:16', '2014-10-27 01:04:16'),
(10, 1, 3, 3, 0, '2014-10-27 01:04:16', '2014-10-27 01:04:16'),
(11, 1, 3, 6, 0, '2014-10-27 01:04:16', '2014-10-27 01:04:16');

-- --------------------------------------------------------

--
-- Table structure for table `message_lobbies`
--

CREATE TABLE IF NOT EXISTS `message_lobbies` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `message_lobbies`
--

INSERT INTO `message_lobbies` (`id`, `created_at`, `updated_at`) VALUES
(1, '2014-10-26 23:15:34', '2014-10-27 01:04:16'),
(2, '2014-10-27 00:37:19', '2014-10-27 00:37:19');

-- --------------------------------------------------------

--
-- Table structure for table `message_lobby_users`
--

CREATE TABLE IF NOT EXISTS `message_lobby_users` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message_lobby_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `message_lobby_users`
--

INSERT INTO `message_lobby_users` (`id`, `created_at`, `updated_at`, `message_lobby_id`, `user_id`) VALUES
(1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 4),
(2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 2),
(3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 3),
(4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 6),
(5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 7),
(6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 2),
(7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 3),
(8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 4),
(9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 5),
(10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_09_17_020504_setup', 1),
('2014_09_22_103237_database_fix_1', 1),
('2014_09_23_000115_post_comments', 1),
('2014_09_23_024035_messages', 1),
('2014_10_17_014855_stress_tips', 1),
('2014_10_17_033801_messages_read', 1),
('2014_10_23_124703_profile_image', 1),
('2014_10_25_110002_global_notifications', 1),
('2014_10_25_115156_achievement_update', 1);

-- --------------------------------------------------------

--
-- Table structure for table `milestones`
--

CREATE TABLE IF NOT EXISTS `milestones` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `soft_delete` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `milestones`
--

INSERT INTO `milestones` (`id`, `name`, `start_date`, `end_date`, `project_id`, `soft_delete`, `created_at`, `updated_at`) VALUES
(1, 'Final Product Demonstration', '2014-07-28', '2014-11-23', 2, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(2, 'Finish all of the team blogs over the semester', '2014-08-01', '2014-10-28', 2, 0, '2014-10-27 00:52:09', '2014-10-27 00:52:09');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
`id` int(10) unsigned NOT NULL,
  `to_id` int(10) unsigned NOT NULL,
  `from_id` int(10) unsigned NOT NULL,
  `from_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `to_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extra` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `read` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `project_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `to_id`, `from_id`, `from_type`, `to_type`, `category_id`, `url`, `extra`, `read`, `created_at`, `updated_at`, `project_id`) VALUES
(1, 4, 4, '', '', 4, 'http://localhost/colabfinal/public/projects/project/2/overview', 'Finish Profile Page', 1, '2014-10-26 23:12:05', '2014-10-26 23:12:05', 2),
(2, 4, 4, '', '', 4, 'http://localhost/colabfinal/public/projects/project/2/overview', 'Fill in Profile Information', 1, '2014-10-27 00:32:23', '2014-10-27 00:32:23', 2),
(3, 7, 7, '', '', 4, 'http://localhost/colabfinal/public/projects/project/2/overview', 'Finish last blog', 0, '2014-10-27 00:53:21', '2014-10-27 00:53:21', 2),
(4, 5, 5, '', '', 4, 'http://localhost/colabfinal/public/projects/project/2/overview', 'Poster', 0, '2014-10-27 01:11:59', '2014-10-27 01:11:59', 2);

-- --------------------------------------------------------

--
-- Table structure for table `notification_categories`
--

CREATE TABLE IF NOT EXISTS `notification_categories` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `notification_categories`
--

INSERT INTO `notification_categories` (`id`, `name`, `text`, `created_at`, `updated_at`) VALUES
(1, 'acknowledgement', '{User.first_name} has acknowledged "{extra}"', '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(2, 'achievement', 'The group has unlocked the team achievement <strong>{extra}</strong>!', '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(3, 'newmeeting', 'A new meeting has been set for {extra}', '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(4, 'newtask', 'You have been assigned a new task "{extra}"', '2014-09-16 22:33:24', '2014-09-16 22:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `personalachievements`
--

CREATE TABLE IF NOT EXISTS `personalachievements` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `personalachievements`
--

INSERT INTO `personalachievements` (`id`, `name`, `description`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'First Step', 'Completed their first task', 'tasks', '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(2, 'The Last Step', 'Completed all tasks', 'check', '2014-09-16 22:33:24', '2014-09-16 22:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
`id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `table` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TB_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `project_id`, `table`, `TB_id`, `created_at`, `updated_at`) VALUES
(1, 2, 'tasks', '1', '2014-09-16 22:28:24', '2014-09-16 22:28:24'),
(2, 2, 'stress', '7', '2014-10-26 23:12:23', '2014-10-26 23:12:23'),
(3, 2, 'personalachievements', '1', '2014-10-27 00:31:19', '2014-10-27 00:31:19'),
(4, 2, 'personalachievements', '2', '2014-10-27 00:31:19', '2014-10-27 00:31:19'),
(5, 2, 'tasks', '4', '2014-10-27 00:31:19', '2014-10-27 00:31:19'),
(6, 2, 'stress', '8', '2014-10-27 00:32:48', '2014-10-27 00:32:48');

-- --------------------------------------------------------

--
-- Table structure for table `posts_comments`
--

CREATE TABLE IF NOT EXISTS `posts_comments` (
`id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `comment` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `posts_comments`
--

INSERT INTO `posts_comments` (`id`, `created_at`, `updated_at`, `user_id`, `post_id`, `comment`) VALUES
(1, '2014-09-16 22:28:24', '2014-09-16 22:28:24', 3, 1, 'OMG you are so awesome'),
(2, '2014-09-16 22:28:24', '2014-09-16 22:28:24', 2, 1, 'I know');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hobbies` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hair_colour` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `eye_colour` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `height` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zodiac_sign` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pets` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bad_habits` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `best_friend` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `future_goals` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `three_words` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `favourite_song` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `favourite_movie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `favourite_celebrity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `description`, `start_date`, `end_date`, `created_at`, `updated_at`) VALUES
(1, 'Empty Project', 'Best project in the world', '2014-07-28', '2014-11-23', '2014-10-26 12:37:05', '2014-10-26 12:37:05'),
(2, 'CoLab', 'Best project in the world', '2014-07-28', '2014-11-23', '2014-10-26 12:37:05', '2014-10-26 12:37:05');

-- --------------------------------------------------------

--
-- Table structure for table `projects_teamachievements`
--

CREATE TABLE IF NOT EXISTS `projects_teamachievements` (
`id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `teamachievement_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rules`
--

CREATE TABLE IF NOT EXISTS `rules` (
`id` int(10) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `rules`
--

INSERT INTO `rules` (`id`, `description`, `project_id`, `created_at`, `updated_at`) VALUES
(4, 'No foul or offensive language', 2, '2014-10-26 23:17:36', '2014-10-26 23:17:36'),
(6, 'Give prior notice if you will be unable to attend a meeting', 2, '2014-10-26 23:18:35', '2014-10-26 23:18:35'),
(7, 'Be on time to meetings', 2, '2014-10-26 23:18:44', '2014-10-26 23:18:44'),
(8, 'Keep group members apprised of what you are working on and how you are going', 2, '2014-10-26 23:19:09', '2014-10-26 23:19:09');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE IF NOT EXISTS `skills` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ability` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `user_id`, `field`, `ability`, `description`, `created_at`, `updated_at`) VALUES
(2, 2, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 3, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 4, 'Recreation', 'Juggling', '', '0000-00-00 00:00:00', '2014-10-26 23:09:08'),
(5, 5, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 6, '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 7, 'Computing', 'Civ', '', '0000-00-00 00:00:00', '2014-10-27 00:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `stress`
--

CREATE TABLE IF NOT EXISTS `stress` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `stress_level` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `stress`
--

INSERT INTO `stress` (`id`, `user_id`, `project_id`, `stress_level`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(2, 3, 2, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(3, 4, 2, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(4, 5, 2, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(5, 6, 2, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(6, 7, 2, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(7, 4, 2, 1, '2014-10-26 23:12:23', '2014-10-26 23:12:23'),
(8, 4, 2, 2, '2014-10-27 00:32:48', '2014-10-27 00:32:48');

-- --------------------------------------------------------

--
-- Table structure for table `stress_tips`
--

CREATE TABLE IF NOT EXISTS `stress_tips` (
`id` int(10) unsigned NOT NULL,
  `content` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `source_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `stress_tips`
--

INSERT INTO `stress_tips` (`id`, `content`, `source_name`, `source_url`) VALUES
(1, '<strong>Meditate</strong> A few minutes of practice per day can help ease anxiety. “Research suggests that daily meditation may alter the brain’s neural pathways, making you more resilient to stress,” says psychologist Robbie Maller Hartman, PhD, a Chicago health and wellness coach. It''s simple. Sit up straight with both feet on the floor. Close your eyes. Focus your attention on reciting -- out loud or silently -- a positive mantra such as “I feel at peace” or “I love myself.” Place one hand on your belly to sync the mantra with your breaths. Let any distracting thoughts float by like clouds.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(2, '<strong>Breathe Deeply</strong> Take a 5-minute break and focus on your breathing. Sit up straight, eyes closed, with a hand on your belly. Slowly inhale through your nose, feeling the breath start in your abdomen and work its way to the top of your head. Reverse the process as you exhale through your mouth. “Deep breathing counters the effects of stress by slowing the heart rate and lowering blood pressure,” psychologist Judith Tutin, PhD, says. She''s a certified life coach in Rome, GA.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(3, '<strong>Be Present</strong> Slow down.“Take 5 minutes and focus on only one behavior with awareness,” Tutin says. Notice how the air feels on your face when you’re walking and how your feet feel hitting the ground. Enjoy the texture and taste of each bite of food. When you spend time in the moment and focus on your senses, you should feel less tense.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(4, '<strong>Reach Out</strong> Your social network is one of your best tools for handling stress. Talk to others -- preferably face to face, or at least on the phone. Share what''s going on. You can get a fresh perspective while keeping your connection strong.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(5, '<strong>Tune In to Your Body</strong> Mentally scan your body to get a sense of how stress affects it each day. Lie on your back, or sit with your feet on the floor. Start at your toes and work your way up to your scalp, noticing how your body feels. “Simply be aware of places you feel tight or loose without trying to change anything,” Tutin says. For 1 to 2 minutes, imagine each deep breath flowing to that body part. Repeat this process as you move your focus up your body, paying close attention to sensations you feel in each body part.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(6, '<strong>Decompress</strong> Place a warm heat wrap around your neck and shoulders for 10 minutes. Close your eyes and relax your face, neck, upper chest, and back muscles. Remove the wrap, and use a tennis ball or foam roller to massage away tension. “Place the ball between your back and the wall. Lean into the ball, and hold gentle pressure for up to 15 seconds. Then move the ball to another spot, and apply pressure,” says Cathy Benninger, a nurse practitioner and assistant professor at The Ohio State University Wexner Medical Center in Columbus', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(7, '<strong>Laugh Out Loud</strong> A good belly laugh doesn’t just lighten the load mentally. It lowers cortisol, your body’s stress hormone, and boosts brain chemicals called endorphins, which help your mood. Lighten up by tuning in to your favorite sitcom or video, reading the comics, or chatting with someone who makes you smile.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(8, '<strong>Crank Up the Tunes</strong> Research shows that listening to soothing music can lower blood pressure, heart rate, and anxiety. “Create a playlist of songs or nature sounds (the ocean, a bubbling brook, birds chirping), and allow your mind to focus on the different melodies, instruments, or singers in the piece,” Benninger says. You also can blow off steam by rocking out to more upbeat tunes -- or singing at the top of your lungs!', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(9, '<strong>Get Moving</strong> You don’t have to run in order to get a runner’s high. All forms of exercise, including yoga and walking, can ease depression and anxiety by helping the brain release feel-good chemicals and by giving your body a chance to practice dealing with stress. You can go for a quick walk around the block, take the stairs up and down a few flights, or do some stretching exercises like head rolls and shoulder shrugs.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot'),
(10, '<strong>Be Grateful</strong> Keep a gratitude journal or several (one by your bed, one in your purse, and one at work) to help you remember all the things that are good in your life. “Being grateful for your blessings cancels out negative thoughts and worries,” says Joni Emmerling, a wellness coach in Greenville, NC. Use these journals to savor good experiences like a child’s smile, a sunshine-filled day, and good health. Don’t forget to celebrate accomplishments like mastering a new task at work or a new hobby. When you start feeling stressed, spend a few minutes looking through your notes to remind yourself what really matters.', 'WebMD', 'http://www.webmd.com/balance/guide/blissing-out-10-relaxation-techniques-reduce-stress-spot');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `milestone_id` int(10) unsigned NOT NULL,
  `progress` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `soft_delete` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `description`, `start_date`, `end_date`, `user_id`, `milestone_id`, `progress`, `created_at`, `updated_at`, `soft_delete`) VALUES
(1, 'Redesign Existing Database', 'Redesign Database', '2014-07-28', '2014-11-23', 2, 1, 50, '2014-09-16 22:33:24', '2014-09-16 22:33:24', 0),
(2, 'Add messages to database', 'Add messages to database', '2014-07-28', '2014-11-23', 1, 1, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24', 0),
(3, 'Add timeline comments to database', 'Add timeline comments to database', '2014-07-28', '2014-11-23', 2, 1, 0, '2014-09-16 22:33:24', '2014-09-16 22:33:24', 0),
(4, 'Finish Profile Page', 'Finish implementing the uploading of profile pictures and the editing and saving of profile information.', '2014-10-23', '2014-10-27', 4, 1, 100, '2014-10-26 23:12:05', '2014-10-27 00:31:19', 0),
(5, 'Fill in Profile Information', 'Fill in profiles with information to show normal use.', '2014-10-26', '2014-10-27', 4, 1, 0, '2014-10-27 00:32:23', '2014-10-27 00:32:23', 0),
(6, 'Finish last blog', 'Finished the final blog for the semester.', '2014-10-27', '2014-10-28', 7, 2, 10, '2014-10-27 00:53:21', '2014-10-27 00:54:54', 0),
(7, 'Poster', 'Get poster finished and printed', '2014-10-13', '2014-10-16', 5, 1, 0, '2014-10-27 01:11:59', '2014-10-27 01:11:59', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teamachievements`
--

CREATE TABLE IF NOT EXISTS `teamachievements` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `teamachievements`
--

INSERT INTO `teamachievements` (`id`, `name`, `description`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'Group Love', 'Have a member''s task acknowledged by the rest of the team', 'heart', '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(2, 'Synergy', 'Complete the project', 'globe', '2014-09-16 22:33:24', '2014-09-16 22:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_of_birth` date NOT NULL DEFAULT '0000-00-00',
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `about` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `remember_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `display_picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default.png'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `first_name`, `last_name`, `display_name`, `date_of_birth`, `phone`, `location`, `about`, `remember_token`, `created_at`, `updated_at`, `display_picture`) VALUES
(1, 'not@assigned.com', '', 'Not', 'Assigned', 'Not Assigned', '0000-00-00', '', '', '', '', '2014-10-26 12:37:05', '2014-10-26 12:37:05', 'default.png'),
(2, 'jacob23791@gmail.com', '$2y$10$M7mWk.MXN12I70RTvVxHj.XAtz1ZEdqVG64w29lJY5FgNQCWjBnNi', 'Jacob', 'Klein', 'Jacob Klein', '1991-07-23', '0412148038', '', 'too cool for school', 'ORHdIeHQUhGGwgWDMx6lVdEj6IQP3xZP6jJW0WvtbIPwECpeAek9HImAPX1G', '2014-10-26 12:37:05', '2014-10-27 01:06:17', '2.jpg'),
(3, 'clareheesh@gmail.com', '$2y$10$7aZd/27fBsokl8uOiTNzGOJFpPyZV5BuiLNdM/3o4hiEy93D1fjMS', 'Clare', 'Heesh', 'Clare Heesh', '0000-00-00', '', '', '', 'cgctCJpv7hnGeRYQ0VyP2QX9WuNdYRJetU3CQ0wK4D2EXhHqRhrSSAtzZ2kB', '2014-10-26 12:37:05', '2014-10-27 01:07:15', '3.jpg'),
(4, 'andytest@gmail.com', '$2y$10$Brk6WuWxzLyhU05I5N/wd.hYucadwPr2HP.ef74YazyujXffl3UAS', 'Andrew', 'Schaul', 'Andy Schaul', '0000-00-00', '', 'Brisbane', '', 'GwNENqAhbGFGXOW5LhuKmDHWgRXD1DVCbkxiyyv74JsLz2BlxkAY9qd48LCj', '2014-10-26 12:37:05', '2014-10-27 00:33:36', '4.jpg'),
(5, 'katelouisew@gmail.com', '$2y$10$9NYO1Ng44oEzBP91S1vIkOFi5kLcGgW3hmL4ieW37CHfIMAl8ct/6', 'Kate', 'Weir', 'Kate Weir', '0000-00-00', '', '', '', '', '2014-10-26 12:37:05', '2014-10-27 01:07:44', '5.jpg'),
(6, 'mitchell.stringfellow@uqconnect.edu.au', '$2y$10$5aRLNA45PZs1D41WZsWLCeadGQOkbUsxVBdxEogLURVpzkQ5WmLku', 'Mitchell', 'Stringfellow', 'Mitchell Stringfellow', '0000-00-00', '', '', '', '', '2014-10-26 12:37:05', '2014-10-26 12:37:05', 'default.png'),
(7, 'benjamin.byron@uqconnect.edu.au', '$2y$10$bIViv2QvDBriUtc.YZkfsO8Ymv4HE8nF7s9104VOlc36i871UkW3q', 'Ben', 'Byron', 'Benjamin Byron', '0000-00-00', '', '', 'Casual', '5e6lV8Qc1RfgRUmrIUu7jSVKnwccq7a402pRg1XyyicMYghesXbJ0dR29q2i', '2014-10-26 12:37:05', '2014-10-27 00:56:12', '7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users_personalachievements`
--

CREATE TABLE IF NOT EXISTS `users_personalachievements` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `personalachievement_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `project_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users_personalachievements`
--

INSERT INTO `users_personalachievements` (`id`, `user_id`, `personalachievement_id`, `created_at`, `updated_at`, `project_id`) VALUES
(1, 4, 1, '2014-10-27 00:31:19', '2014-10-27 00:31:19', 2),
(2, 4, 2, '2014-10-27 00:31:19', '2014-10-27 00:31:19', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users_projects`
--

CREATE TABLE IF NOT EXISTS `users_projects` (
`id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users_projects`
--

INSERT INTO `users_projects` (`id`, `project_id`, `user_id`, `created_at`, `updated_at`) VALUES
(2, 2, 2, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(3, 2, 3, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(4, 2, 4, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(5, 2, 5, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(6, 2, 6, '2014-09-16 22:33:24', '2014-09-16 22:33:24'),
(7, 2, 7, '2014-09-16 22:33:24', '2014-09-16 22:33:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acknowledgements`
--
ALTER TABLE `acknowledgements`
 ADD PRIMARY KEY (`id`), ADD KEY `acknowledgements_task_id_foreign` (`task_id`), ADD KEY `acknowledgements_post_id_foreign` (`post_id`), ADD KEY `acknowledgements_user_id_foreign` (`user_id`);

--
-- Indexes for table `datafiles`
--
ALTER TABLE `datafiles`
 ADD PRIMARY KEY (`id`), ADD KEY `datafiles_project_id_foreign` (`project_id`), ADD KEY `datafiles_user_id_foreign` (`user_id`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
 ADD PRIMARY KEY (`id`), ADD KEY `education_user_id_foreign` (`user_id`);

--
-- Indexes for table `interests`
--
ALTER TABLE `interests`
 ADD PRIMARY KEY (`id`), ADD KEY `education_user_id_foreign` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
 ADD PRIMARY KEY (`id`), ADD KEY `jobs_user_id_foreign` (`user_id`);

--
-- Indexes for table `meetings`
--
ALTER TABLE `meetings`
 ADD PRIMARY KEY (`id`), ADD KEY `meetings_project_id_foreign` (`project_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
 ADD PRIMARY KEY (`id`), ADD KEY `messages_user_id_foreign` (`user_id`), ADD KEY `messages_message_lobby_id_foreign` (`message_lobby_id`);

--
-- Indexes for table `messages_read`
--
ALTER TABLE `messages_read`
 ADD PRIMARY KEY (`id`), ADD KEY `messages_read_user_id_foreign` (`user_id`), ADD KEY `messages_read_message_id_foreign` (`message_id`), ADD KEY `messages_read_lobby_id_foreign` (`lobby_id`);

--
-- Indexes for table `message_lobbies`
--
ALTER TABLE `message_lobbies`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_lobby_users`
--
ALTER TABLE `message_lobby_users`
 ADD PRIMARY KEY (`id`), ADD KEY `message_lobby_users_message_lobby_id_foreign` (`message_lobby_id`), ADD KEY `message_lobby_users_user_id_foreign` (`user_id`);

--
-- Indexes for table `milestones`
--
ALTER TABLE `milestones`
 ADD PRIMARY KEY (`id`), ADD KEY `milestones_project_id_foreign` (`project_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
 ADD PRIMARY KEY (`id`), ADD KEY `notifications_to_id_foreign` (`to_id`), ADD KEY `notifications_from_id_foreign` (`from_id`), ADD KEY `notifications_category_id_foreign` (`category_id`), ADD KEY `notifications_project_id_foreign` (`project_id`);

--
-- Indexes for table `notification_categories`
--
ALTER TABLE `notification_categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personalachievements`
--
ALTER TABLE `personalachievements`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`), ADD KEY `posts_project_id_foreign` (`project_id`);

--
-- Indexes for table `posts_comments`
--
ALTER TABLE `posts_comments`
 ADD PRIMARY KEY (`id`), ADD KEY `posts_comments_user_id_foreign` (`user_id`), ADD KEY `posts_comments_post_id_foreign` (`post_id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
 ADD PRIMARY KEY (`id`), ADD KEY `profiles_user_id_foreign` (`user_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects_teamachievements`
--
ALTER TABLE `projects_teamachievements`
 ADD PRIMARY KEY (`id`), ADD KEY `projects_teamachievements_project_id_foreign` (`project_id`), ADD KEY `projects_teamachievements_teamachievement_id_foreign` (`teamachievement_id`);

--
-- Indexes for table `rules`
--
ALTER TABLE `rules`
 ADD PRIMARY KEY (`id`), ADD KEY `rules_project_id_foreign` (`project_id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
 ADD PRIMARY KEY (`id`), ADD KEY `skills_user_id_foreign` (`user_id`);

--
-- Indexes for table `stress`
--
ALTER TABLE `stress`
 ADD PRIMARY KEY (`id`), ADD KEY `stress_project_id_foreign` (`project_id`), ADD KEY `stress_user_id_foreign` (`user_id`);

--
-- Indexes for table `stress_tips`
--
ALTER TABLE `stress_tips`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
 ADD PRIMARY KEY (`id`), ADD KEY `tasks_milestone_id_foreign` (`milestone_id`), ADD KEY `tasks_user_id_foreign` (`user_id`);

--
-- Indexes for table `teamachievements`
--
ALTER TABLE `teamachievements`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_personalachievements`
--
ALTER TABLE `users_personalachievements`
 ADD PRIMARY KEY (`id`), ADD KEY `users_personalachievements_project_id_foreign` (`project_id`), ADD KEY `users_personalachievements_user_id_foreign` (`user_id`), ADD KEY `users_personalachievements_personalachievement_id_foreign` (`personalachievement_id`);

--
-- Indexes for table `users_projects`
--
ALTER TABLE `users_projects`
 ADD PRIMARY KEY (`id`), ADD KEY `users_projects_project_id_foreign` (`project_id`), ADD KEY `users_projects_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acknowledgements`
--
ALTER TABLE `acknowledgements`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `datafiles`
--
ALTER TABLE `datafiles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `interests`
--
ALTER TABLE `interests`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `meetings`
--
ALTER TABLE `meetings`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `messages_read`
--
ALTER TABLE `messages_read`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `message_lobbies`
--
ALTER TABLE `message_lobbies`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `message_lobby_users`
--
ALTER TABLE `message_lobby_users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `milestones`
--
ALTER TABLE `milestones`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `notification_categories`
--
ALTER TABLE `notification_categories`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `personalachievements`
--
ALTER TABLE `personalachievements`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `posts_comments`
--
ALTER TABLE `posts_comments`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `projects_teamachievements`
--
ALTER TABLE `projects_teamachievements`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rules`
--
ALTER TABLE `rules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `stress`
--
ALTER TABLE `stress`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `stress_tips`
--
ALTER TABLE `stress_tips`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `teamachievements`
--
ALTER TABLE `teamachievements`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users_personalachievements`
--
ALTER TABLE `users_personalachievements`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users_projects`
--
ALTER TABLE `users_projects`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `acknowledgements`
--
ALTER TABLE `acknowledgements`
ADD CONSTRAINT `acknowledgements_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `acknowledgements_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `acknowledgements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `datafiles`
--
ALTER TABLE `datafiles`
ADD CONSTRAINT `datafiles_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `datafiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `education`
--
ALTER TABLE `education`
ADD CONSTRAINT `education_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `interests`
--
ALTER TABLE `interests`
ADD CONSTRAINT `interests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
ADD CONSTRAINT `jobs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `meetings`
--
ALTER TABLE `meetings`
ADD CONSTRAINT `meetings_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
ADD CONSTRAINT `messages_message_lobby_id_foreign` FOREIGN KEY (`message_lobby_id`) REFERENCES `message_lobbies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messages_read`
--
ALTER TABLE `messages_read`
ADD CONSTRAINT `messages_read_lobby_id_foreign` FOREIGN KEY (`lobby_id`) REFERENCES `message_lobbies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `messages_read_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `messages_read_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `message_lobby_users`
--
ALTER TABLE `message_lobby_users`
ADD CONSTRAINT `message_lobby_users_message_lobby_id_foreign` FOREIGN KEY (`message_lobby_id`) REFERENCES `message_lobbies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `message_lobby_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `milestones`
--
ALTER TABLE `milestones`
ADD CONSTRAINT `milestones_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
ADD CONSTRAINT `notifications_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `notification_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `notifications_from_id_foreign` FOREIGN KEY (`from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `notifications_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `notifications_to_id_foreign` FOREIGN KEY (`to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
ADD CONSTRAINT `posts_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `posts_comments`
--
ALTER TABLE `posts_comments`
ADD CONSTRAINT `posts_comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `posts_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects_teamachievements`
--
ALTER TABLE `projects_teamachievements`
ADD CONSTRAINT `projects_teamachievements_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `projects_teamachievements_teamachievement_id_foreign` FOREIGN KEY (`teamachievement_id`) REFERENCES `teamachievements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rules`
--
ALTER TABLE `rules`
ADD CONSTRAINT `rules_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `skills`
--
ALTER TABLE `skills`
ADD CONSTRAINT `skills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stress`
--
ALTER TABLE `stress`
ADD CONSTRAINT `stress_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `stress_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
ADD CONSTRAINT `tasks_milestone_id_foreign` FOREIGN KEY (`milestone_id`) REFERENCES `milestones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_personalachievements`
--
ALTER TABLE `users_personalachievements`
ADD CONSTRAINT `users_personalachievements_personalachievement_id_foreign` FOREIGN KEY (`personalachievement_id`) REFERENCES `personalachievements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `users_personalachievements_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `users_personalachievements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_projects`
--
ALTER TABLE `users_projects`
ADD CONSTRAINT `users_projects_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `users_projects_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
