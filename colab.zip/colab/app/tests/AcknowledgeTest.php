<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class AcknowledgeTest extends TestCase {
	
	
	/**
	*  Test relation
	*/
	public function test_relations()
	{
		//Find test data
		$ack = Acknowledgement::find(1);
		if(isset($ack)){
			//User relation
			$this->assertEquals( $ack->user->display_name, 'Test User');
			//task relation
			$this->assertEquals( $ack->task->name, 'Test Task');
			//post relation
			$this->assertEquals( $ack->post->table, 'tasks');
		}
		else{
			$this->fail("Could not find acknowlegement");
		}
	}
	
}
?>