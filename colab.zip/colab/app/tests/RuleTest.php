<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class RuleTest extends TestCase {
	
	/**
	*  Test class
	*/
	public function test_class()
	{
		//Find test data
		$rule = Rule::find(1);
		if(isset($rule)){
			//Test project milestone relation
			$this->assertEquals( $rule->project->name, 'Test Project');
		}
		else{
			$this->fail('Could not find rule');
		}
		
	}

}
?>