<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class DatafileTest extends TestCase {
	
	
	/**
	*  Test relations
	*/
	public function test_relations()
	{
		//Find test data
		$file = Datafile::find(1);
		if(isset($file)){
			//Test user relation
			$this->assertEquals( $file->user->display_name, 'Test User');
			//Test project relation
			$this->assertEquals( $file->project->name, 'Test Project');
		}
		else{
			$this->fail("Could not find task");
		}
	}


}
?>