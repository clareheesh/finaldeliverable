<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class MeetingTest extends TestCase {
	
	/**
	*  Test relation
	*/
	public function test_project_relations()
	{
		//Find test data
		$meeting = Meeting::find(1);
		if(isset($meeting)){
			//Test project milestone relation
			$this->assertEquals( $meeting->project->name, 'Test Project');
		}
		else{
			$this->fail('Could not find meeting');
		}
		
	}

}
?>