<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class SkillTest extends TestCase {
	
	
	/**
	*  Test class
	*/
	public function test_class()
	{
		//Find test data
		$skill = Skill::find(1);		
		if(isset($skill)){
			//Test user relation
			$this->assertEquals( $skill->user()->first()->display_name, 'Test User');
		}
		else{
			$this->fail("Could not find skill");
		}
		
	}
}
?>