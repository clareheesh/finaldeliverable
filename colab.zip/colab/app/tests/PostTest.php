<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class PostTest extends TestCase {
	
	/**
	*  Test post class
	*/
	public function test_class()
	{
		//Find test data
		$post = Post::find(1);
		if (isset($post)){
			//project relation
			$this->assertEquals($post->project->name, "Test Project");
			//comment relation
			$this->assertEquals($post->getComments()[0]->comment, "Test Comment");
			//post relation
			$this->assertEquals($post->acknowledgements->first()->user_id, 2);
			//Check if user has acknowledege
			$this->assertNotEquals($post->hasAcknowledged(2),null);
			//Check if user has acknowledege
			$this->assertEquals($post->hasAcknowledged(3),null);
		}
		else{
			$this->fail("Could not find post");
		}	
	}
	
}
?>