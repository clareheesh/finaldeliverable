<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class TaskTest extends TestCase {
	
	
	/**
	*  Test class
	*/
	public function test_class()
	{
		//Find task
		$task = Task::find(1);
		if(isset($task)){
			//Test milestone relation
			$this->assertEquals( $task->milestone->name, 'Test Milestone');
			//Test user relation
			$this->assertEquals( $task->user->display_name, 'Test User');			
			//Test acknowledge relation
			$this->assertEquals( $task->acknowledgements->first()->user_id, 2);
			//Test project function
			$this->assertEquals( $task->getProject()->name, 'Test Project');
		}
		else{
			$this->fail("Could not find task");
		}
	}


}
?>