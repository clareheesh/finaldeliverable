<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class JobTest extends TestCase {
	
	
	/**
	*  Test relations
	*/
	public function test_relations()
	{
		//Find test data
		$job = Job::find(1);
		
		if(isset($job)){
			//Test user relation
			$this->assertEquals( $job->user()->first()->display_name, 'Test User');
		}
		else{
			$this->fail("Could not find job");
		}
		
	}
}
?>