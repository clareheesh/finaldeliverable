<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class CommentTest extends TestCase {
	
	
	/**
	*  Test relations
	*/
	public function test_relations()
	{
		//Find test data
		$comment = Comment::find(1);		
		if(isset($comment)){
			//Test user relation
			$this->assertEquals( $comment->getUser()->display_name, 'Test User');
		}
		else{
			$this->fail("Could not find comment");
		}
		
	}
}
?>