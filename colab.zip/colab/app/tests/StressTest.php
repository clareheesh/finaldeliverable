<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class StressTest extends TestCase {
	
	
	/**
	*  Test class
	*/
	public function test_class()
	{
		//Find Stress
		$stress = Stress::find(1);
		if(isset($stress)){
			//Test project milestone relation
			$this->assertEquals( $stress->user->display_name, 'Test User');
			//Test project milestone relation
			$this->assertEquals( $stress->project->name, 'Test Project');
		}
		else{
			$this->fail("Could not find stress");
		}
		
	}
}
?>