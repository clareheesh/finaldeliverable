<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class UserTest extends TestCase {

	/*
	 * Test user class
	 */
	public function test_class()
	{
		//Find test data
	    $user = User::find(2);
		if(isset($user)){
			//Test project task relation
			$this->assertEquals( $user->tasks->first()->name, 'Test Task');
			//project relation
			$this->assertEquals($user->projects->first()->name, 'Test Project');
			$this->assertEquals($user->stressInProject(1)->stress_level, 0);
			//stress relation
			$this->assertEquals($user->stress()->first()->stress_level, 0);
			//acknowledge relation
			$this->assertEquals($user->acknowledgements()->first()->task_id, 1);
			//personal achievement relation
			$this->assertEquals($user->personalachievements->first()->name, 'First Step');
			//message lobby relation
			$this->assertEquals($user->getMessageLobbies()[0]->id, 1);
			//datafile relation
			$this->assertEquals($user->datafiles()->first()->name, 'Test File');
		
			// test internal data
			$this->assertEquals( $user->getAuthIdentifier(), '2');
			$this->assertTrue( Hash::check('password', $user->getAuthPassword()));
			$this->assertEquals( $user->getReminderEmail(), 'testuser@gmail.com');
			//Test tokens
			$token = $user->getRememberTokenName();
			$user->setRememberToken($token);
			$this->assertEquals( $user->getRememberToken(), $token);
		}
		else{
			$this->fail("Could not find user");
		}
	}

}