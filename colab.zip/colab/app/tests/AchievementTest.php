<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class AchievementTest extends TestCase {
	
	
	/**
	*  Test relations
	*/
	public function test_relations()
	{
		//Find personal achievement
		$pa = Personalachievement::find(1);
		if(isset($pa)){
			//Test achievement user relation
			$this->assertEquals( $pa->users->first()->display_name, 'Test User');
		}
		else{
			$this->fail("Could not find task");
		}
		
		//Find team achievement
		$pa = Teamachievement::find(1);
		if(isset($pa)){
			//Test achievement user relation
			$this->assertEquals( $pa->projects->first()->name, 'Test Project');
		}
		else{
			$this->fail("Could not find task");
		}
	}


}
?>