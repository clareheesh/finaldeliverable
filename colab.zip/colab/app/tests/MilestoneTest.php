<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class MilestoneTest extends TestCase {
	
	/**
	*  Test milestone class
	*/
	public function test_class()
	{
		//Find test data
		$milestone = Milestone::find(1);		
		if(isset($milestone)){
			//project relation
			$this->assertEquals( $milestone->project->name, 'Test Project');
			//task relation
			$this->assertEquals($milestone->getTasks()[0]->name, 'Test Task');
			// Count tasks
			$this->assertEquals( $milestone->TotalTasks(), 2);
			//Count completed tasks
			$this->assertEquals( count($milestone->finishedTasks()), 1);
			//Test progress
			$this->assertEquals( $milestone->progress(), 50);	
		}
		else{
			$this->fail("Could not find milestone");
		}
	}
}
?>