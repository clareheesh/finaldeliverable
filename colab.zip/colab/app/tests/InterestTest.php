<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class InterestTest extends TestCase {
	
	
	/**
	*  Test user relation
	*/
	public function test_relations()
	{
		//Find test data
		$Interest = Interest::find(1);		
		if(isset($Interest)){
			//Test user relation
			$this->assertEquals( $Interest->user()->first()->display_name, 'Test User');
		}
		else{
			$this->fail("Could not find Interest");
		}
		
	}
}
?>