<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class EducationTest extends TestCase {
	
	
	/**
	*  Test relations
	*/
	public function test_relations()
	{
		//Find test data
		$education = Education::find(1);		
		if(isset($education)){
			//Test user relation
			$this->assertEquals( $education->user()->first()->display_name, 'Test User');
		}
		else{
			$this->fail("Could not find education");
		}
		
	}
}
?>