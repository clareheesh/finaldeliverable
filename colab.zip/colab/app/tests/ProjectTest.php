<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class ProjectTest extends TestCase {

	/*
	 * Test class
	 */
	public function test_class(){
		$project = Project::find(1);
		if(isset($project)){
			//milestone relation
			$this->assertEquals( $project->milestones()->first()->name,"Test Milestone");
			//rule relation
			$this->assertEquals($project->rules->first()->description, 'Test Rule');
			//team achievement relation
			$ta = Teamachievement::find(1);
			$this->assertEquals($project->teamachievements->first()->name, $ta->name);
			//post relation
			$this->assertEquals($project->posts->first()->table, 'tasks');
			//datafile relation
			$this->assertEquals($project->datafiles()->first()->name, 'Test File');	
			//Count the number of users
			$this->assertEquals( count($project->getUsers()), 1);
			//Count the number of users excluding the current user
			$this->assertEquals( count($project->otherUsers(2)), 0);
			//Count the stress levels
			$this->assertEquals( count($project->stress()->get()), 1);
			//Count milestones
			$this->assertEquals( $project->countMilestones(), 1);
			//Count tasks
			$this->assertEquals( $project->countTasks(), 2);
			//Count acknowledgeges
			$this->assertEquals( $project->countAck(), 1);
		}
		else{
			$this->fail("Could not find project");
		}
	}
}