<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class MessageTest extends TestCase {
	
	/**
	*  Test class
	*/
	public function test_relations()
	{
		//Find test data
		$MessageLobby = MessageLobby::find(1);		
		if(isset($MessageLobby)){
			//test user relations
			$this->assertEquals( $MessageLobby->users->first()->display_name, 'Test User');
			//test message relations
			$this->assertEquals( $MessageLobby->getMessages()[0]->contents, 'Test Message');			
			//test last message
			$this->assertEquals( $MessageLobby->lastMessage()->contents, 'Test Message');
			//test user count
			$this->assertEquals( $MessageLobby->userCount(), 1);
			//test other users
			$this->assertEquals( count($MessageLobby->getOtherUsers(2)), 0);
			//test counting unread messages
			$this->assertEquals( count($MessageLobby->countMsgUser(2)), 1);
		}
		else{
			$this->fail("Could not find lobby");
		}
		
		//Test message
		$message = Message::find(1);	
		if(isset($message)){
			//test user relations
			$this->assertEquals( $message->getUser()->display_name, 'Test User');
		}
		else{
			$this->fail("Could not find messsage");
		}
		
		//Test message reader
		$read = new MessageReader;
		$this->assertEquals( $read->countNotRead(2), 1);
		$this->assertEquals( $read->countAll(2), 1);	
		$read->readAll(2);
		$this->assertEquals( $read->countNotRead(2), 0);
	}
	
}
?>