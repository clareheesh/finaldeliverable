<?php
use Zizaco\FactoryMuff\Facade\FactoryMuff;
class UserPersonalAchievementTest extends TestCase {
	
	
	/**
	*  Test class
	*/
	public function test_class()
	{
		//Find test data
		$ach = UserPersonalAchievement::find(1);		
		if(isset($ach)){
			//Test user relation
			$this->assertEquals( $ach->getUser()->display_name, 'Test User');
			//Test achievement relation
			$this->assertEquals( $ach->getAch()->name, 'First Step');
		}
		else{
			$this->fail("Could not find achievement");
		}
		
	}
}
?>