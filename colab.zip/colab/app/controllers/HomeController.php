<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	 */

	/**
	 * Constructor with filters
	 */
	public function __construct()
	{
		// so if user is already logged in, he wont login again
        $this->beforeFilter('csrf', array('on' => 'post'));        
        $this->beforeFilter('guest', array('only' => 'getLogin'));
    }
	
	
    /**
	 * Change the users password
	 */
	public function savePassword(){
	
		// validate the info, create rules for the inputs
		$rules = array(
			'old_password'=>'required|min:6',
			'new_password'=>'required|min:6|confirmed',
		 );

		// run the validation rules on the inputs from the form
		$validator = Validator::make(Input::all(),$rules);		
		
		// if the validator passes, save user & redirect to login, otherwise back to reg form
		if ($validator->passes()) {
			$user = Auth::user();
			//Check if password match
			$userdata = array(
				'email' => $user->email,
				'password' => Input::get('old_password')
			);

			// attempt to do login, auth attempt checks plaintext password against hashed password
			if(Auth::attempt($userdata)) {
				//Success, change the password
				$user->password = Hash::make(Input::get('new_password'));
				$user->save();
				return Redirect::route('settings')
				->with('flash_notice', 'You have successfully changed your password');
			}
			else{
				//Authenticate failed
				return Redirect::route('settings')
				->with('flash_error', 'Your existing password was incorrect.');
			}
			
		} else {
			// Return to form with errors
		    return Redirect::route('settings')->withErrors($validator)->withInput();
		}
	
	}

    /**
	 * Get User Settings View
	 */
	public function getUserSettings(){
		// get logged in user
		$user = Auth::user();
		
		// get projects of user
		$projects = $user->projects;
		
		// create the view from folder "projects" -> settings.blade.php
		return View::make('projects.user-settings')
			->with('projects', $projects); // add variables to the view
	}

    /**
	 * Go to Index Page - landing/introductory page
	 */
	public function getIndex()
	{
		// If user is logged in - redirect to Projects dashboard
		if(Auth::check()) {
		   return Redirect::route('dashboard');
		}

		// create a view from the template index.blade.php (found in app/views folder)
		return View::make('index');
	}

	/**
	 * Go to login page
	 */
	public function getLogin()
	{
		return View::make('login');
	}
	
	/**
	 * Go to 404 page
	 */
	public function get404()
	{
		return View::make('404');
	}

	/**
	 * Go to About page
	 */
	public function getAbout()
	{
		return View::make('about');
	}

	/**
	 * Post login form
	 */
	public function postLogin()
	{
		// validate the info, create rules for the inputs
		$rules = array( 
			'email' => 'required|email', // make sure email is actual email
			'password' => 'required|min:6' // make sure password is alphanumeric and greater than 6 chars
		);

		// run the validation rules on the inputs from the form
		$validator = Validator::make(Input::all(),$rules);

		// if the validator failes, redirect back to the form
		if($validator->fails()) {
			return Redirect::to('login')
			->withErrors($validator)
			->withInput(Input::except('password'));
		} else {

			// create our user data for authentication
			$userdata = array(
				'email' => Input::get('email'),
				'password' => Input::get('password')
			);

			// attempt to do login, auth attempt checks plaintext password against hashed password
			if(Auth::attempt($userdata)) {
				return Redirect::intended(route('dashboard'))
                ->with('flash_notice', 'You are successfully logged in.');
			} else {
				return Redirect::to('login')
				->with('flash_error', 'Your email/password combination was incorrect.')
           	 	->withInput();
			}
		}
	}

	/**
	 * Logout
	 */
	public function getLogout()
	{
		// log user out of app
		Auth::logout(); 

		// redirect to named route 'home' (as seen in app/routes.php) with flash variable to show in the home page
		return Redirect::route('home')
			->with('flash_notice', 'You are successfully logged out.');
	}

	/**
	 * Go to reset page
	 */
	public function getReset()
	{
		return View::make('reset');
	}

	/**
	 * Go to Signup
	 */
	public function getSignup()
	{
		return View::make('signup');
	}

	
	/**
	 * Post registration form
	 */
	public function postRegister() {
		
		// validate the info, create rules for the inputs
		$rules = array(
			'first_name'=>'required|alpha|min:2',
			'last_name'=>'required|alpha|min:2',
		    'email'=>'required|email|unique:users',
		    'password'=>'required|between:6,12',
		 );

		// run the validation rules on the inputs from the form
		$validator = Validator::make(Input::all(),$rules);
		
		// if the validator passes, save user & redirect to login, otherwise back to reg form
		if ($validator->passes()) {
			// save new user
		    $user = new User;
		    $user->first_name = htmlspecialchars(Input::get('first_name'));
		    $user->last_name = htmlspecialchars(Input::get('last_name'));
			$user->display_name = $user->first_name." ".$user->last_name;
		    $user->email = Input::get('email');
		    $user->password = Hash::make(Input::get('password'));
		    $user->save();
			// Go to login page
		    return Redirect::route('login')->with('flash_notice', 'Thanks for registering!');
		} else {
			// Return to form with errors
		    return Redirect::route('signup')->with('flash_error', 'The following errors occurred')->withErrors($validator)->withInput();
		}
	}

}
