<?php

class ProjectController extends \BaseController {
	
	/*
	|--------------------------------------------------------------------------
	| Project Controller
	|--------------------------------------------------------------------------
	|
	| Handles functions that relate to Projects
	|
	*/

	/**
	 * Constructor with filters
	 */
	public function __construct()
    {	
    	// ensures that all Project pages are only accessible when user is logged in
        $this->beforeFilter('auth');
        // ensures that forms that are posted contain csrf token for added security
        $this->beforeFilter('csrf', array('on' => 'post'));

    }

	/**
	 * Go to index page of Projects section, which is the Dashboard 
	 * with a list of the user's projects
	 */
	public function getIndex()
	{
		// get logged in user
		$user = Auth::user();

		// get projects of user
		$projects = $user->projects;

		// create the view from folder "projects" -> index.blade.php
		return View::make('projects.index')
			->with('projects', $projects); // add variables to the view
	}
	
	/**
	 * Go to the Project page of Project with $Pid
	 */
	public function getProject($Pid)
	{	
		// code to get project object based on Pid is in View Composer in filters.php
		// put into view composer as the code is reused again and again
		return View::make('projects.project');
	}

	/**
	 * Go to create new project page
	 */
	public function getNewProject()
	{
		// get logged in user
		$user = Auth::user();

		// get projects of user
		$projects = $user->projects;

		// create the view from folder "projects" -> index.blade.php
		return View::make('projects.new-project')
			->with('projects', $projects); // add variables to the view
			
	}
	
	
	/**
	 * Go to the Overview page of Project with $Pid
	 */
	public function getOverview($Pid)
	{	
		// Get current user
		$user = Auth::user();

		// get user's personal tasks in project
		$myTasks = Task::whereHas('milestone', function($q) use ($Pid){
		    $q->where('project_id', '=', $Pid);
		})->where('user_id','=',$user->id)->where('soft_delete','!=',1)->get();

		// get user's stress level in project
		$stress = $user->stressInProject($Pid);
		return View::make('projects.overview', 
			array('user'=>$user, 'myTasks'=>$myTasks, 'stress'=>$stress));
	}

	/**
	 * Go to page with "Add Milestone" form
	 */
	public function addMilestone($Pid)
	{
		//Get current user
		$user = Auth::user();
		
		// create the view from folder "projects" -> milestone.blade.php
		return View::make('projects.milestone', 
			array('user'=>$user));
	}
	
	/**
	 * Go to page "Members"
	 */
	public function getMembers($Pid)
	{
		//Get current user
		$user = Auth::user();
		$project = Project::find($Pid);
		
		// Get project members
		$members = $project->getUsers();
		
		// create the view from folder "projects" -> members.blade.php
		return View::make('projects.members', 
			array('user'=>$user,'members'=>$members));
	}
	
	/**
	 * Go to page "Rules"
	 */
	public function getRules($Pid)
	{
        //Get current rules
        $rules = Rule::where('rules.project_id', '=', $Pid)->get();

		// create the view from folder "projects" -> rules.blade.php
		return View::make('projects.rules', 
			array('rules'=>$rules));
	}
	
	/**
	 * Go to page "Files"
	 */
	public function getFiles($Pid)
	{
		//Get current files
        $files = Datafile::where('datafiles.project_id', '=', $Pid)->get();
   
		// create the view from folder "projects" -> files.blade.php
		return View::make('projects.files', 
			array('files'=>$files));
	}
	
	/**
	 * Go to page "Chat"
	 */
	public function getChat($Pid)
	{
		// create the view from folder "projects" -> chat.blade.php
		return View::make('projects.chat');
	}
	
	/**
	 * Go to page "Messages"
	 */
	public function getMessagesGlobal()
	{
		// get all the members that are part of the current project
		$user = Auth::user();
		// get projects of user
		$projects = $user->projects;
		$otherUsers = array();
		$otherId = array();
		//Get users that are group members with the current user
		foreach ($projects as $project){
			foreach ($project->otherUsers($user->id) as $groupuser){
				//If user has not been added, add it to list and track their id
				if (!(in_array($groupuser->id,$otherId))){				
					array_push($otherUsers,$groupuser);
					array_push($otherId,$groupuser->id);
				}
			}
			
		}
		// create the view from folder "projects" -> index.blade.php
		return View::make('projects.messages-global')
			->with('otherUsers', $otherUsers)
			->with('projects', $projects); // add variables to the view
	}
	
	/**
	 * Go to page "Messages"
	 */
	public function getMessages($Pid)
	{
		// get all the members that are part of the current project
		$user = Auth::user();
		$project = Project::find($Pid);
		$otherUsers = $project->otherUsers($user->id);
		// create the view from folder "projects" -> messages.blade.php
		return View::make('projects.messages',
				array('otherUsers'=>$otherUsers));
	}
	
	/**
	 * Go to page "Help"
	 */
	public function getHelp($Pid)
	{
		// create the view from folder "projects" -> help.blade.php
		return View::make('projects.help');
	}
	
	/**
	 * Go to page "Meetings"
	 */
	public function getMeetings($Pid)
	{
		//Get project meetings
        $meetings = Meeting::where('project_id', '=', $Pid)->orderby('created_at', 'asc')->get();
		// create the view from folder "projects" -> meetings.blade.php
		return View::make('projects.meetings',
			array('meetings'=>$meetings));
	}
	
	/**
	 * Go to page "Stress"
	 */
	public function getStressLevels($Pid){
		//Get all users of projects
		$project = Project::find($Pid);
		$otherUsers = $project->getUsers();
		
		//Calculate group stress level
		$total = 0;
		foreach($otherUsers as $member){
			$total += $member->stressInProject($Pid)->stress_level;
		}
		$groupStress = intval(round($total/count($otherUsers)));
		
		//Get current users stress
		$stress = Auth::user()->stressInProject($Pid);

		
		//Return view with data
		return View::make('projects.stress',
			array('otherUsers'=>$otherUsers, 'groupStress'=>$groupStress, 'stress'=>$stress));
	}
	
	/**
	 * Go to page User Settings
	 */
	public function getSettings($Pid)
	{
		// create the view from folder "projects" -> settings.blade.php
		return View::make('projects.settings');
	}
	
	/**
	 * Go to page "User Profile"
	 */
	public function getProfile()
	{
		// get logged in user
		$user = Auth::user();
		
		// get projects of user
		$projects = $user->projects;
		
		// create the view from folder "projects" -> profile.blade.php
		return View::make('projects.profile')
			 // add variables to the view
			->with('user', $user)
			->with('projects', $projects);
	}
	
	/**
	 * Add member with member $Mid
	 */
	public function addMember($Pid,$Uid){
		//Find Project
		$project = Project::find($Pid);
		$user = User::find($Uid);
		
		//Check if user in project
		$exists = DB::table('users_projects')->where('user_id', $user->id)->where('project_id', $project->id)->first();
		
		if ($exists){
			//User already exists message
			Session::flash('flash_info', '<strong>'.$user->display_name.' is already in the group</strong>');
		}
		
		else if((isset($project))&&(isset($user))){
			//Add user to project
			$project->addUser($user->id);
			//Session message
			Session::flash('flash_notice', '<strong>Added '.$user->display_name.'</strong>');
			//Create Post for timeline
			$post 			= new Post;
			$post->table    = "users";
			$post->TB_id     = $user->id;
			$post->project_id      = $Pid;
			$post->save();
		}
		//Return to members page
		return Redirect::route('members', array('Pid' => $Pid));
	}
	
	/**
	 * Save a new rule in Project with $Pid
	 */
	public function saveRule($Pid)
	{
		// Validate
		$rules = array(
            'ruledesc'       => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);
		
		// if the validator passes, add rule
		if ($validator->passes()) {
			$rule = New Rule;
            $rule->description = Input::get('ruledesc');
			$rule->project_id = $Pid;
			$rule->save();
		}
		//Return to rules page with any errors
		return Redirect::route('rules', array('Pid' => $Pid))->withErrors($validator);
	}
    
	/**
	 * Remove Rule with $PR_id in Project with $Pid
	 */
	public function deleteRule($Pid, $PR_id)
	{
		//Delete rule
		$rule = Rule::where('id', '=', $PR_id)->delete();
		
		// redirect
		return Redirect::route('rules', array('Pid' => $Pid));
	}
        
	/**
	 * Save a new file in Project with $Pid
	 */
	public function saveFile($Pid)
	{
		//Get current user
		$user = Auth::user();
		// Validate user input
		$inputs = array(
			'filedata'       => 'required'
		);
		$validator = Validator::make(Input::all(), $inputs);
		$upload = Input::file('filedata');

	    // move to media storage
	    $dest = public_path().'/uploads';
		
		// if the validator passes, add a new file
		if ($validator->passes()) {
			//Save file data
            $file = New Datafile;
            $file->user_id = $user->id;
            $file->name = $upload->getClientOriginalName();
            $file->type = $upload->getMimeType();
            $file->size = $upload->getSize();
            $file->destination = $dest;
			$desc = Input::get('description');
			if (isset($desc)){
				$file->description = Input::get('description');
			}
			$file->project_id = $Pid;
			$file->save();
			//Upload the file
			$upload->move($dest, $upload->getClientOriginalName());
		}
        //Redirect
		return Redirect::route('files', array('Pid' => $Pid))->withErrors($validator);
	}
    
	/**
	 * Remove file with $Fid in Project with $Pid
	 */
	public function deleteFile($Pid, $Fid)
	{
		//If the file still exists, delete it
		$file = Datafile::find($Fid);
        $path = public_path().'/uploads/'.$file->name;
		if (File::exists($path)) {
		    File::delete($path);
		} 
		//Delete file from database
		$file->delete();		
		// return to FIles page
		return Redirect::route('files', array('Pid' => $Pid));
	}

	/**
	 * Download file with $Fid in Project with $Pid
	 */
	public function downloadFile($Pid, $Fid)
	{
		//Find the file
		$file = Datafile::find($Fid);
        $path = public_path().'/uploads/'.$file->name;
		//Tell the client to download the file
        return Response::download($path);
	}
    
	/**
	 * Save user profile
	 */
	public function saveProfile()
	{
		// get logged in user
		$user = Auth::user();
	
		// validate the info, create rules for the inputs
		$rules = array(
			'first_name'=>'required|alpha|min:2',
			'last_name'=>'required|alpha|min:2',
		    'email'=>'required|email',
		 );
		 
		 //If email is different, add unique requirement
		 if (Input::get('email')!=$user->email) {
			$rules['email'] = 'required|email|unique:users';
		 }

		// run the validation rules on the inputs from the form
		$validator = Validator::make(Input::all(),$rules);
		
		// if the validator passes, save user & redirect to login, otherwise back to reg form
		if ($validator->passes()) {
			// save new user
		    $user->first_name = htmlspecialchars(Input::get('first_name'));
		    $user->last_name = htmlspecialchars(Input::get('last_name'));
		    $user->email = htmlspecialchars(Input::get('email'));
			$user->about = htmlspecialchars(Input::get('about'));
			$user->location = htmlspecialchars(Input::get('location'));
			//If the user has included a photo
			if (Input::hasFile('photo'))
			{
				// upload photo to media storage and database
				$upload = Input::file('photo');				
				$user->display_picture = $user->id.'.'.$upload->getClientOriginalExtension();
				$dest = public_path().'/uploads/display_pictures';
				$upload->move($dest, $user->id.'.'.$upload->getClientOriginalExtension());
			}
		    $user->save();

		   //Save the users education info
        	$education = Education::firstOrNew(array('user_id' => $user->id));
        	$education->title = Input::get('degree');
        	$education->place = Input::get('university');
        	$education->field = Input::get('program');
        	$education->graduation_year = Input::get('grad_year');
        	$education->gpa = Input::get('gpa');
        	$education->save();

			//Save the user's job info
        	$job = Job::firstOrNew(array('user_id' => $user->id));
        	$job->name = Input::get('name');
        	$job->company = Input::get('company');
        	$job->department = Input::get('department');
        	$job->location = Input::get('location');
        	$job->date = Input::get('date');
        	$job->save();

			//Save the user's interest info
        	$interest = Interest::firstOrNew(array('user_id' => $user->id));
        	$interest->hobby = Input::get('hobby');
        	$interest->pet = Input::get('pet');
        	$interest->food = Input::get('food');
        	$interest->save();
			//Save the user's skill info
        	$skill = Skill::firstOrNew(array('user_id' => $user->id));
        	$skill->field = Input::get('field');
        	$skill->ability = Input::get('ability');
        	$skill->description = Input::get('description');
        	$skill->save();
			Session::flash('flash_notice', '<strong>Successfully saved profile</strong>');
		}
		//Return to profile page with any errors
		return Redirect::route('profile')->withErrors($validator);
    }
	 
	 
	/**
	 * Save a new milestone in Project with $Pid
	 */
	public function saveMilestone($Pid)
	{
		// validate
		$rules = array(
			'name'       => 'required',
			'description'       => 'required',
			'start_date'	=> 'required|date',
			'end_date'	=> 'required|date',
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the form
		if ($validator->fails()) {
		    return Redirect::route('milestone', array('Pid' => $Pid))
				->withErrors($validator)
				->withInput(Input::except('password'));
		} else {
			
			//change date format
			$start_day_old = Input::get('start_date');
			$start_day = date("Y-m-d", strtotime($start_day_old));
			$end_day_old = Input::get('end_date');
			$end_day = date("Y-m-d", strtotime($end_day_old));

			// store
			$milestone = new Milestone;
			$milestone->name = htmlspecialchars(Input::get('name'));
			$milestone->name = htmlspecialchars(Input::get('description'));
			$milestone->start_date = $start_day;
			$milestone->end_date = $end_day;
			$milestone->project_id = $Pid;
			$milestone->save();

			// redirect
			Session::flash('flash_notice', '<strong>Successfully created milestone:</strong> '.$milestone->name.'!');
			return Redirect::route('overview', array('Pid' => $Pid));
			}
		}

	/**
	 * Go to page with "Add Task" form
	 */
	public function addTask($Pid)
	{
		// get all the members of the current project
		// needed for dropdown menu for assigning a task to a member
		$project = Project::find($Pid);
		$otherUsers = $project->getUsers();

		//Create View
		return View::make('projects.task', 
			array('otherUsers'=>$otherUsers));
	}
	
	/**
	 * Edit the project's information
	 */
	public function editProject(){
		// get logged in user
		$user = Auth::user();
	
		// validate the info, create rules for the inputs
		$rules = array(
			'name'=>'required|min:2',
			'start_date'	=> 'required|date',
			'end_date'	=> 'required|date',
		 );

		// run the validation rules on the inputs from the form
		$validator = Validator::make(Input::all(),$rules);
		
		// if the validator passes, create new project
		if ($validator->passes()) {		
			//change date format
			$start_day_old = Input::get('start_dt');
			$start_day = date("Y-m-d", strtotime($start_day_old));
			$end_day_old = Input::get('end_dt');
			$end_day = date("Y-m-d", strtotime($end_day_old));
			
			//Save project
			$newProject = Project::find(Input::get('id'));
			$newProject->name = htmlspecialchars(Input::get('name'));
			$newProject->description = htmlspecialchars(Input::get('description'));
			$newProject->start_date = $start_day;
			$newProject->end_date = $end_day;
			$newProject->save();
			//Return to project settings 
			return Redirect::route('project-settings', array('Pid' => Input::get('id')))
				->with('flash_success', 'You have successfully changed the project settings');
		}
		else{
			//Return to project settings with any errors
			return Redirect::route('project-settings', array('Pid' => Input::get('id')))
				->withErrors($validator)->withInput();
		}
	}
	
	/**
	 * Create a new project
	 */
	public function saveNewProject()
	{
		// get logged in user
		$user = Auth::user();
	
		// validate the info, create rules for the inputs
		$rules = array(
			'name'=>'required|min:2',
			'start_date'	=> 'required|date',
			'end_date'	=> 'required|date',
		 );

		// run the validation rules on the inputs from the form
		$validator = Validator::make(Input::all(),$rules);
		
		// if the validator passes, create new project
		if ($validator->passes()) {
		
			//change date format
			$start_day_old = Input::get('start_dt');
			$start_day = date("Y-m-d", strtotime($start_day_old));
			$end_day_old = Input::get('end_dt');
			$end_day = date("Y-m-d", strtotime($end_day_old));
		
			// Save new project
			$newProject = new Project;
			$newProject->name = htmlspecialchars(Input::get('name'));
			$newProject->description = htmlspecialchars(Input::get('description'));
			$newProject->start_date = $start_day;
			$newProject->end_date = $end_day;
			$newProject->save();
			
			// Add user to project
			$newProject->addUser($user->id);
			return Redirect::route('project', array('Pid' => $newProject->id));
		}
		//Redirect
		return Redirect::route('new')
				->withErrors($validator)->withInput();
	}
	
	/**
	 * Save a new comment
	 */
	public function saveComment($Pid){
		//Get current user
		$user = Auth::user();
	
		// validate
		$rules = array(
			'post' => 'required',
			'comment' => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);

		// process the form
		if ($validator->fails()) {
		
		}
		else{
			//Save the comment
			$comment  = new Comment();
			$comment->post_id = htmlspecialchars(Input::get('post'));
			$comment->comment = htmlspecialchars(Input::get('comment'));
			$comment->user_id = $user->id;
			$comment->save();
		}
		//Return to timeline
		return Redirect::route('project', array('Pid' => $Pid));
	}

	/**
	 * Save a new task in Project with $Pid 
	 */
	public function saveTask($Pid)
	{

		// validate
		$rules = array(
			'milestone' => 'required',
			'name'       => 'required',
			'description'       => 'required',
			'start_date'	=> 'required|date',
			'end_date'	=> 'required|date',
			'user'    =>	'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the form
		if ($validator->fails()) {
		    return Redirect::route('task', array('Pid' => $Pid))
				->withErrors($validator)
				->withInput(Input::except('password'));
		} else {			
			//change date format
			$start_day_old = Input::get('start_date');
			$start_day = date("Y-m-d", strtotime($start_day_old));
			$end_day_old = Input::get('end_date');
			$end_day = date("Y-m-d", strtotime($end_day_old));

			// store
			$task = new Task;
			$task->name       = htmlspecialchars(Input::get('name'));
			$task->description   = htmlspecialchars(Input::get('description'));
			$task->start_date      = $start_day;
			$task->end_date 	= $end_day;
			$task->progress = 0;
			$task->milestone_id = Input::get('milestone');
			$task->user_id   =Input::get('user');
			$task->save();
			
			//Send Notification
			$user = Auth::user();
			
			$notification = new Notification;
			$notification->from_id= $user->id;
			$notification->to_id = $task->user->id;
			$notification->project_id = $Pid;
			$notification->category_id = 4;
			$notification->url = route('overview', array('Pid' => $Pid));
			$notification->extra = $task->name;
			$notification->save();

			// redirect
			Session::flash('flash_notice', '<strong>Successfully created task: </strong>'.$task->name.'!');
			return Redirect::route('overview', array('Pid' => $Pid));
		}
	}
	
	/**
	 * Go to Edit Task Page
	 */
	public function getEditTask($Pid,$Tid){
		$project = Project::find($Pid);
		$otherUsers = $project->getUsers();
		$task = Task::find($Tid);

		//Create View
		return View::make('projects.task-edit', 
			array('otherUsers'=>$otherUsers,'task'=>$task));
	
	}
	
	/**
	 * Edit a task  with id $Tid
	 */
	public function editTask($Pid,$Tid){
		// validate
		$rules = array(
			'milestone' => 'required',
			'name'       => 'required',
			'description'       => 'required',
			'start_date'	=> 'required|date',
			'end_date'	=> 'required|date',
			'user'    =>	'required'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the form
		if ($validator->fails()) {
		    return Redirect::route('edit-task-view', array('Pid' => $Pid,'Tid' => $Tid))
				->withErrors($validator)
				->withInput(Input::except('password'));
		} else {			
			//change date format
			$start_day_old = Input::get('start_date');
			$start_day = date("Y-m-d", strtotime($start_day_old));
			$end_day_old = Input::get('end_date');
			$end_day = date("Y-m-d", strtotime($end_day_old));

			// store
			$task = Task::find($Tid);
			$task->name       = htmlspecialchars(Input::get('name'));
			$task->description   = htmlspecialchars(Input::get('description'));
			$task->start_date      = $start_day;
			$task->end_date 	= $end_day;
			$task->progress = 0;
			$task->milestone_id = Input::get('milestone');
			$task->user_id   =Input::get('user');
			$task->save();
		
			// redirect
			Session::flash('flash_notice', '<strong>Successfully edit task: </strong>'.$task->name.'!');
			return Redirect::route('overview', array('Pid' => $Pid));
		}
	}

	/**
	 * Change the progress of a Task with $Tid in project with $Pid
	 */
	public function editTaskProgress($Pid, $Tid)
	{
		// validation rules
		$rules = array(
			'progress' => 'required|numeric|between:0,100'
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the form
		if ($validator->fails()) {
		    return Redirect::route('overview', array('Pid' => $Pid))
				->withErrors($validator)
				->withInput(Input::except('password'));
		} else {
			// store
			$task = Task::find($Tid);
			$task->progress = Input::get('progress');
			$task->save();

			// save award if progress was changed to 100%/complete
			if($task->progress==100){
				$user = Auth::user();
				$project = Project::find($Pid);
				
				//First step achievement
				$achieve_check =$user->personalachievements()->where('personalachievement_id',1)->first();
				if (!$achieve_check){
					if (count($user->tasks()->where('progress','=','100')->get())==1){
						$pa = new UserPersonalachievement;
						$pa->user_id = $user->id;
						$pa->personalachievement_id = 1;
						$pa->project_id = $Pid;
						$pa->save();
						Session::flash('flash_award', 'Great Job! You earned the achievement <strong>First Step</strong>!');
						// create a post in newsfeed announcing new project team achievement
						$post 			= new Post;
						$post->table    = "personalachievements";
						$post->TB_id     =  $pa->id;
						$post->project_id      = $Pid;
						$post->save();
					}
				}
				
				//Final step acheivement
				$achieve_check =$user->personalachievements()->where('personalachievement_id',2)->first();
				if (!$achieve_check){
					if (count($user->tasks()->where('progress','=','100')->get())==count($user->tasks()->get())){
						$pa = new UserPersonalachievement;
						$pa->user_id = $user->id;
						$pa->personalachievement_id = 2;
						$pa->project_id = $Pid;
						$pa->save();
						Session::flash('flash_award', 'Great Job! You earned the achievement <strong>The Last Step</strong>!');
						// create a post in newsfeed announcing new project team achievement
						$post 			= new Post;
						$post->table    = "personalachievements";
						$post->TB_id     =  $pa->id;
						$post->project_id      = $Pid;
						$post->save();
					}
				}
				
				//Synergy achievement
				$achieve_check = DB::table('projects_teamachievements')->where('project_id', $Pid)->where('teamachievement_id',2)->first();
				if (!$achieve_check){
					if (count($project->tasks()->where('progress','=','100')->get())==count($project->tasks()->get())){
						// save new team achievement
						$ta = new ProjectTeamachievement;
						$ta->project_id = $Pid;
						$ta->teamachievement_id = 2;
						$ta->save();
						
						//Notify team
						foreach($project->getUsers() as $oneUser){
							$notification = new Notification;
							$notification->from_id= $user->id;
							$notification->to_id = $oneUser->id;
							$notification->project_id = $Pid;
							$notification->category_id = 2;
							$notification->url = route('team-achievement', array('Pid' => $Pid));
							$notification->extra = 'Synergy';
							$notification->save();
						}

						// create a post in newsfeed announcing new project team achievement
						$post 			= new Post;
						$post->table    = "projects_teamachievements";
						$post->TB_id     =  2;
						$post->project_id      = $project->id;
						$post->save();
					}
				}
				
				// create a post in the newsfeed announcing the newly completed task
				$post 			= new Post;
				$post->table    = "tasks";
				$post->TB_id     = $Tid;
				$post->project_id      = $Pid;
				$post->save();
				Session::flash('flash_notice', '<strong> Successfully updated task: </strong>'.$task->name.'!');
				
			} else {
				Session::flash('flash_notice', '<strong> Successfully updated task: </strong>'.$task->name.'!');
			}

			// redirect
			return Redirect::route('overview', array('Pid' => $Pid));
			}
	}
	
	/**
	 * Save a new meeting
	 */
	public function saveMeeting($Pid){
		// validate
		$rules = array(
			'description'       => 'required',
			'start_date'	=> 'required|date',
		);
		$validator = Validator::make(Input::all(), $rules);

		// process the form
		if ($validator->fails()) {
		    return Redirect::route('meetings', array('Pid' => $Pid))
				->withErrors($validator);
		} else {		
			$meeting = new Meeting;
			$meeting->project_id = $Pid;
			$meeting->description = Input::get('description');
			
			//change date format
			$start_day_old = Input::get('start_date');
			$meeting->start_date = date("Y-m-d", strtotime($start_day_old));
			$meeting->end_date = date("Y-m-d", strtotime($start_day_old));
			
			//Start Time
			$minute = Input::get('start_minute');
			if ($minute < 10){
				$minute = "0".$minute;
			}
			if(Input::get('start_suffix')=="PM"){
				$meeting->start_time = (Input::get('start_hour')+12).":".$minute;
			}
			else{
				$meeting->start_time = Input::get('start_hour').":".$minute;
			}
			
			//End Time
			$minute = Input::get('end_minute');
			if ($minute < 10){
				$minute = "0".$minute;
			}
			if(Input::get('end_suffix')=="PM"){
				$meeting->end_time = (Input::get('end_hour')+12).":".$minute;
			}
			else{
				$meeting->end_time = Input::get('end_hour').":".$minute;
			}
			$meeting->save();
			//Send notifications
			$project = Project::find($Pid);
			$user = Auth::user();
			// notifications to be sent to all members of the project team for winning award
			foreach($project->getUsers() as $oneUser){
				$notification = new Notification;
			    $notification->from_id= $user->id;
			    $notification->to_id = $oneUser->id;
				$notification->project_id = $Pid;
			    $notification->category_id = 3;
			    $notification->url = route('meetings', array('Pid' => $Pid));
			    $notification->extra = date("D dS M Y", strtotime($meeting->start_date));
				$notification->save();
			}
			//Return to meetings page
			return Redirect::route('meetings', array('Pid' => $Pid));
		}
	}
	
	/**
	 * Remove meeting with $meeting_id in Project with $Pid
	 */
	public function deleteMeeting($Pid, $meeting_id)
	{
		//Delete meeting
		$meeting = Meeting::where('id', '=', $meeting_id)->delete();
		
		// redirect
		return Redirect::route('meetings', array('Pid' => $Pid));
	}
	
	/**
	 *	Soft Delete task with id of $task_id
	 */
	 public function deleteTask($Pid,$task_id){
		//Find task and soft delete
		$name = Task::where('id', '=', $task_id)->first()->name;
		$task = Task::where('id', '=', $task_id)->first();
		$task->soft_delete = 1;
		$task->save();
		
		// redirect to overview page
		return Redirect::route('overview', array('Pid' => $Pid))
			->with('flash_notice', 'You deleted task <strong>'.$name.'</strong>');
	 }
	 

	/**
	 * Go to the Project Status page of Project with $Pid
	 */
	public function getProjectStatus($Pid)
	{

		// get all the members that are part of the current project
		$project = Project::find($Pid);
		$otherUsers = $project->getUsers();
		
		//Calculate group stress level
		$total = 0;
		foreach($otherUsers as $member){
			$total += $member->stressInProject($Pid)->stress_level;
		}
		$groupStress = intval(round($total/count($otherUsers)));
		
		//Create View
		return View::make('projects.project-status',
			array('otherUsers'=>$otherUsers, 'groupStress'=>$groupStress));

	}

	/**
	 * Go to the Milestone Status page of Milestone with $Mid and Project with $Pid
	 */
	public function getMilestoneStatus($Pid, $Mid)
	{
		//Get current milestones
		$milestone= Milestone::find($Mid);
		//Create View
		return View::make('projects.milestone-status', 
			array('milestone' =>$milestone));
	}
	
	
	/**
	 * Create a new lobby and send message
	 */
	public function saveNewMessageGlobal(){
		$user = Auth::user();
		// validate
		$rules = array(
			'to' => 'required',
			'comment' => 'required'
		);
		$validator = Validator::make(Input::all(), $rules);
		
		// process the form
		if ($validator->fails()) {
		    return Redirect::route('globalmessages')
				->withErrors($validator);
		}
		else{
			//Create lobby
			$lobby = new MessageLobby;
			$lobby->save();
			//Add users to lobby
			$lobby->users()->attach($user->id);
			foreach (Input::get('to') as $otherUser){
				$lobby->users()->attach($otherUser);
			}
		}
		//Send message to lobby
		return $this->sendMessageGlobal($user,$lobby,htmlspecialchars(Input::get('comment')));
	}
	
	/**
	 * Send a message to an existing lobby
	 */
	public function saveMessageGlobal(){
		//Get current user
		$user = Auth::user();
	
		// validate
		$rules = array(
			'lobby' => 'required',
			'comment' => 'required'

		);
		$validator = Validator::make(Input::all(), $rules);
		// process the form
		if ($validator->fails()) {
		    return Redirect::route('globalmessages')
				->withErrors($validator);
		}
		else{
		
			//Get lobby to update timestamp
			$lobby = MessageLobby::find(Input::get('lobby'));
			$lobby->touch();
			//Send message
			return $this->sendMessageGlobal($user,$lobby,htmlspecialchars(Input::get('comment')));
		}
	}
	
	/**
	 * Send message to lobby
	 */
	public function sendMessageGlobal($user,$lobby,$contents){
		//Send message
		$message  = new Message();
		$message->message_lobby_id = $lobby->id;
		$message->contents = $contents;
		$message->user_id = $user->id;
		$message->save();
		
		//Create notifications
		foreach($lobby->getOtherUsers($user->id) as $userreader){
			$reader = new MessageReader;
			$reader->user_id = $userreader->id;
			$reader->message_id = $message->id;
			$reader->lobby_id = $lobby->id;
			$reader->read = 0;
			$reader->save();
		}
		
		//Return to message page
		return Redirect::route('globalmessages');
	}

	/**
	 * Go to the Personal Achievement page of user in the Project with $Pid
	 */
	public function getPersonalAchievement($Pid)
	{
		//Get current user
		$user = Auth::user();
		$project = Project::find($Pid);
		
		//Get achievements
		$achievements = Personalachievement::all();

		// user's personal achievements in the selected project
		$ach_id = $user->personalachievements()->get()->lists('id');

		//Create View
		return View::make('projects.personal-achievement',
			array('achievements' => $achievements,'ach_id' =>$ach_id));
	}

	/**
	 * Go to the Team Achievement page of Project with $Pid
	 */
	 
	public function getTeamAchievement($Pid)
	{
		//Get current user
		$user = Auth::user();
		$project = Project::find($Pid);
		
		//Get achievements
		$achievements = Teamachievement::all();

		// user's personal achievements in the selected project
		$ach_id = $project->teamachievements()->get()->lists('id');

		//Create View
		return View::make('projects.team-achievement',
			array('achievements' => $achievements,'ach_id' =>$ach_id));
	}


	/**
	 * Change the stress level of a user in Project with $Pid
	 */
	public function changeStress($Pid, $STid)
	{
		//Change old string into int
		$stress_level = 0;
		switch(Input::get('stress_level')){
			case "Low":
				$stress_level = 1;
				break;
			case "Medium":
				$stress_level = 2;
				break;
			case "High":
				$stress_level = 3;
				break;
			case "Going insane":
				$stress_level = 4;
				break;
		}
		// get user
		$user = Auth::user();
		
		// create stress
		$stress = new Stress;
		$stress->user_id = $user->id;
		$stress->project_id = $Pid;
		$stress->stress_level = $stress_level;
		$stress->save();
		
		// create a post for the newsfeed announcing the change in stress level
		$post 			= new Post;
		$post->table    = "stress";
		$post->TB_id     = $stress->id;
		$post->project_id      = $Pid;
		$post->save();
		
		// redirect with success message
		Session::flash('flash_notice', '<strong> Successfully changed stress level: </strong>'.Input::get('stress_level').'!');
		return Redirect::route('stresslevels', array('Pid' => $Pid));
	}

	/**
	 * Save an acknowledgement on a Post in Project with $Pid and Task with $Tid
	 */
	public function saveAcknowledgement($Pid, $Tid)
	{
		//Get current user
		$user = Auth::user();
		
		// save new acknowledgement
		$acknowledgement 			= new Acknowledgement;
		$acknowledgement->user_id    = Auth::user()->id;
		$acknowledgement->task_id       = $Tid;
		$acknowledgement->post_id      = Input::get('PSid');
		$acknowledgement->save();

		//Get task and count acknowledgments
		$task = Task::find($Tid);
		$project = Project::find($Pid);
		$ackCount = Acknowledgement::where('post_id', '=', Input::get('PSid'))->count();
		
		// get the users of a project
		$projectUsers = User::with(array('projects' => function($query) use ($Pid){
		    $query->where('users_projects.project_id', '=', $Pid);
		}))->get();
		
		//Check if team already has achievement
		$achieve_check = DB::table('projects_teamachievements')->where('project_id', $Pid)->where('teamachievement_id',1)->first();
		if (!$achieve_check){
			// check if a task is fully acknowleged to get team achievement
			// check if # of acknowledgements == # of team members -1 (remove the member who did the task)
			if( $ackCount == ((count($projectUsers)) - 1)) {
				// save new team achievement
				$ta = new ProjectTeamachievement;
				$ta->project_id = $Pid;
				$ta->teamachievement_id = 1;
				$ta->save();

				Session::flash('flash_award', '<strong>Great Job!</strong> The team earned the <strong>Group Love</strong> achievement!');
				// notifications to be sent to all members of the project team for winning award
				foreach($projectUsers as $oneUser){
					$notification = new Notification;
					$notification->from_id= $user->id;
					$notification->to_id = $oneUser->id;
					$notification->project_id = $Pid;
					$notification->category_id = 2;
					$notification->url = route('team-achievement', array('Pid' => $Pid));
					$notification->extra = 'Group Love';
					$notification->save();
				}

				// create a post in newsfeed announcing new project team achievement
				$post 			= new Post;
				$post->table    = "projects_teamachievements";
				$post->TB_id     =  1;
				$post->project_id      = $project->id;
				$post->save();

			}
		} else {
			Session::flash('flash_notice', '<strong>Successfully acknowledged:</strong> '.$task->name.'!');
		}

		// notification to be sent to owner of the completed task (person who accomplished the task) stating
		// who has acknowledged his task
		$notification = new Notification;
		$notification->from_id= $user->id;
		$notification->to_id = $task->user->id;
		$notification->project_id = $Pid;
		$notification->category_id = 1;
		$notification->url = route('overview', array('Pid' => $Pid));
		$notification->extra = $task->name;
		$notification->save();

		// redirect		
		return Redirect::route('project', array('Pid' => $Pid));
	}
}
