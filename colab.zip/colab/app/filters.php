<?php

/*
|--------------------------------------------------------------------------
| Application & Route Filters
|--------------------------------------------------------------------------
|
| Below you will find the "before" and "after" events for the application
| which may be used to do any work before or after a request into your
| application. Here you may also register your custom route filters.
|
*/

App::before(function($request)
{
	//
});


App::after(function($request, $response)
{
	//
});

/*
|--------------------------------------------------------------------------
| Authentication Filters
|--------------------------------------------------------------------------
|
| The following filters are used to verify that the user of the current
| session is logged into this application. The "basic" filter easily
| integrates HTTP Basic authentication for quick, simple checking.
|
*/

Route::filter('auth', function()
{
	if (Auth::guest()) return Redirect::guest('login')
		->with('flash_error', 'You must be logged in to view this page!');
});



Route::filter('auth.basic', function()
{
	return Auth::basic();
});

/*
|--------------------------------------------------------------------------
| Guest Filter
|--------------------------------------------------------------------------
|
| The "guest" filter is the counterpart of the authentication filters as
| it simply checks that the current user is not logged in. A redirect
| response will be issued if they are, which you may freely change.
|
*/

Route::filter('guest', function()
{
	if (Auth::check()) return Redirect::to('/');
});

/*
|--------------------------------------------------------------------------
| CSRF Protection Filter
|--------------------------------------------------------------------------
|
| The CSRF filter is responsible for protecting your application against
| cross-site request forgery attacks. If this special token in a user
| session does not match the one given in this request, we'll bail.
|
*/

Route::filter('csrf', function()
{
	if (Session::token() != Input::get('_token'))
	{
		throw new Illuminate\Session\TokenMismatchException;
	}
});


/*
|--------------------------------------------------------------------------
| Project View Composer
|--------------------------------------------------------------------------
|
| Project pages all require the selected Project object as well 
| as the list of a user's other Projects. In order to reduce
| code duplication a view composer passes this data to every Project view
|
*/


View::composer(array('projects.project','projects.overview','projects.member-add','projects.members', 'projects.milestone', 'projects.task','projects.project-status', 'projects.milestone-status', 'projects.files', 'projects.chat', 'projects.personal-achievement','projects.meetings','projects.rules','projects.team-achievement','projects.messages','projects.help','projects.stress','projects.settings','projects.task-edit'), function($view)
{
	
	$Pid = Route::getCurrentRoute()->getParameter('Pid');
	$user = Auth::user();
	$messageReader = new MessageReader;
	$stressLevel = $user->stressInProject($Pid)->stress_level;
	$tip = "";
	if($stressLevel>=3){
		$rawtip = DB::table('stress_tips')->where('id','=',rand(1,DB::table('stress_tips')->count()))->first();		
		$tip = '<div>We have noticed you are still stressed. Try this tip from <strong><a href="'.$rawtip->source_url.'" target="new">'.$rawtip->source_name."</a>:</strong></div><br><div>".$rawtip->content."</div>";
	}
	$otherProjects = $user->projects()->where('projects.id','!=',$Pid)->get();
	$project = $user->projects()->where('users_projects.project_id','=',$Pid)->first();
	$messageLobbies = $user->getMessageLobbies();
	$myTasks = Task::whereHas('milestone', function($q) use ($Pid)
	{
		$q->where('project_id', '=', $Pid);

	})->where('user_id','=',$user->id)->where('soft_delete','!=',1)->get();

    $view->with(array('messageReader' =>$messageReader,'otherProjects'=> $otherProjects, 'project'=> $project, 'myTasks'=>$myTasks, 'messageLobbies'=>$messageLobbies, 'stressLevel' =>$stressLevel,'stressTip' =>$tip));
});

View::composer(array('projects.layout-user','projects.messages-global'), function($view)
{
	$messageReader = new MessageReader;
	$user = Auth::user();
	$messageLobbies = $user->getMessageLobbies();
	$myTasks = Task::where('user_id','=',$user->id)->where('soft_delete','!=',1)->get();	
	$view->with(array('messageReader' =>$messageReader, 'messageLobbies' =>$messageLobbies,'myTasks' =>$myTasks));
});