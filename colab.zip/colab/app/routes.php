<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

// Profile
Route::get('404', array('as' => '404', 'uses' => 'HomeController@get404' ));

// Profile
Route::get('profile', array('as' => 'profile', 'uses' => 'HomeController@getProfile' ));

// Home page
Route::get('/', array('as' => 'home', 'uses' => 'HomeController@getIndex'));

// About page
Route::get('about', array('as' => 'about', 'uses' => 'HomeController@getAbout'));

// Login page
Route::get('login', array('as' => 'login', 'uses' => 'HomeController@getLogin'));

// Reset login page
Route::get('reset', array('as' => 'reset', 'uses' => 'HomeController@getReset'));

// Logout
Route::get('logout', array('as' => 'logout', 'uses' => 'HomeController@getLogout')); 

// Sign up
Route::get('signup', array('as' => 'signup', 'uses' => 'HomeController@getSignup'));

// New project
Route::get('new', array('as' => 'new','prefix' => 'projects/', 'uses' => 'ProjectController@getNewProject')); 

// Process creating new project
Route::post('new', array('as' => 'new','prefix' => 'projects/', 'uses' => 'ProjectController@saveNewProject'));

// Process login
Route::post('login', array('uses' => 'HomeController@postLogin'));

// Process signup
Route::post('signup', array('uses' => 'HomeController@postRegister'));

// Process updating profile
Route::post('profile', array('as' => 'profile','prefix' => 'projects/','uses' => 'ProjectController@saveProfile'));

// Process change password
Route::post('password', array('as' => 'password','prefix' => 'projects/','uses' => 'HomeController@savePassword'));

//--User Menu--//
Route::get('settings', array('as' => 'settings','prefix' => 'projects/','uses' => 'HomeController@getUserSettings'));
Route::get('profile', array('as' => 'profile','prefix' => 'projects/','uses' => 'ProjectController@getProfile'));

//--Global Messages--//
Route::get('messages', array('as' => 'globalmessages','prefix' => 'projects/','uses' => 'ProjectController@getMessagesGlobal'));
Route::post('newmessage', array('as' => 'newmessage','prefix' => 'projects/', 'uses' => 'ProjectController@saveNewMessageGlobal'));
Route::post('sendmessage', array('as' => 'sendmessage','prefix' => 'projects/', 'uses' => 'ProjectController@saveMessageGlobal'));

// routes to a certain project
Route::group(array('prefix' => 'projects/project/{Pid}/'), function()
	{
		//Group settings
		Route::get('settings', array('as' => 'project-settings','uses' => 'ProjectController@getSettings'));
		
		//Milestone Status
		Route::get('milestone-status/{Mid}', array('as' => 'milestone-status', 'uses' => 'ProjectController@getMilestoneStatus'));
		
		//Stress levels
		Route::get('stresslevels', array('as' => 'stresslevels', 'uses' => 'ProjectController@getStressLevels'));
		
		//Save Milestone
		Route::post('milestone', array('uses' => 'ProjectController@saveMilestone'));
		
		//Edit ProjectController
		Route::post('edit', array('uses' => 'ProjectController@editProject'));
		
		//Add meeting
		Route::post('meetings', array('as' => 'meetings', 'uses' => 'ProjectController@saveMeeting'));
		
		//Delete meeting
		Route::delete('meeting/{meeting_id}/delete', array('as' => 'delete-meeting', 'uses' => 'ProjectController@deleteMeeting'));
		
		//Save task
		Route::post('task', array('uses' => 'ProjectController@saveTask'));
		Route::delete('task/{task_id}/delete', array('as' => 'delete-task', 'uses' => 'ProjectController@deleteTask'));
		Route::put('task/{Tid}/edit_progress', array('as' => 'edit-task-progress', 'uses' => 'ProjectController@editTaskProgress'));
		Route::get('task/{Tid}/edit', array('as' => 'edit-task-view', 'uses' => 'ProjectController@getEditTask'));
		Route::post('task/{Tid}/edit', array('as' => 'edit-task', 'uses' => 'ProjectController@editTask'));
		
		//Add member
		Route::get('member/{Uid}', array('as' => 'addmember','uses' => 'ProjectController@addMember'));
		
		//Save comment
		Route::post('comment', array('uses' => 'ProjectController@saveComment'));
        
		//Change users stress level
		Route::put('stress/{STid}/change', array('as' => 'change-stress', 'uses' => 'ProjectController@changeStress'));

		//Save Acknowledge task
		Route::post('task/{Tid}/acknowledge', array('as' => 'acknowledge', 'uses' => 'ProjectController@saveAcknowledgement'));
	
		//Notifier readAll
		Route::get('/categories', function(){
			Notifynder::readAll(Auth::user()->Uemail);          
			return '';
		});
		
		//Process sending message
		Route::post('message', array('as' => 'message', 'uses' => 'ProjectController@saveMessage'));
		
		//Process add rule
		Route::post('rules', array('as' => 'rules', 'uses' => 'ProjectController@saveRule'));
        
        //Process deleting rule
		Route::delete('rule/{PR_id}/delete', array('as' => 'delete-rule', 'uses' => 'ProjectController@deleteRule'));
        
        //Process adding file
        Route::post('files', array('as' => 'files', 'uses' => 'ProjectController@saveFile'));
        
        //Process deleting file
		Route::delete('file/{Fid}/delete', array('as' => 'delete-file', 'uses' => 'ProjectController@deleteFile'));

		// Process downloading file
		Route::get('file/{Fid}/download', array('as' => 'download-file', 'uses' => 'ProjectController@downloadFile'));
		
		//--Menu--//
		Route::get('/', array('as' => 'project', 'uses' => 'ProjectController@getProject'));
		Route::get('members', array('as' => 'members', 'uses' => 'ProjectController@getMembers'));
		Route::get('rules', array('as' => 'rules', 'uses' => 'ProjectController@getRules'));
		Route::get('files', array('as' => 'files', 'uses' => 'ProjectController@getFiles'));
		
		//--Task and Milestone Submenu--//
		Route::get('overview', array('as' => 'overview', 'uses' => 'ProjectController@getOverview'));
		Route::get('task', array('as' => 'task', 'uses' => 'ProjectController@addTask'));
		Route::get('milestone', array('as' => 'milestone', 'uses' => 'ProjectController@addMilestone'));
		Route::get('project-status', array('as' => 'project-status', 'uses' => 'ProjectController@getProjectStatus'));

		//--Communication Submenu--//
		Route::get('chat', array('as' => 'chat', 'uses' => 'ProjectController@getChat'));
		Route::get('messages', array('as' => 'messages', 'uses' => 'ProjectController@getMessages'));
		Route::get('help', array('as' => 'help', 'uses' => 'ProjectController@getHelp'));
		Route::get('meetings', array('as' => 'meetings', 'uses' => 'ProjectController@getMeetings'));
		
		//--Achievements Submenu--//
		Route::get('personal-achievement', array('as' => 'personal-achievement', 'uses' => 'ProjectController@getPersonalAchievement'));
		Route::get('team-achievement', array('as' => 'team-achievement', 'uses' => 'ProjectController@getTeamAchievement'));

		//Search Members
		Route::post('search', array('as' => 'search', function($Pid)
		{
			$search = Input::get('search');
			$results = User::where('display_name','LIKE', '%'.$search.'%')->get();
			
			foreach ($results as $x){
				if ($x->id !=1){
					echo "<div class=\"col-lg-6\"><a href=\"".URL::route('addmember', array('Pid' => $Pid,'Uid' => $x->id))."\"><i class=\"fa fa-plus\"></i> ".$x->display_name."</a></div>";
				}
			}
		}));
	});

// route for AJAX call - used to update notifications status from unread to read
Route::get('categories', array('as' => 'categories', function()
{
    Notifynder::readAll(Auth::user()->id);          
	return '';
}));

//AJAX call to read messages
Route::get('readmsg/{user_id}', array('as' => 'readmsg', function()
{
    $readAll = new MessageReader;
	$readAll->readAll(Auth::user()->id);
	return '';
}));

// route to project controller
Route::controller('projects', 'ProjectController', array(
	'getIndex'=>'dashboard',
	));


