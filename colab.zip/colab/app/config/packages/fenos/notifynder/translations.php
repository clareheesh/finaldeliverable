<?php


// Add your translations in this array following the array of the
// language and speficing the name of the category to translate
// feel free to add it how much you want

return array(

        'it' => array(

            'notifynder' => 'e un ottimo pacchetto',

        ),

        'fr' => array(


        ),

        'es' => array(


        )

);
