## CoLab

Colab is an effective, web-based Group Management Application. The application enables users to form groups, allocate tasks and milestones, gain achievements and communicate stress levels to other group members. By focusing not only on hard issues like task completion, CoLab helps users "feel confident and supported working in a team".

## This Project Uses Laravel

Documentation for the entire laravel framework can be found on the [Laravel website](http://laravel.com/docs).


### Laravel License

The Laravel framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)
